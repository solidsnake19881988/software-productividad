import React, { useState } from "react";
import { 
  LayoutDashboard, 
  Settings, 
  Cpu, 
  MapIcon, 
  Users, 
  Bell,
  Menu,
  X,
  CalendarDays,
  Activity,
  Boxes
} from "lucide-react";
import { Toaster } from "sonner";
import { GlobalLegend } from "@/app/components/GlobalLegend";
import { GlobalActionToolbar } from "@/app/components/GlobalActionToolbar";
import { AIAssistantChat } from "@/app/components/AIAssistantChat";
import { EngineStatusPanel } from "@/app/components/EngineStatusPanel";

// Import new blueprint views
import { DashboardView } from "@/app/components/DashboardView";
import { MachinesLinesView } from "@/app/components/MachinesLinesView";
import { ProcessFlowView } from "@/app/components/ProcessFlowView";
import { SimulationsView2 } from "@/app/components/SimulationsView2";
import { ManualPlannerView } from "@/app/components/ManualPlannerView";
import { MaintainersDataView } from "@/app/components/MaintainersDataView";

export type View = "dashboard" | "machines" | "process-flow" | "planner" | "simulations" | "maintainers";

export default function App() {
  const [currentView, setCurrentView] = useState<View>("dashboard");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showLegend, setShowLegend] = useState(true);

  const navigation = [
    { id: "dashboard", name: "Dashboard", icon: LayoutDashboard },
    { id: "machines", name: "Máquinas & Líneas", icon: Cpu },
    { id: "process-flow", name: "Plano del Proceso", icon: MapIcon },
    { id: "planner", name: "Planificador Manual", icon: CalendarDays },
    { id: "simulations", name: "Simulaciones", icon: Activity },
    { id: "maintainers", name: "Mantenedores", icon: Settings }
  ];

  const renderView = () => {
    switch (currentView) {
      case "dashboard": return <DashboardView />;
      case "machines": return <MachinesLinesView />;
      case "process-flow": return <ProcessFlowView />;
      case "planner": return <ManualPlannerView />;
      case "simulations": return <SimulationsView2 />;
      case "maintainers": return <MaintainersDataView />;
      default: return <DashboardView />;
    }
  };

  const handleNavClick = (id: View) => {
    setCurrentView(id);
    if (window.innerWidth < 768) setIsSidebarOpen(false);
  };

  return (
    <div className="flex h-screen bg-[#0a0a0f] text-slate-200 overflow-hidden font-sans selection:bg-orange-500/30">
      <Toaster position="top-right" theme="dark" richColors />
      
      {/* Sidebar */}
      <aside 
        className={`${
          isSidebarOpen ? "w-64" : "w-20"
        } transition-all duration-300 bg-[#12121a] border-r border-slate-800 flex flex-col z-50 shadow-2xl`}
      >
        {/* Logo Header */}
        <div className="p-6 flex items-center justify-between border-b border-slate-800/50">
          {isSidebarOpen ? (
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-gradient-to-br from-orange-600 to-orange-700 rounded-lg flex items-center justify-center shadow-lg shadow-orange-900/30">
                <Boxes className="text-white w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-base tracking-tight text-white block leading-none">
                  OPTI<span className="text-orange-500">FLOW</span>
                </span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest">MILP Platform</span>
              </div>
            </div>
          ) : (
            <Boxes className="text-orange-500 w-8 h-8 mx-auto" />
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navigation.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id as View)}
              className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all group relative ${
                currentView === item.id 
                  ? "bg-orange-600 text-white shadow-lg shadow-orange-900/30" 
                  : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
              }`}
            >
              <item.icon 
                className={`w-5 h-5 flex-shrink-0 transition-transform ${
                  currentView === item.id ? "scale-110" : "group-hover:scale-110"
                }`} 
              />
              {isSidebarOpen && (
                <span className="font-medium whitespace-nowrap text-sm">
                  {item.name}
                </span>
              )}
              {isSidebarOpen && currentView === item.id && (
                <div className="ml-auto w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
              )}
            </button>
          ))}
        </nav>

        {/* System Status */}
        {isSidebarOpen && (
          <div className="px-4 py-3 border-t border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-xs">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-slate-400 font-mono">ENGINE: OPTIMAL</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <div className="w-2 h-2 rounded-full bg-blue-500" />
              <span className="text-slate-400 font-mono">SYNC: SAP_ERP</span>
            </div>
          </div>
        )}

        {/* Toggle Button */}
        <div className="p-4 border-t border-slate-800">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="w-full flex items-center justify-center p-2 rounded-lg hover:bg-slate-800 text-slate-400 transition-colors"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header className="h-16 border-b border-slate-800 bg-[#12121a]/80 backdrop-blur-xl flex items-center justify-between px-8 z-40 sticky top-0">
          <div className="flex items-center gap-4">
            <h2 className="text-lg font-bold text-white tracking-wide">
              {navigation.find(n => n.id === currentView)?.name.toUpperCase()}
            </h2>
            <div className="h-4 w-[1px] bg-slate-800" />
            <span className="text-xs text-slate-500 font-mono">BLUEPRINT UX v2.0</span>
          </div>

          <div className="flex items-center gap-6">
            {/* Status Indicators */}
            <div className="hidden lg:flex items-center gap-4 text-xs font-mono">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span className="text-slate-400">ENGINE: OPTIMAL</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <span className="text-slate-400">SYNC: SAP_ERP</span>
              </div>
            </div>

            {/* User Actions */}
            <div className="flex items-center gap-4">
              <button className="p-2 text-slate-400 hover:text-white relative bg-slate-800/50 rounded-lg transition-colors">
                <Bell className="w-4 h-4" />
                <span className="absolute top-0 right-0 w-2 h-2 bg-red-600 rounded-full border-2 border-[#12121a]" />
              </button>
              <div className="flex items-center gap-3 pl-4 border-l border-slate-800">
                <div className="text-right">
                  <p className="text-xs font-bold text-white leading-none">PLANNER</p>
                  <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-widest">Blueprint Mode</p>
                </div>
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-slate-700 to-slate-900 flex items-center justify-center border border-slate-700">
                  <Users className="w-4 h-4 text-slate-400" />
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* View Container */}
        <div className="flex-1 overflow-auto bg-[#0a0a0f] relative">
          <div className="min-h-full h-full pb-32">
            {renderView()}
          </div>
        </div>

        {/* Global Legend */}
        {showLegend && <GlobalLegend />}

        {/* Global Action Toolbar */}
        <GlobalActionToolbar />

        {/* AI Assistant Chat */}
        <AIAssistantChat />

        {/* Engine Status Panel */}
        <EngineStatusPanel />

        {/* Footer Badge */}
        <div className="absolute bottom-4 right-4 z-10">
          <div className="flex flex-col gap-2 items-end">
            <button
              onClick={() => setShowLegend(!showLegend)}
              className="px-3 py-1.5 bg-slate-900/95 border border-slate-700 rounded-lg text-xs text-slate-400 hover:text-white transition-colors"
            >
              {showLegend ? "Ocultar Leyenda" : "Mostrar Leyenda"}
            </button>
            <div className="bg-slate-900/95 border border-orange-600/30 rounded-lg px-4 py-2 shadow-2xl backdrop-blur-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                <span className="text-xs font-mono text-slate-400">
                  BLUEPRINT MODE - No functional logic
                </span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}