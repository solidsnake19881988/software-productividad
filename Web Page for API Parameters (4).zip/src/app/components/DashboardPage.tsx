import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { ArrowLeft, TrendingUp, TrendingDown, Package, Clock } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface DashboardPageProps {
  onBack: () => void;
}

export function DashboardPage({ onBack }: DashboardPageProps) {
  // Datos de ejemplo para producción mensual
  const productionData = [
    { mes: 'Ene', produccion: 4500, planificado: 4200 },
    { mes: 'Feb', produccion: 4800, planificado: 4500 },
    { mes: 'Mar', produccion: 5200, planificado: 5000 },
    { mes: 'Abr', produccion: 4900, planificado: 5100 },
    { mes: 'May', produccion: 5400, planificado: 5200 },
    { mes: 'Jun', produccion: 5600, planificado: 5300 },
  ];

  // Datos de eficiencia por línea
  const efficiencyData = [
    { linea: 'Línea 1', eficiencia: 92 },
    { linea: 'Línea 2', eficiencia: 88 },
    { linea: 'Línea 3', eficiencia: 95 },
    { linea: 'Línea 4', eficiencia: 85 },
  ];

  // Datos de distribución de productos
  const productDistribution = [
    { producto: 'Pech s/hp', valor: 30 },
    { producto: 'Alas', valor: 25 },
    { producto: 'Filetillo', valor: 20 },
    { producto: 'Trufro Pollo', valor: 15 },
    { producto: 'Otros', valor: 10 },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  // KPIs principales
  const kpis = [
    {
      title: 'Producción Total',
      value: '30,400 kg',
      change: '+12.5%',
      trend: 'up',
      icon: Package,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      title: 'Eficiencia Global',
      value: '90.2%',
      change: '+3.2%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      title: 'Tiempo de Operación',
      value: '168 hrs',
      change: '-2.1%',
      trend: 'down',
      icon: Clock,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
    },
    {
      title: 'Cumplimiento',
      value: '94.8%',
      change: '+5.4%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
    },
  ];

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">
              KPIs, gráficos y analíticas de planificaciones
            </p>
          </div>
        </div>

        {/* KPIs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((kpi) => {
            const Icon = kpi.icon;
            const TrendIcon = kpi.trend === 'up' ? TrendingUp : TrendingDown;
            return (
              <Card key={kpi.title}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{kpi.title}</CardTitle>
                  <div className={`w-10 h-10 rounded-lg ${kpi.bgColor} flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${kpi.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{kpi.value}</div>
                  <div className="flex items-center gap-1 text-sm">
                    <TrendIcon className={`w-4 h-4 ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`} />
                    <span className={kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}>
                      {kpi.change}
                    </span>
                    <span className="text-muted-foreground">vs mes anterior</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Gráficos principales */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Producción vs Planificado */}
          <Card>
            <CardHeader>
              <CardTitle>Producción vs Planificado</CardTitle>
              <CardDescription>Comparación mensual de producción real vs planificada (kg)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={productionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="produccion" stroke="#0088FE" strokeWidth={2} name="Producción Real" />
                  <Line type="monotone" dataKey="planificado" stroke="#FF8042" strokeWidth={2} strokeDasharray="5 5" name="Planificado" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Eficiencia por línea */}
          <Card>
            <CardHeader>
              <CardTitle>Eficiencia por Línea</CardTitle>
              <CardDescription>Rendimiento de cada línea de producción (%)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={efficiencyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="linea" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="eficiencia" fill="#00C49F" name="Eficiencia %" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Distribución de productos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Distribución de Productos</CardTitle>
              <CardDescription>Porcentaje de producción por tipo de producto</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={productDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ producto, valor }) => `${producto}: ${valor}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="valor"
                  >
                    {productDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Resumen de planificaciones */}
          <Card>
            <CardHeader>
              <CardTitle>Resumen de Planificaciones</CardTitle>
              <CardDescription>Estadísticas de las últimas planificaciones</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <span className="font-medium">Total Planificaciones</span>
                  <span className="text-2xl font-bold">24</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <span className="font-medium">Planificaciones Exitosas</span>
                  <span className="text-2xl font-bold text-green-600">22</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <span className="font-medium">Tiempo Promedio de Cálculo</span>
                  <span className="text-2xl font-bold">3.2 seg</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <span className="font-medium">Ahorro Promedio</span>
                  <span className="text-2xl font-bold text-blue-600">12.5%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
