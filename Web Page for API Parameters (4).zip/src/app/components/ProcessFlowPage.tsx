import { useState, useEffect, useRef } from 'react';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/app/components/ui/dialog';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Switch } from '@/app/components/ui/switch';
import { ArrowLeft, Plus, Trash2, Power, PowerOff, Play, Pause, RotateCcw, Link2, Move, ZoomIn, ZoomOut } from 'lucide-react';
import { toast } from 'sonner';

interface ProcessFlowPageProps {
  onBack: () => void;
}

interface Machine {
  id: string;
  name: string;
  type: string;
  line: number;
  position: { x: number; y: number };
  active: boolean;
  parameters: {
    speed: number;
    efficiency: number;
    workingHours: number;
  };
  currentLoad?: number;
}

interface SpecialNode {
  id: string;
  name: string;
  position: { x: number; y: number };
  capacity?: number;
}

interface FlowLine {
  id: string;
  from: string;
  to: string;
}

interface Particle {
  id: string;
  product: string;
  color: string;
  amount: number;
  currentPath: string[];
  pathIndex: number;
  progress: number;
  position: { x: number; y: number };
}

interface Planning {
  id: string;
  name: string;
  date: string;
  totalProduction: number;
}

interface SimulationState {
  isRunning: boolean;
  currentTime: number;
  inventory: number;
  output: number;
  machineLoads: Record<string, number>;
  totalGenerated: number;
  initialInventory: number;
}

const PRODUCTS = [
  { name: 'Pech s/hp', color: '#ef4444' },
  { name: 'Alas', color: '#3b82f6' },
  { name: 'Filetillo', color: '#10b981' },
  { name: 'Trufro Pollo', color: '#f59e0b' },
  { name: 'Nuggets', color: '#8b5cf6' },
];

export function ProcessFlowPage({ onBack }: ProcessFlowPageProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const INITIAL_INVENTORY = 15000;
  
  const [machines, setMachines] = useState<Machine[]>([
    {
      id: 'm1',
      name: 'IQF-01',
      type: 'IQF',
      line: 1,
      position: { x: 350, y: 250 },
      active: true,
      parameters: { speed: 1800, efficiency: 92, workingHours: 8 },
      currentLoad: 0,
    },
    {
      id: 'm2',
      name: 'IQF-02',
      type: 'IQF',
      line: 1,
      position: { x: 350, y: 400 },
      active: true,
      parameters: { speed: 1600, efficiency: 88, workingHours: 8 },
      currentLoad: 0,
    },
    {
      id: 'm3',
      name: 'CALIBRADO-01',
      type: 'CALIBRADO',
      line: 2,
      position: { x: 650, y: 250 },
      active: true,
      parameters: { speed: 1500, efficiency: 90, workingHours: 8 },
      currentLoad: 0,
    },
    {
      id: 'm4',
      name: 'EMPAQUE-01',
      type: 'EMPAQUE',
      line: 2,
      position: { x: 650, y: 400 },
      active: true,
      parameters: { speed: 1400, efficiency: 85, workingHours: 8 },
      currentLoad: 0,
    },
  ]);

  const [specialNodes, setSpecialNodes] = useState<SpecialNode[]>([
    {
      id: 'inventory',
      name: 'Inventario',
      position: { x: 50, y: 300 },
      capacity: INITIAL_INVENTORY,
    },
    {
      id: 'output',
      name: 'Sumidero',
      position: { x: 950, y: 300 },
    },
  ]);

  const [flowLines, setFlowLines] = useState<FlowLine[]>([
    { id: 'f0-1', from: 'inventory', to: 'm1' },
    { id: 'f0-2', from: 'inventory', to: 'm2' },
    { id: 'f1', from: 'm1', to: 'm3' },
    { id: 'f2', from: 'm2', to: 'm4' },
    { id: 'f3', from: 'm3', to: 'output' },
    { id: 'f4', from: 'm4', to: 'output' },
  ]);

  const [particles, setParticles] = useState<Particle[]>([]);
  const particleIdCounter = useRef(0);

  const [plannings] = useState<Planning[]>([
    { id: 'p1', name: 'Planificación Enero 2026', date: '2026-01-15', totalProduction: 12000 },
    { id: 'p2', name: 'Planificación Diciembre 2025', date: '2025-12-20', totalProduction: 11500 },
    { id: 'p3', name: 'Planificación Noviembre 2025', date: '2025-11-18', totalProduction: 10800 },
  ]);

  const [selectedPlanning, setSelectedPlanning] = useState<string>('');
  const [simulation, setSimulation] = useState<SimulationState>({
    isRunning: false,
    currentTime: 0,
    inventory: INITIAL_INVENTORY,
    output: 0,
    machineLoads: {},
    totalGenerated: 0,
    initialInventory: INITIAL_INVENTORY,
  });

  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });
  const [draggedNode, setDraggedNode] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [hoveredFlowLine, setHoveredFlowLine] = useState<string | null>(null);

  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showAddLineDialog, setShowAddLineDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAddFlowDialog, setShowAddFlowDialog] = useState(false);
  const [showEditNodeDialog, setShowEditNodeDialog] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [selectedNode, setSelectedNode] = useState<SpecialNode | null>(null);
  const [newFlowLine, setNewFlowLine] = useState({ from: '', to: '' });
  const [newLineNumber, setNewLineNumber] = useState(3);
  const [newLineName, setNewLineName] = useState('');

  const [newMachine, setNewMachine] = useState({
    name: '',
    type: 'IQF',
    line: 1,
    speed: 1500,
    efficiency: 90,
    workingHours: 8,
  });

  // Función para encontrar caminos desde un nodo al sumidero
  const findPaths = (startNode: string): string[][] => {
    const paths: string[][] = [];
    const visited = new Set<string>();

    const dfs = (current: string, path: string[]) => {
      if (current === 'output') {
        paths.push([...path, current]);
        return;
      }

      if (visited.has(current)) return;
      visited.add(current);

      const connections = flowLines.filter((f) => f.from === current);
      for (const conn of connections) {
        dfs(conn.to, [...path, current]);
      }

      visited.delete(current);
    };

    dfs(startNode, []);
    return paths;
  };

  // Generar partículas desde el inventario
  const generateParticle = () => {
    // No generar si el inventario está vacío o se alcanzó el total
    if (simulation.inventory <= 0 || simulation.totalGenerated >= simulation.initialInventory) {
      return;
    }

    const paths = findPaths('inventory');
    if (paths.length === 0) return;

    const randomPath = paths[Math.floor(Math.random() * paths.length)];
    const randomProduct = PRODUCTS[Math.floor(Math.random() * PRODUCTS.length)];
    
    // Calcular cantidad disponible
    const maxAmount = Math.min(150, simulation.inventory, simulation.initialInventory - simulation.totalGenerated);
    if (maxAmount < 50) return; // No generar partículas muy pequeñas
    
    const amount = Math.floor(Math.random() * (maxAmount - 50) + 50);

    const particle: Particle = {
      id: `p${particleIdCounter.current++}`,
      product: randomProduct.name,
      color: randomProduct.color,
      amount,
      currentPath: randomPath,
      pathIndex: 0,
      progress: 0,
      position: getNodePosition('inventory'),
    };

    setParticles((prev) => [...prev, particle]);
    
    // Disminuir el inventario inmediatamente cuando sale la partícula
    setSimulation((prev) => ({
      ...prev,
      inventory: Math.max(0, prev.inventory - amount),
      totalGenerated: prev.totalGenerated + amount,
    }));
  };

  // Simulación - 17 horas total, 2 minutos simulados por segundo
  useEffect(() => {
    if (!simulation.isRunning || !selectedPlanning) return;

    const interval = setInterval(() => {
      setSimulation((prev) => {
        const newTime = prev.currentTime + 120; // 2 minutos por tick
        const totalSimulationTime = 17 * 3600; // 17 horas en segundos

        if (newTime >= totalSimulationTime) {
          toast.success('Simulación completada');
          return { ...prev, isRunning: false, currentTime: totalSimulationTime };
        }

        // Calcular cargas de máquinas
        const newLoads: Record<string, number> = {};

        machines.forEach((machine) => {
          if (!machine.active) {
            newLoads[machine.id] = 0;
            return;
          }

          const efficiency = machine.parameters.efficiency / 100;
          newLoads[machine.id] = machine.parameters.speed * efficiency;
        });

        return {
          ...prev,
          currentTime: newTime,
          machineLoads: newLoads,
        };
      });

      // Generar partículas periódicamente si hay inventario disponible
      if (simulation.inventory > 0 && simulation.totalGenerated < simulation.initialInventory) {
        if (Math.random() < 0.4) {
          generateParticle();
        }
      }
    }, 1000); // Tick cada segundo

    return () => clearInterval(interval);
  }, [simulation.isRunning, simulation.inventory, simulation.totalGenerated, machines, flowLines, selectedPlanning]);

  // Animación de partículas
  useEffect(() => {
    if (!simulation.isRunning) return;

    const interval = setInterval(() => {
      setParticles((prevParticles) => {
        const particlesToRemove: string[] = [];
        
        const updatedParticles = prevParticles
          .map((particle) => {
            const { currentPath, pathIndex, progress } = particle;

            if (pathIndex >= currentPath.length - 1) {
              // La partícula llegó al final del camino
              const lastNode = currentPath[currentPath.length - 1];
              if (lastNode === 'output') {
                // Incrementar el output cuando llega al sumidero
                particlesToRemove.push(particle.id);
                setSimulation((prev) => ({
                  ...prev,
                  output: prev.output + particle.amount,
                }));
              }
              return null; // Remover partícula
            }

            const fromNode = currentPath[pathIndex];
            const toNode = currentPath[pathIndex + 1];
            const fromPos = getNodePosition(fromNode);
            const toPos = getNodePosition(toNode);

            const fromX = fromNode.startsWith('m') || fromNode === 'inventory' ? fromPos.x + 60 : fromPos.x + 50;
            const fromY = fromNode.startsWith('m') || fromNode === 'inventory' ? fromPos.y + 40 : fromPos.y + 40;
            const toX = toNode === 'output' ? toPos.x : toPos.x;
            const toY = toNode === 'output' ? toPos.y + 40 : toPos.y + 40;

            let newProgress = progress + 0.02; // Velocidad de movimiento

            if (newProgress >= 1) {
              // Avanzar al siguiente segmento
              return {
                ...particle,
                pathIndex: pathIndex + 1,
                progress: 0,
                position: { x: toX, y: toY },
              };
            }

            // Interpolación lineal
            const x = fromX + (toX - fromX) * newProgress;
            const y = fromY + (toY - fromY) * newProgress;

            return {
              ...particle,
              progress: newProgress,
              position: { x, y },
            };
          })
          .filter((p): p is Particle => p !== null);
        
        return updatedParticles;
      });
    }, 50); // Actualizar cada 50ms

    return () => clearInterval(interval);
  }, [simulation.isRunning]);

  const handleMouseDown = (e: React.MouseEvent, nodeId: string, isSpecial: boolean = false) => {
    if (simulation.isRunning) return;

    if (e.button === 1 || e.ctrlKey) {
      // Middle click o Ctrl+click para pan
      setIsPanning(true);
      setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
      return;
    }

    const nodePos = getNodePosition(nodeId);
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    setDraggedNode(nodeId);
    setDragOffset({
      x: e.clientX - rect.left - panOffset.x - nodePos.x,
      y: e.clientY - rect.top - panOffset.y - nodePos.y,
    });
  };

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget || (e.target as HTMLElement).tagName === 'svg') {
      setIsPanning(true);
      setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isPanning) {
      setPanOffset({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y,
      });
      return;
    }

    if (!draggedNode || simulation.isRunning) return;

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const newX = e.clientX - rect.left - panOffset.x - dragOffset.x;
    const newY = e.clientY - rect.top - panOffset.y - dragOffset.y;

    // Actualizar posición de máquina o nodo especial
    const machine = machines.find((m) => m.id === draggedNode);
    if (machine) {
      setMachines(
        machines.map((m) =>
          m.id === draggedNode ? { ...m, position: { x: newX, y: newY } } : m
        )
      );
    } else {
      setSpecialNodes(
        specialNodes.map((n) =>
          n.id === draggedNode ? { ...n, position: { x: newX, y: newY } } : n
        )
      );
    }
  };

  const handleMouseUp = () => {
    setDraggedNode(null);
    setIsPanning(false);
  };

  const handleAddMachine = () => {
    const machine: Machine = {
      id: `m${Date.now()}`,
      name: newMachine.name,
      type: newMachine.type,
      line: newMachine.line,
      position: { x: 400, y: 300 },
      active: true,
      parameters: {
        speed: newMachine.speed,
        efficiency: newMachine.efficiency,
        workingHours: newMachine.workingHours,
      },
      currentLoad: 0,
    };

    setMachines([...machines, machine]);
    setShowAddDialog(false);
    toast.success(`Máquina ${newMachine.name} agregada`);
    setNewMachine({
      name: '',
      type: 'IQF',
      line: 1,
      speed: 1500,
      efficiency: 90,
      workingHours: 8,
    });
  };

  const handleAddLine = () => {
    toast.success(`Línea ${newLineNumber} - ${newLineName} creada`);
    setShowAddLineDialog(false);
    setNewLineNumber(newLineNumber + 1);
    setNewLineName('');
  };

  const handleAddFlowLine = () => {
    if (!newFlowLine.from || !newFlowLine.to) {
      toast.error('Selecciona origen y destino');
      return;
    }

    const flowLine: FlowLine = {
      id: `f${Date.now()}`,
      from: newFlowLine.from,
      to: newFlowLine.to,
    };

    setFlowLines([...flowLines, flowLine]);
    setShowAddFlowDialog(false);
    toast.success('Línea de flujo agregada');
    setNewFlowLine({ from: '', to: '' });
  };

  const handleDeleteFlowLine = (id: string) => {
    setFlowLines(flowLines.filter((f) => f.id !== id));
    toast.success('Línea de flujo eliminada');
  };

  const handleEditMachine = () => {
    if (!selectedMachine) return;

    setMachines(
      machines.map((m) =>
        m.id === selectedMachine.id
          ? {
              ...m,
              name: selectedMachine.name,
              parameters: selectedMachine.parameters,
              active: selectedMachine.active,
            }
          : m
      )
    );
    setShowEditDialog(false);
    toast.success(`Máquina ${selectedMachine.name} actualizada`);
  };

  const handleEditNode = () => {
    if (!selectedNode) return;

    setSpecialNodes(
      specialNodes.map((n) => (n.id === selectedNode.id ? selectedNode : n))
    );
    setShowEditNodeDialog(false);
    toast.success(`Nodo ${selectedNode.name} actualizado`);
  };

  const handleToggleMachine = (id: string) => {
    setMachines(machines.map((m) => (m.id === id ? { ...m, active: !m.active } : m)));
  };

  const handleDeleteMachine = (id: string) => {
    const machine = machines.find((m) => m.id === id);
    setMachines(machines.filter((m) => m.id !== id));
    setFlowLines(flowLines.filter((f) => f.from !== id && f.to !== id));
    toast.success(`Máquina ${machine?.name} eliminada`);
  };

  const handleDeleteNode = (id: string) => {
    const node = specialNodes.find((n) => n.id === id);
    setSpecialNodes(specialNodes.filter((n) => n.id !== id));
    setFlowLines(flowLines.filter((f) => f.from !== id && f.to !== id));
    toast.success(`Nodo ${node?.name} eliminado`);
  };

  const startSimulation = () => {
    if (!selectedPlanning) {
      toast.error('Selecciona una planificación primero');
      return;
    }
    setSimulation({ ...simulation, isRunning: true });
    setParticles([]);
    toast.success('Simulación iniciada');
  };

  const pauseSimulation = () => {
    setSimulation({ ...simulation, isRunning: false });
  };

  const resetSimulation = () => {
    setSimulation({
      isRunning: false,
      currentTime: 0,
      inventory: INITIAL_INVENTORY,
      output: 0,
      machineLoads: {},
      totalGenerated: 0,
      initialInventory: INITIAL_INVENTORY,
    });
    setParticles([]);
    toast.info('Simulación reiniciada');
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  };

  const formatPlanningTime = (seconds: number) => {
    // Hora de inicio de planificación: 08:00
    const startHour = 8;
    const startMinute = 0;
    
    const totalMinutes = startHour * 60 + startMinute + Math.floor(seconds / 60);
    const hour = Math.floor(totalMinutes / 60) % 24;
    const minute = totalMinutes % 60;
    
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
  };

  const allNodes = [
    ...specialNodes.map((n) => ({ id: n.id, name: n.name })),
    ...machines.map((m) => ({ id: m.id, name: m.name })),
  ];

  const getNodePosition = (id: string) => {
    const specialNode = specialNodes.find((n) => n.id === id);
    if (specialNode) return specialNode.position;
    return machines.find((m) => m.id === id)?.position || { x: 0, y: 0 };
  };

  const getNodeColor = (id: string) => {
    if (id === 'inventory') return 'bg-blue-600 border-blue-500';
    if (id === 'output') return 'bg-red-600 border-red-500';
    return 'bg-orange-500 border-orange-600';
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-[1600px] mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={onBack}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Plano del Proceso</h1>
              <p className="text-muted-foreground">
                Configuración interactiva y simulación del flujo de producción
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setShowAddFlowDialog(true)}>
              <Link2 className="mr-2 h-4 w-4" />
              Agregar Flujo
            </Button>
            <Button variant="outline" onClick={() => setShowAddLineDialog(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Nueva Línea
            </Button>
            <Button onClick={() => setShowAddDialog(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Agregar Máquina
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Panel de control */}
          <div className="lg:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Control de Simulación</CardTitle>
                <CardDescription>Planificación de 17 horas</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Planificación</Label>
                  <Select value={selectedPlanning} onValueChange={setSelectedPlanning}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona una planificación" />
                    </SelectTrigger>
                    <SelectContent>
                      {plannings.map((p) => (
                        <SelectItem key={p.id} value={p.id}>
                          {p.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-2">
                  {!simulation.isRunning ? (
                    <Button onClick={startSimulation} className="flex-1">
                      <Play className="mr-2 h-4 w-4" />
                      Iniciar
                    </Button>
                  ) : (
                    <Button onClick={pauseSimulation} className="flex-1" variant="secondary">
                      <Pause className="mr-2 h-4 w-4" />
                      Pausar
                    </Button>
                  )}
                  <Button onClick={resetSimulation} variant="outline">
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Tiempo de Simulación</p>
                    <p className="text-4xl font-bold font-mono">
                      {formatTime(simulation.currentTime)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {((simulation.currentTime / (17 * 3600)) * 100).toFixed(1)}% completado
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-primary/10 rounded-lg border border-primary/20">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Hora de Planificación</p>
                    <p className="text-3xl font-bold font-mono text-primary">
                      {formatPlanningTime(simulation.currentTime)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Inicio: 08:00 - Fin estimado: 01:00
                    </p>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground bg-muted p-2 rounded">
                  💡 Usa rueda del mouse o Ctrl+click para navegar
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>KPIs en Tiempo Real</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Inventario Restante</span>
                    <span className="text-2xl font-bold text-blue-600">
                      {simulation.inventory.toFixed(0)} kg
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all"
                      style={{
                        width: `${Math.max(0, Math.min(100, (simulation.inventory / 15000) * 100))}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Producción Acumulada</span>
                    <span className="text-2xl font-bold text-green-600">
                      {simulation.output.toFixed(0)} kg
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-sm font-semibold">Carga por Máquina (kg/h)</p>
                  {machines
                    .filter((m) => m.active)
                    .map((m) => (
                      <div key={m.id} className="flex justify-between text-sm">
                        <span>{m.name}</span>
                        <span className="font-mono">
                          {(simulation.machineLoads[m.id] || 0).toFixed(0)} kg/h
                        </span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Leyenda de Productos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {PRODUCTS.map((product) => (
                    <div key={product.name} className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: product.color }}
                      />
                      <span className="text-sm">{product.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Líneas de Flujo</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {flowLines.map((line) => {
                    const fromNode = allNodes.find((n) => n.id === line.from);
                    const toNode = allNodes.find((n) => n.id === line.to);
                    return (
                      <div
                        key={line.id}
                        className="flex items-center justify-between p-2 bg-muted rounded text-sm"
                      >
                        <span>
                          {fromNode?.name} → {toNode?.name}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteFlowLine(line.id)}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Canvas principal */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Diagrama de Flujo 2D</CardTitle>
                <CardDescription>
                  Arrastra nodos para reposicionar. Click en líneas de flujo para eliminar.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  ref={canvasRef}
                  className="relative w-full h-[700px] bg-slate-800 rounded-lg overflow-hidden border-2 border-slate-700 cursor-move"
                  onMouseDown={handleCanvasMouseDown}
                  onMouseMove={handleMouseMove}
                  onMouseUp={handleMouseUp}
                  onMouseLeave={handleMouseUp}
                >
                  <div
                    style={{
                      transform: `translate(${panOffset.x}px, ${panOffset.y}px)`,
                      width: '2000px',
                      height: '2000px',
                      position: 'absolute',
                    }}
                  >
                    {/* Grid de fondo */}
                    <svg
                      className="absolute inset-0 w-full h-full pointer-events-none"
                      style={{ width: '2000px', height: '2000px' }}
                    >
                      <defs>
                        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                          <path
                            d="M 40 0 L 0 0 0 40"
                            fill="none"
                            stroke="rgba(255,255,255,0.1)"
                            strokeWidth="1"
                          />
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#grid)" />
                    </svg>

                    {/* Líneas de flujo */}
                    <svg
                      className="absolute inset-0 w-full h-full"
                      style={{ width: '2000px', height: '2000px' }}
                    >
                      <defs>
                        <marker
                          id="arrowhead"
                          markerWidth="10"
                          markerHeight="10"
                          refX="9"
                          refY="3"
                          orient="auto"
                        >
                          <polygon points="0 0, 10 3, 0 6" fill="#60a5fa" />
                        </marker>
                      </defs>
                      {flowLines.map((line) => {
                        const fromPos = getNodePosition(line.from);
                        const toPos = getNodePosition(line.to);

                        const fromX = fromPos.x + 60;
                        const fromY = fromPos.y + 40;
                        const toX = toPos.x;
                        const toY = toPos.y + 40;

                        const isHovered = hoveredFlowLine === line.id;

                        return (
                          <g key={line.id}>
                            {/* Línea invisible más gruesa para mejor hover */}
                            <line
                              x1={fromX}
                              y1={fromY}
                              x2={toX}
                              y2={toY}
                              stroke="transparent"
                              strokeWidth="15"
                              className="cursor-pointer"
                              onMouseEnter={() => setHoveredFlowLine(line.id)}
                              onMouseLeave={() => setHoveredFlowLine(null)}
                              onClick={(e) => {
                                e.stopPropagation();
                                if (
                                  window.confirm(
                                    '¿Deseas eliminar esta línea de flujo?'
                                  )
                                ) {
                                  handleDeleteFlowLine(line.id);
                                }
                              }}
                            />
                            {/* Línea visual */}
                            <line
                              x1={fromX}
                              y1={fromY}
                              x2={toX}
                              y2={toY}
                              stroke={isHovered ? '#fbbf24' : '#60a5fa'}
                              strokeWidth={isHovered ? '4' : '3'}
                              strokeDasharray="5,5"
                              markerEnd="url(#arrowhead)"
                              className="pointer-events-none"
                            />
                          </g>
                        );
                      })}
                    </svg>

                    {/* Partículas en movimiento */}
                    {particles.map((particle) => (
                      <div
                        key={particle.id}
                        className="absolute pointer-events-none transition-all"
                        style={{
                          left: particle.position.x - 15,
                          top: particle.position.y - 15,
                        }}
                      >
                        <div className="relative">
                          <div
                            className="w-8 h-8 rounded-full shadow-lg border-2 border-white"
                            style={{ backgroundColor: particle.color }}
                          />
                          <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-black/75 text-white px-2 py-0.5 rounded text-xs whitespace-nowrap">
                            {particle.amount} kg
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Nodos especiales */}
                    {specialNodes.map((node) => (
                      <div
                        key={node.id}
                        className="absolute cursor-grab active:cursor-grabbing"
                        style={{
                          left: node.position.x,
                          top: node.position.y,
                        }}
                        onMouseDown={(e) => handleMouseDown(e, node.id, true)}
                        onClick={(e) => {
                          if (draggedNode) return;
                          e.stopPropagation();
                          setSelectedNode(node);
                          setShowEditNodeDialog(true);
                        }}
                      >
                        <div
                          className={`w-24 h-20 rounded-lg border-2 shadow-lg flex flex-col items-center justify-center ${getNodeColor(
                            node.id
                          )}`}
                        >
                          <div className="text-white font-bold text-xs">{node.name}</div>
                          <div className="text-white text-xs mt-1">
                            {node.id === 'inventory'
                              ? `${simulation.inventory.toFixed(0)} kg`
                              : `${simulation.output.toFixed(0)} kg`}
                          </div>
                        </div>
                        <div className="absolute -top-2 -right-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (
                                window.confirm(
                                  `¿Deseas eliminar ${node.name}?`
                                )
                              ) {
                                handleDeleteNode(node.id);
                              }
                            }}
                            className="p-1 bg-red-600 rounded-full"
                          >
                            <Trash2 className="w-3 h-3 text-white" />
                          </button>
                        </div>
                      </div>
                    ))}

                    {/* Máquinas */}
                    {machines.map((machine) => (
                      <div
                        key={machine.id}
                        className={`absolute cursor-grab active:cursor-grabbing transition-all ${
                          machine.active ? 'opacity-100' : 'opacity-50'
                        } ${draggedNode === machine.id ? 'z-50 scale-110' : ''}`}
                        style={{
                          left: machine.position.x,
                          top: machine.position.y,
                        }}
                        onMouseDown={(e) => handleMouseDown(e, machine.id)}
                        onClick={(e) => {
                          if (draggedNode) return;
                          e.stopPropagation();
                          setSelectedMachine(machine);
                          setShowEditDialog(true);
                        }}
                      >
                        <div
                          className={`w-32 h-20 rounded-lg border-2 shadow-lg flex flex-col items-center justify-center relative ${
                            machine.active
                              ? 'bg-orange-500 border-orange-600'
                              : 'bg-gray-500 border-gray-600'
                          }`}
                        >
                          <div className="text-white font-bold text-xs">{machine.name}</div>
                          <div className="text-white text-xs">{machine.type}</div>
                          <div className="text-white text-xs mt-1">
                            {machine.parameters.speed} kg/h
                          </div>
                          {simulation.isRunning && machine.active && (
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                          )}
                        </div>
                        <div className="absolute -top-2 -right-2 flex gap-1">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleMachine(machine.id);
                            }}
                            className={`p-1 rounded-full ${
                              machine.active ? 'bg-green-500' : 'bg-red-500'
                            }`}
                          >
                            {machine.active ? (
                              <Power className="w-3 h-3 text-white" />
                            ) : (
                              <PowerOff className="w-3 h-3 text-white" />
                            )}
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteMachine(machine.id);
                            }}
                            className="p-1 bg-red-600 rounded-full"
                          >
                            <Trash2 className="w-3 h-3 text-white" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Dialogs... */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Agregar Nueva Máquina</DialogTitle>
            <DialogDescription>Define los parámetros de la nueva máquina</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre de la Máquina</Label>
              <Input
                id="name"
                value={newMachine.name}
                onChange={(e) => setNewMachine({ ...newMachine, name: e.target.value })}
                placeholder="Ej: IQF-03"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Tipo de Máquina</Label>
              <Select
                value={newMachine.type}
                onValueChange={(value) => setNewMachine({ ...newMachine, type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="IQF">IQF</SelectItem>
                  <SelectItem value="CALIBRADO">CALIBRADO</SelectItem>
                  <SelectItem value="EMPAQUE">EMPAQUE</SelectItem>
                  <SelectItem value="CORTE">CORTE</SelectItem>
                  <SelectItem value="PROCESO">PROCESO</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="line">Línea de Producción</Label>
              <Input
                id="line"
                type="number"
                value={newMachine.line}
                onChange={(e) =>
                  setNewMachine({ ...newMachine, line: parseInt(e.target.value) || 1 })
                }
                min="1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="speed">Velocidad (kg/h)</Label>
              <Input
                id="speed"
                type="number"
                value={newMachine.speed}
                onChange={(e) =>
                  setNewMachine({ ...newMachine, speed: parseInt(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="efficiency">Eficiencia (%)</Label>
              <Input
                id="efficiency"
                type="number"
                value={newMachine.efficiency}
                onChange={(e) =>
                  setNewMachine({ ...newMachine, efficiency: parseInt(e.target.value) })
                }
                min="0"
                max="100"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="workingHours">Horas de Trabajo</Label>
              <Input
                id="workingHours"
                type="number"
                value={newMachine.workingHours}
                onChange={(e) =>
                  setNewMachine({ ...newMachine, workingHours: parseInt(e.target.value) })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddMachine} disabled={!newMachine.name}>
              Agregar Máquina
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showAddLineDialog} onOpenChange={setShowAddLineDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Agregar Nueva Línea de Producción</DialogTitle>
            <DialogDescription>
              Crea una nueva línea de producción con un nombre personalizado
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="lineNumber">Número de Línea</Label>
              <Input id="lineNumber" type="number" value={newLineNumber} disabled />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lineName">Nombre de la Línea</Label>
              <Input
                id="lineName"
                value={newLineName}
                onChange={(e) => setNewLineName(e.target.value)}
                placeholder="Ej: Proceso Especial"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddLineDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddLine} disabled={!newLineName}>
              Crear Línea
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showAddFlowDialog} onOpenChange={setShowAddFlowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Agregar Línea de Flujo</DialogTitle>
            <DialogDescription>
              Conecta dos nodos para crear un flujo de producción
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="from">Desde</Label>
              <Select
                value={newFlowLine.from}
                onValueChange={(value) => setNewFlowLine({ ...newFlowLine, from: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona origen" />
                </SelectTrigger>
                <SelectContent>
                  {allNodes.map((node) => (
                    <SelectItem key={node.id} value={node.id}>
                      {node.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="to">Hacia</Label>
              <Select
                value={newFlowLine.to}
                onValueChange={(value) => setNewFlowLine({ ...newFlowLine, to: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona destino" />
                </SelectTrigger>
                <SelectContent>
                  {allNodes.map((node) => (
                    <SelectItem key={node.id} value={node.id}>
                      {node.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddFlowDialog(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleAddFlowLine}
              disabled={!newFlowLine.from || !newFlowLine.to}
            >
              Agregar Flujo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Máquina</DialogTitle>
            <DialogDescription>Modifica los parámetros de la máquina</DialogDescription>
          </DialogHeader>
          {selectedMachine && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">Nombre de la Máquina</Label>
                <Input
                  id="edit-name"
                  value={selectedMachine.name}
                  onChange={(e) =>
                    setSelectedMachine({ ...selectedMachine, name: e.target.value })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-speed">Velocidad (kg/h)</Label>
                <Input
                  id="edit-speed"
                  type="number"
                  value={selectedMachine.parameters.speed}
                  onChange={(e) =>
                    setSelectedMachine({
                      ...selectedMachine,
                      parameters: {
                        ...selectedMachine.parameters,
                        speed: parseInt(e.target.value),
                      },
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-efficiency">Eficiencia (%)</Label>
                <Input
                  id="edit-efficiency"
                  type="number"
                  value={selectedMachine.parameters.efficiency}
                  onChange={(e) =>
                    setSelectedMachine({
                      ...selectedMachine,
                      parameters: {
                        ...selectedMachine.parameters,
                        efficiency: parseInt(e.target.value),
                      },
                    })
                  }
                  min="0"
                  max="100"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-workingHours">Horas de Trabajo</Label>
                <Input
                  id="edit-workingHours"
                  type="number"
                  value={selectedMachine.parameters.workingHours}
                  onChange={(e) =>
                    setSelectedMachine({
                      ...selectedMachine,
                      parameters: {
                        ...selectedMachine.parameters,
                        workingHours: parseInt(e.target.value),
                      },
                    })
                  }
                />
              </div>
              <div className="flex items-center justify-between p-4 bg-muted rounded">
                <Label htmlFor="edit-active">Estado de la Máquina</Label>
                <Switch
                  id="edit-active"
                  checked={selectedMachine.active}
                  onCheckedChange={(checked) =>
                    setSelectedMachine({ ...selectedMachine, active: checked })
                  }
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleEditMachine}>Guardar Cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditNodeDialog} onOpenChange={setShowEditNodeDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Nodo</DialogTitle>
            <DialogDescription>Modifica los parámetros del nodo</DialogDescription>
          </DialogHeader>
          {selectedNode && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-node-name">Nombre del Nodo</Label>
                <Input
                  id="edit-node-name"
                  value={selectedNode.name}
                  onChange={(e) =>
                    setSelectedNode({ ...selectedNode, name: e.target.value })
                  }
                />
              </div>
              {selectedNode.capacity !== undefined && (
                <div className="space-y-2">
                  <Label htmlFor="edit-capacity">Capacidad (kg)</Label>
                  <Input
                    id="edit-capacity"
                    type="number"
                    value={selectedNode.capacity}
                    onChange={(e) =>
                      setSelectedNode({
                        ...selectedNode,
                        capacity: parseInt(e.target.value),
                      })
                    }
                  />
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditNodeDialog(false)}>
              Cancelar
            </Button>
            <Button onClick={handleEditNode}>Guardar Cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}