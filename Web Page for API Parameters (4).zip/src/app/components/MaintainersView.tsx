import React, { useState } from "react";
import { 
  Users, 
  Shield, 
  Lock, 
  Globe, 
  Database, 
  Zap, 
  FileJson, 
  RefreshCw,
  Plus,
  Mail,
  UserCheck,
  UserX,
  Binary,
  Target,
  Settings2
} from "lucide-react";

export function MaintainersView() {
  const [activeTab, setActiveTab] = useState<"staff" | "params">("staff");

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex border-b border-slate-800">
        <button 
          onClick={() => setActiveTab("staff")}
          className={`px-6 py-3 text-sm font-medium transition-all relative ${
            activeTab === "staff" ? "text-orange-500" : "text-slate-500 hover:text-slate-300"
          }`}
        >
          Gestión de Personal
          {activeTab === "staff" && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-orange-500" />}
        </button>
        <button 
          onClick={() => setActiveTab("params")}
          className={`px-6 py-3 text-sm font-medium transition-all relative ${
            activeTab === "params" ? "text-orange-500" : "text-slate-500 hover:text-slate-300"
          }`}
        >
          Parámetros del Modelo
          {activeTab === "params" && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-orange-500" />}
        </button>
      </div>

      {activeTab === "staff" ? <StaffSection /> : <ParamsSection />}
    </div>
  );
}

function StaffSection() {
  const staff = [
    { name: "Juan Pérez", role: "Mantenedor Senior", email: "j.perez@planta.com", status: "Active", lines: ["Línea 1", "Línea 2"] },
    { name: "Marta Gómez", role: "Ingeniero de Procesos", email: "m.gomez@planta.com", status: "Active", lines: ["Línea 1"] },
    { name: "Carlos Ruiz", role: "Técnico IQF", email: "c.ruiz@planta.com", status: "Inactive", lines: ["Línea 1"] },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-white font-semibold">Usuarios y Permisos</h3>
        <button className="flex items-center gap-2 bg-slate-800 text-white rounded-lg px-4 py-2 text-sm font-medium hover:bg-slate-700 transition-all">
          <Plus className="w-4 h-4" />
          Nuevo Usuario
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {staff.map((p) => (
          <div key={p.email} className="bg-[#12121a] border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
                <Users className="w-6 h-6" />
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                p.status === "Active" ? "bg-green-500/10 text-green-500" : "bg-slate-500/10 text-slate-500"
              }`}>
                {p.status}
              </span>
            </div>
            <h4 className="text-white font-bold">{p.name}</h4>
            <p className="text-xs text-slate-500 mb-4">{p.role}</p>
            
            <div className="space-y-2 mb-6">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Mail className="w-3.5 h-3.5" />
                {p.email}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Shield className="w-3.5 h-3.5" />
                {p.lines.join(", ")}
              </div>
            </div>

            <div className="flex gap-2">
              <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-white py-2 rounded text-xs font-medium transition-all">Editar</button>
              <button className="p-2 border border-slate-800 hover:bg-slate-800 text-slate-400 rounded transition-all">
                <Lock className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ParamsSection() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="space-y-6">
        <h3 className="text-white font-semibold flex items-center gap-2">
          <Binary className="w-5 h-5 text-orange-500" />
          Configuración MILP
        </h3>
        <div className="bg-[#12121a] border border-slate-800 rounded-xl p-6 space-y-6">
          <ParamInput 
            label="Objetivo de Optimización" 
            description="Métrica principal que el modelo intentará maximizar."
            defaultValue="Maximizar Kg Salida"
          />
          <ParamInput 
            label="Tiempo Límite (Solver)" 
            description="Tiempo máximo en segundos para encontrar una solución factible."
            defaultValue="300s"
          />
          <ParamInput 
            label="Gap de Optimalidad" 
            description="Diferencia porcentual aceptable entre la solución y el óptimo teórico."
            defaultValue="0.05%"
          />
          <div className="pt-4 flex items-center gap-4">
             <button className="flex-1 bg-orange-500 text-white py-2 rounded-lg font-bold text-sm hover:bg-orange-600 transition-all">Guardar Configuración</button>
             <button className="p-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700 transition-all">
                <RefreshCw className="w-5 h-5" />
             </button>
          </div>
        </div>

        <div className="bg-orange-500/5 border border-orange-500/20 rounded-xl p-6">
          <h4 className="text-orange-500 font-bold text-sm mb-2 flex items-center gap-2">
            <Target className="w-4 h-4" />
            Políticas Operativas
          </h4>
          <ul className="space-y-3">
            {[
              "Priorizar productos perecederos (Vencimiento < 24h)",
              "Minimizar cambios de formato en Línea 2",
              "Respetar horas de descanso de mantenedores",
              "Evitar arranques de máquinas en horario punta"
            ].map((p, i) => (
              <li key={i} className="flex items-start gap-3 text-xs text-slate-400">
                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-1" />
                {p}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="space-y-6">
        <h3 className="text-white font-semibold flex items-center gap-2">
          <Database className="w-5 h-5 text-blue-500" />
          Integraciones ERP / API
        </h3>
        <div className="bg-[#12121a] border border-slate-800 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between p-4 bg-slate-900/50 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500">
                <Globe className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">SAP S/4HANA</p>
                <p className="text-xs text-green-500 flex items-center gap-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500" /> Sincronizado
                </p>
              </div>
            </div>
            <button className="text-xs text-slate-400 hover:text-white flex items-center gap-1">
              Logs <Settings2 className="w-3 h-3" />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 bg-slate-900/50 border border-slate-800 rounded-lg opacity-60">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center text-slate-400">
                <FileJson className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">WMS Interno (API)</p>
                <p className="text-xs text-slate-500">Desconectado</p>
              </div>
            </div>
            <button className="text-xs text-orange-500 hover:text-orange-400 font-bold">Conectar</button>
          </div>

          <div className="p-4 bg-slate-800/30 rounded-lg border border-slate-800">
            <div className="flex justify-between items-center mb-4">
               <span className="text-xs font-bold text-slate-400 uppercase">Estado de Datos Maestro</span>
               <span className="text-[10px] text-slate-500 italic">Última actualización: hace 12 min</span>
            </div>
            <div className="space-y-2">
              <SyncProgress label="Productos" progress={100} />
              <SyncProgress label="Inventarios" progress={85} />
              <SyncProgress label="Órdenes de Trabajo" progress={40} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ParamInput({ label, description, defaultValue }: any) {
  return (
    <div className="space-y-1.5">
      <label className="text-sm font-bold text-white">{label}</label>
      <p className="text-[11px] text-slate-500 leading-tight">{description}</p>
      <input 
        type="text" 
        defaultValue={defaultValue}
        className="w-full bg-slate-900/50 border border-slate-800 rounded-lg py-2 px-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500"
      />
    </div>
  );
}

function SyncProgress({ label, progress }: any) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-[10px]">
        <span className="text-slate-400">{label}</span>
        <span className="text-white">{progress}%</span>
      </div>
      <div className="h-1 bg-slate-900 rounded-full overflow-hidden">
        <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${progress}%` }} />
      </div>
    </div>
  );
}
