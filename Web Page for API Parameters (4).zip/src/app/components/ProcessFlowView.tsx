import { MapIcon, Layers, ArrowRight, Database, Package, AlertTriangle, Info, Settings, Eye, Maximize2, Move } from "lucide-react";
import { SectionHeader } from "./SectionHeader";
import { AnnotationBadge } from "./AnnotationBadge";
import { ButtonWithTooltip } from "./ButtonWithTooltip";
import { AddMachineToCanvas } from "./AddMachineToCanvas";
import { FlowCreationMode } from "./FlowCreationMode";
import { EngineStatusPanel } from "./EngineStatusPanel";
import { useState } from "react";

interface ProcessNode {
  id: string;
  type: "inventory" | "machine" | "sink";
  name: string;
  x: number;
  y: number;
  capacity?: number;
  lineColor?: string;
  status?: string;
}

interface ProcessFlow {
  from: string;
  to: string;
  capacity: number;
  isBottleneck?: boolean;
}

type ViewMode = "topology" | "byline" | "bottlenecks";

export function ProcessFlowView() {
  const [selectedNode, setSelectedNode] = useState<ProcessNode | null>(null);
  const [showSidebar, setShowSidebar] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>("topology");
  const [moveMode, setMoveMode] = useState(false);
  const [nodes, setNodes] = useState<ProcessNode[]>([
    { id: "inv-1", type: "inventory", name: "Inventario Entrada\n(Fruta Fresca)", x: 100, y: 250 },
    { id: "m1", type: "machine", name: "Pre-Cooler A", x: 300, y: 150, capacity: 3000, lineColor: "#f97316", status: "Operativa" },
    { id: "m2", type: "machine", name: "IQF Tunnel 01", x: 300, y: 350, capacity: 2500, lineColor: "#f97316", status: "Operativa" },
    { id: "m3", type: "machine", name: "Sorter X1", x: 550, y: 200, capacity: 4000, lineColor: "#3b82f6", status: "Operativa" },
    { id: "m4", type: "machine", name: "Packer 500", x: 550, y: 350, capacity: 1500, lineColor: "#3b82f6", status: "Operativa" },
    { id: "sink-1", type: "sink", name: "Producción\nFinal", x: 750, y: 275 }
  ]);
  const [flows, setFlows] = useState<ProcessFlow[]>([
    { from: "inv-1", to: "m1", capacity: 3000 },
    { from: "inv-1", to: "m2", capacity: 2500 },
    { from: "m1", to: "m3", capacity: 3000 },
    { from: "m2", to: "m3", capacity: 2500, isBottleneck: true },
    { from: "m3", to: "m4", capacity: 1500, isBottleneck: true },
    { from: "m4", to: "sink-1", capacity: 1500 }
  ]);

  const handleAddMachine = (profile: { id: string; name: string; capacity: number }) => {
    const newNode: ProcessNode = {
      id: `m${Date.now()}`,
      type: "machine",
      name: profile.name,
      x: 400,
      y: 250,
      capacity: profile.capacity,
      lineColor: "#f97316",
      status: "Pendiente de conexión"
    };
    setNodes([...nodes, newNode]);
  };

  const handleAddFlow = (fromId: string, toId: string) => {
    const fromNode = nodes.find(n => n.id === fromId);
    const toNode = nodes.find(n => n.id === toId);
    
    if (!fromNode || !toNode) return;
    
    // Check if flow already exists
    const exists = flows.some(f => f.from === fromId && f.to === toId);
    if (exists) return;
    
    const newFlow: ProcessFlow = {
      from: fromId,
      to: toId,
      capacity: fromNode.capacity || 2000,
      isBottleneck: false
    };
    
    setFlows([...flows, newFlow]);
  };

  const handleNodeClick = (node: ProcessNode) => {
    setSelectedNode(node);
    setShowSidebar(true);
  };

  const getNodeIcon = (type: ProcessNode["type"]) => {
    switch (type) {
      case "inventory": return Database;
      case "machine": return Package;
      case "sink": return Layers;
    }
  };

  const getNodeColor = (type: ProcessNode["type"]) => {
    switch (type) {
      case "inventory": return "#3b82f6";
      case "machine": return "#f97316";
      case "sink": return "#10b981";
    }
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto">
      <SectionHeader
        icon={MapIcon}
        title="Plano del Proceso Productivo"
        subtitle="Diagrama de flujo 2D - Representación visual del modelo matemático"
        badge="VISUAL MODEL"
      >
        <div className="flex items-center gap-2">
          {/* View Mode Selector */}
          <div className="flex items-center gap-1 bg-slate-900/50 rounded-lg p-1 border border-slate-800">
            <ButtonWithTooltip
              icon={Eye}
              label="Topología"
              tooltip="Vista completa del diagrama de flujo mostrando todas las conexiones entre nodos. Estado visual del plano – no interactivo."
              state={viewMode === "topology" ? "active" : "normal"}
              variant="ghost"
              onClick={() => setViewMode("topology")}
              size="sm"
            />
            <ButtonWithTooltip
              icon={Layers}
              label="Por Línea"
              tooltip="Agrupa visualmente los nodos por línea de producción. Los colores destacan la separación jerárquica."
              state={viewMode === "byline" ? "active" : "normal"}
              variant="ghost"
              onClick={() => setViewMode("byline")}
              size="sm"
            />
            <ButtonWithTooltip
              icon={AlertTriangle}
              label="Cuellos de Botella"
              tooltip="Destaca únicamente los flujos que presentan cuellos de botella detectados automáticamente por el modelo."
              state={viewMode === "bottlenecks" ? "active" : "normal"}
              variant="ghost"
              onClick={() => setViewMode("bottlenecks")}
              size="sm"
            />
          </div>

          <ButtonWithTooltip
            icon={Move}
            label="Modo Mover"
            tooltip="Activa el modo de movimiento de nodos. Permite reposicionar libremente los nodos en la rejilla para definir la topología visual."
            state={moveMode ? "active" : "normal"}
            variant="ghost"
            onClick={() => setMoveMode(!moveMode)}
            size="sm"
          />

          <ButtonWithTooltip
            icon={Maximize2}
            label="Pantalla Completa"
            tooltip="Expande el plano del proceso a pantalla completa para mejor visualización de sistemas complejos."
            state="normal"
            variant="ghost"
            size="sm"
          />
        </div>
      </SectionHeader>

      {/* Modo Mover Notification */}
      {moveMode && (
        <div className="mb-4 bg-blue-600/10 border border-blue-600/30 rounded-lg p-4">
          <p className="text-sm text-blue-400 flex items-center gap-2">
            <Move className="w-4 h-4" />
            <strong>Modo ejemplo:</strong> Los nodos pueden moverse libremente para definir la topología del proceso. La rejilla de alineación se activa automáticamente.
          </p>
        </div>
      )}

      <AnnotationBadge type="info" className="mb-8">
        <strong>Modelo visual:</strong> Este diagrama representa la topología del proceso productivo. 
        Cada nodo es una variable de decisión del MILP, cada flecha es una restricción de flujo. 
        Los cuellos de botella se detectan automáticamente según las capacidades relativas.
      </AnnotationBadge>
      
      {/* Extended annotation for node movement */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <AnnotationBadge type="success">
          <strong>🖱️ Movimiento de nodos:</strong> Los nodos pueden reorganizarse libremente en el canvas. 
          El sistema muestra rejilla de alineación, cursor de arrastre y etiqueta visual "Nodo movido" 
          durante la interacción para definir la topología del proceso.
        </AnnotationBadge>

        <AnnotationBadge type="warning">
          <strong>⚙️ Agregar máquinas:</strong> Las máquinas pueden insertarse desde perfiles predefinidos 
          con vista previa del nodo. Una vez agregadas, están disponibles para conectar con flujos en el diagrama.
        </AnnotationBadge>
      </div>

      {/* Canvas & Sidebar Layout */}
      <div className="flex gap-6">
        {/* Main Canvas */}
        <div className="flex-1 bg-[#1a1a24] border border-slate-800 rounded-lg overflow-hidden">
          {/* Canvas Toolbar */}
          <div className="px-4 py-3 bg-[#12121a] border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <span className="text-xs text-slate-400 font-mono">VISTA: Topología del Proceso</span>
              <div className="h-4 w-[1px] bg-slate-800" />
              <div className="flex items-center gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-blue-600" />
                  <span className="text-slate-400">Inventario</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-orange-600" />
                  <span className="text-slate-400">Máquina</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-green-600" />
                  <span className="text-slate-400">Salida</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>2 cuellos de botella detectados</span>
            </div>
          </div>

          {/* SVG Canvas */}
          <div className="relative bg-[#0a0a0f] p-8" style={{ minHeight: "600px" }}>
            {/* Add Machine and Flow Creation Tools - Positioned at top */}
            <div className="absolute top-4 left-4 z-10 flex gap-2">
              <AddMachineToCanvas onAdd={handleAddMachine} />
              <FlowCreationMode onAdd={handleAddFlow} />
            </div>

            <svg width="900" height="600" className="mx-auto">
              {/* Grid Pattern */}
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1a1a24" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="900" height="600" fill="url(#grid)" />

              {/* Flows (Arrows) */}
              {flows.map((flow, idx) => {
                const fromNode = nodes.find(n => n.id === flow.from);
                const toNode = nodes.find(n => n.id === flow.to);
                if (!fromNode || !toNode) return null;

                const isBottleneck = flow.isBottleneck;

                return (
                  <g key={idx}>
                    <line
                      x1={fromNode.x + 60}
                      y1={fromNode.y + 30}
                      x2={toNode.x}
                      y2={toNode.y + 30}
                      stroke={isBottleneck ? "#f59e0b" : "#475569"}
                      strokeWidth={isBottleneck ? "3" : "2"}
                      strokeDasharray={isBottleneck ? "5,5" : "none"}
                      markerEnd="url(#arrowhead)"
                    />
                    {/* Flow Label */}
                    <text
                      x={(fromNode.x + toNode.x) / 2 + 30}
                      y={(fromNode.y + toNode.y) / 2 + 20}
                      fill="#94a3b8"
                      fontSize="11"
                      fontFamily="monospace"
                    >
                      {flow.capacity} kg/h
                    </text>
                    {isBottleneck && (
                      <text
                        x={(fromNode.x + toNode.x) / 2 + 30}
                        y={(fromNode.y + toNode.y) / 2 + 35}
                        fill="#f59e0b"
                        fontSize="10"
                        fontFamily="monospace"
                      >
                        ⚠ Cuello de botella
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Arrow Marker */}
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="10"
                  markerHeight="10"
                  refX="9"
                  refY="3"
                  orient="auto"
                >
                  <polygon points="0 0, 10 3, 0 6" fill="#475569" />
                </marker>
              </defs>

              {/* Nodes */}
              {nodes.map((node) => {
                const Icon = getNodeIcon(node.type);
                const color = getNodeColor(node.type);
                const isSelected = selectedNode?.id === node.id;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    onClick={() => handleNodeClick(node)}
                    style={{ cursor: "pointer" }}
                  >
                    {/* Node Background */}
                    <rect
                      width="120"
                      height="60"
                      rx="8"
                      fill="#1a1a24"
                      stroke={isSelected ? color : "#2a2a35"}
                      strokeWidth={isSelected ? "3" : "2"}
                    />

                    {/* Node Icon */}
                    <circle cx="20" cy="30" r="12" fill={color} opacity="0.2" />
                    <foreignObject x="8" y="18" width="24" height="24">
                      <div className="w-6 h-6 flex items-center justify-center">
                        <Icon style={{ width: "16px", height: "16px", color }} />
                      </div>
                    </foreignObject>

                    {/* Node Text */}
                    <text
                      x="45"
                      y="28"
                      fill="#ffffff"
                      fontSize="11"
                      fontWeight="600"
                      fontFamily="system-ui"
                    >
                      {node.name.split('\n')[0]}
                    </text>
                    {node.name.includes('\n') && (
                      <text
                        x="45"
                        y="42"
                        fill="#94a3b8"
                        fontSize="10"
                        fontFamily="system-ui"
                      >
                        {node.name.split('\n')[1]}
                      </text>
                    )}

                    {/* Capacity Badge */}
                    {node.capacity && (
                      <text
                        x="60"
                        y="54"
                        fill="#64748b"
                        fontSize="9"
                        fontFamily="monospace"
                        textAnchor="middle"
                      >
                        {node.capacity} kg/h
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>

            {/* Click Instructions */}
            <div className="absolute bottom-4 left-4 bg-slate-900/90 border border-slate-800 rounded-lg px-4 py-3 text-xs text-slate-400">
              <p className="flex items-center gap-2">
                <Info className="w-4 h-4" />
                Haz clic en cualquier nodo para ver su configuración en el panel lateral
              </p>
            </div>
          </div>
        </div>

        {/* Configuration Sidebar */}
        {showSidebar && selectedNode && (
          <div className="w-80 bg-[#1a1a24] border border-slate-800 rounded-lg overflow-hidden flex-shrink-0">
            <div className="px-4 py-3 bg-[#12121a] border-b border-slate-800 flex items-center justify-between">
              <h3 className="font-semibold text-white text-sm">Configuración del Nodo</h3>
              <button
                onClick={() => setShowSidebar(false)}
                className="p-1 hover:bg-slate-800 rounded text-slate-400"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Node Info */}
              <div>
                <label className="text-xs text-slate-400 uppercase tracking-wider mb-2 block">
                  Nombre del Nodo
                </label>
                <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-white">
                  {selectedNode.name.replace('\n', ' ')}
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 uppercase tracking-wider mb-2 block">
                  Tipo de Entidad
                </label>
                <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-white">
                  {selectedNode.type === "inventory" && "Inventario (Fuente)"}
                  {selectedNode.type === "machine" && "Máquina (Procesamiento)"}
                  {selectedNode.type === "sink" && "Sumidero (Salida)"}
                </div>
              </div>

              {selectedNode.capacity && (
                <div>
                  <label className="text-xs text-slate-400 uppercase tracking-wider mb-2 block">
                    Capacidad Nominal
                  </label>
                  <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-white flex items-center justify-between">
                    <span>{selectedNode.capacity.toLocaleString()} kg/h</span>
                    <span className="text-xs text-slate-500">Modelo MILP</span>
                  </div>
                </div>
              )}

              {selectedNode.lineColor && (
                <div>
                  <label className="text-xs text-slate-400 uppercase tracking-wider mb-2 block">
                    Línea de Producción
                  </label>
                  <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm flex items-center gap-2">
                    <div
                      className="w-4 h-4 rounded"
                      style={{ backgroundColor: selectedNode.lineColor }}
                    />
                    <span className="text-white">
                      {selectedNode.lineColor === "#f97316" ? "Línea 1 (IQF)" : "Línea 2 (Calibrado)"}
                    </span>
                  </div>
                </div>
              )}

              {selectedNode.status && (
                <div>
                  <label className="text-xs text-slate-400 uppercase tracking-wider mb-2 block">
                    Estado Operativo
                  </label>
                  <div className="bg-green-600/20 border border-green-600/30 rounded px-3 py-2 text-sm text-green-400 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    {selectedNode.status}
                  </div>
                </div>
              )}

              {/* Restriction Info */}
              <div className="pt-4 border-t border-slate-800">
                <AnnotationBadge type="info">
                  Este parámetro se configura en esta vista y afecta directamente las restricciones del modelo MILP.
                </AnnotationBadge>
              </div>

              {/* Mock Edit Button */}
              <button className="w-full px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm transition-colors flex items-center justify-center gap-2">
                <Settings className="w-4 h-4" />
                Configurar Parámetros (Mock)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer Annotations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <AnnotationBadge type="warning">
          <strong>Detección automática:</strong> Los cuellos de botella se identifican cuando 
          <code className="mx-1 px-2 py-0.5 bg-slate-900 rounded text-xs">Σ flujo_entrada &gt; capacidad_salida</code>. 
          El modelo prioriza estos nodos en la optimización.
        </AnnotationBadge>

        <AnnotationBadge type="success">
          <strong>Interactividad:</strong> Los cambios en este diagrama (agregar/quitar nodos, modificar flujos) 
          regeneran automáticamente la matriz de restricciones del MILP y actualizan las variables de decisión.
        </AnnotationBadge>
      </div>

      {/* Engine Status Panel - Movable */}
      <EngineStatusPanel initialPosition="bottom-left" />
    </div>
  );
}