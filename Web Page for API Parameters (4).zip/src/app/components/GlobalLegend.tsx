import { CheckCircle, AlertTriangle, XCircle, Database, Info } from "lucide-react";

export function GlobalLegend() {
  const legendItems = [
    {
      icon: CheckCircle,
      color: "text-green-400",
      bgColor: "bg-green-600/20",
      label: "Factible",
      description: "Sin violaciones de restricciones"
    },
    {
      icon: AlertTriangle,
      color: "text-amber-400",
      bgColor: "bg-amber-600/20",
      label: "Advertencia",
      description: "Requiere revisión o ajuste"
    },
    {
      icon: XCircle,
      color: "text-red-400",
      bgColor: "bg-red-600/20",
      label: "No Factible",
      description: "Restricción violada - Bloquea ejecución"
    },
    {
      icon: Database,
      color: "text-blue-400",
      bgColor: "bg-blue-600/20",
      label: "Datos ERP",
      description: "Proveniente de SAP (sincronizado)"
    },
    {
      icon: Info,
      color: "text-orange-400",
      bgColor: "bg-orange-600/20",
      label: "Modelo MILP",
      description: "Calculado por el optimizador"
    }
  ];

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 max-w-5xl">
      <div className="bg-[#12121a]/95 backdrop-blur-xl border border-slate-800 rounded-lg shadow-2xl">
        <div className="px-4 py-2 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-orange-500" />
            <span className="text-xs font-semibold text-white uppercase tracking-wider">
              Leyenda de Estados del Sistema
            </span>
          </div>
          <span className="text-xs text-slate-500 font-mono">Blueprint Mode</span>
        </div>
        <div className="px-4 py-3 flex items-center gap-4">
          {legendItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="flex items-center gap-2 px-3 py-1.5 bg-slate-900/50 rounded-lg border border-slate-800">
                <div className={`w-6 h-6 ${item.bgColor} rounded flex items-center justify-center`}>
                  <Icon className={`w-3 h-3 ${item.color}`} />
                </div>
                <div>
                  <p className={`text-xs font-semibold ${item.color}`}>{item.label}</p>
                  <p className="text-[10px] text-slate-500 leading-tight max-w-[140px]">{item.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
