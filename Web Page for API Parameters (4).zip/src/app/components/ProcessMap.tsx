import React, { useState, useEffect, useRef, useMemo } from "react";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Plus, 
  Trash2, 
  Database, 
  Cpu, 
  Trash, 
  ArrowRight,
  Clock,
  Settings,
  Info,
  ChevronRight,
  ChevronLeft,
  Search,
  Zap,
  Box,
  Layers,
  CheckCircle2,
  AlertTriangle,
  GripHorizontal
} from "lucide-react";
import { toast } from "sonner";
import { Machine, Line } from "@/app/App";

interface ProcessMapProps {
  machines: Machine[];
  lines: Line[];
}

interface Node {
  id: string;
  type: "inventory" | "machine" | "sink";
  name: string;
  x: number;
  y: number;
  machineId?: string;
  capacity?: number;
  inventory?: number;
}

interface Connection {
  id: string;
  from: string;
  to: string;
}

export function ProcessMap({ machines, lines }: ProcessMapProps) {
  const [nodes, setNodes] = useState<Node[]>([
    { id: "inv-1", type: "inventory", name: "Inventario Inicial", x: 150, y: 350, inventory: 15000 },
    { id: "node-m1", type: "machine", name: "IQF Tunnel 01", x: 450, y: 250, machineId: "m-1", capacity: 2500 },
    { id: "node-m3", type: "machine", name: "Sorter Optical X1", x: 750, y: 350, machineId: "m-3", capacity: 4000 },
    { id: "sink-1", type: "sink", name: "Producto Final", x: 1050, y: 350, inventory: 0 },
  ]);

  const [connections, setConnections] = useState<Connection[]>([
    { id: "c1", from: "inv-1", to: "node-m1" },
    { id: "c2", from: "node-m1", to: "node-m3" },
    { id: "c3", from: "node-m3", to: "sink-1" },
  ]);

  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [dragNodeId, setDragNodeId] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simTime, setSimTime] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);

  const selectedNode = useMemo(() => nodes.find(n => n.id === selectedNodeId), [nodes, selectedNodeId]);
  const selectedMachine = useMemo(() => machines.find(m => m.id === selectedNode?.machineId), [machines, selectedNode]);

  const handleMouseDown = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDragNodeId(id);
    setSelectedNodeId(id);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (dragNodeId && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      setNodes(prev => prev.map(n => n.id === dragNodeId ? { ...n, x, y } : n));
    }
  };

  const handleMouseUp = () => setDragNodeId(null);

  const addMachineToMap = (machine: Machine) => {
    if (nodes.find(n => n.machineId === machine.id)) {
      toast.error("Esta máquina ya existe en el plano");
      return;
    }
    const newNode: Node = {
      id: `node-${machine.id}`,
      type: "machine",
      name: machine.name,
      machineId: machine.id,
      x: 500,
      y: 350,
      capacity: machine.capacity
    };
    setNodes([...nodes, newNode]);
    toast.success(`${machine.name} añadida al plano`);
  };

  return (
    <div className="flex h-full overflow-hidden">
      {/* Sidebar Izquierda: Elementos Disponibles */}
      <aside className={`w-72 bg-[#12121a] border-r border-slate-800 flex flex-col transition-all ${isSidebarOpen ? "translate-x-0" : "-translate-x-full absolute z-50"}`}>
        <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
           <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Activos Disponibles</h4>
           <button onClick={() => setIsSidebarOpen(false)} className="text-slate-500 hover:text-white lg:hidden">
              <ChevronLeft className="w-4 h-4" />
           </button>
        </div>
        
        <div className="p-4 space-y-4 overflow-y-auto flex-1">
           <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input type="text" placeholder="Buscar máquina..." className="w-full bg-slate-900 border border-slate-800 rounded-lg py-2 pl-9 pr-3 text-xs text-slate-300" />
           </div>

           {lines.map(line => (
             <div key={line.id} className="space-y-2">
                <p className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">{line.name}</p>
                <div className="space-y-1">
                   {machines.filter(m => m.lineId === line.id).map(m => (
                     <button 
                      key={m.id}
                      onClick={() => addMachineToMap(m)}
                      className="w-full flex items-center justify-between p-2 rounded-lg bg-slate-800/50 hover:bg-orange-600 hover:text-white transition-all group border border-slate-800"
                     >
                        <div className="flex items-center gap-2">
                           <Cpu className="w-3.5 h-3.5 text-orange-500 group-hover:text-white" />
                           <span className="text-xs font-medium">{m.name}</span>
                        </div>
                        <Plus className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100" />
                     </button>
                   ))}
                </div>
             </div>
           ))}

           <div className="pt-4 border-t border-slate-800">
              <p className="text-[10px] font-bold text-slate-600 uppercase tracking-wider mb-2">Nodos de Sistema</p>
              <div className="grid grid-cols-2 gap-2">
                 <button className="flex flex-col items-center gap-2 p-3 bg-slate-800/50 border border-slate-800 rounded-xl hover:border-blue-500/50 transition-all">
                    <Database className="w-6 h-6 text-blue-500" />
                    <span className="text-[10px] font-bold">INVENTARIO</span>
                 </button>
                 <button className="flex flex-col items-center gap-2 p-3 bg-slate-800/50 border border-slate-800 rounded-xl hover:border-green-500/50 transition-all">
                    <Trash className="w-6 h-6 text-green-500" />
                    <span className="text-[10px] font-bold">SALIDA</span>
                 </button>
              </div>
           </div>
        </div>
      </aside>

      {/* Canvas Central */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#0a0a0f] relative group">
        {!isSidebarOpen && (
          <button 
            onClick={() => setIsSidebarOpen(true)}
            className="absolute left-4 top-4 z-40 p-2 bg-orange-600 text-white rounded-lg shadow-lg hover:bg-orange-700 transition-all"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        )}

        {/* Toolbar Superior */}
        <div className="h-14 border-b border-slate-800 bg-[#12121a]/50 backdrop-blur-md flex items-center justify-between px-6 z-30">
           <div className="flex items-center gap-4">
              <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-800">
                 <button className="px-3 py-1 text-[10px] font-bold bg-orange-600 text-white rounded-md shadow-lg">DISEÑO</button>
                 <button className="px-3 py-1 text-[10px] font-bold text-slate-500 hover:text-white transition-all">SIMULACIÓN</button>
                 <button className="px-3 py-1 text-[10px] font-bold text-slate-500 hover:text-white transition-all">EJECUCIÓN</button>
              </div>
              <div className="h-4 w-[1px] bg-slate-800" />
              <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full">
                 <CheckCircle2 className="w-3 h-3 text-green-500" />
                 <span className="text-[10px] font-bold text-green-500">MODELO VÁLIDO</span>
              </div>
           </div>

           <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-xs font-mono text-slate-500 mr-4">
                 <Layers className="w-3.5 h-3.5" /> 1:1 SCALE
              </div>
              <button className="p-2 bg-slate-800 text-slate-400 rounded-lg hover:text-white hover:bg-slate-700 transition-all">
                 <RotateCcw className="w-4 h-4" />
              </button>
              <button className="p-2 bg-slate-800 text-slate-400 rounded-lg hover:text-red-500 hover:bg-red-500/10 transition-all">
                 <Trash2 className="w-4 h-4" />
              </button>
              <button className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg text-xs font-bold hover:bg-orange-700 shadow-lg shadow-orange-900/20">
                 <Play className="w-3.5 h-3.5" /> COMPILAR MODELO
              </button>
           </div>
        </div>

        {/* Workspace Canvas */}
        <div 
          ref={containerRef}
          className="flex-1 relative overflow-hidden"
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onClick={() => setSelectedNodeId(null)}
          style={{ 
            backgroundImage: "radial-gradient(#1e293b 0.5px, transparent 0.5px)", 
            backgroundSize: "30px 30px" 
          }}
        >
          {/* SVG para Conexiones */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <defs>
              <marker id="arrow" markerWidth="10" markerHeight="7" refX="22" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#475569" />
              </marker>
            </defs>
            {connections.map(conn => {
              const from = nodes.find(n => n.id === conn.from);
              const to = nodes.find(n => n.id === conn.to);
              if (!from || !to) return null;
              return (
                <line 
                  key={conn.id}
                  x1={from.x} y1={from.y}
                  x2={to.x} y2={to.y}
                  stroke="#475569"
                  strokeWidth="1.5"
                  markerEnd="url(#arrow)"
                />
              );
            })}
          </svg>

          {/* Nodos */}
          {nodes.map(node => {
            const isActive = selectedNodeId === node.id;
            const mData = node.machineId ? machines.find(m => m.id === node.machineId) : null;
            
            return (
              <div 
                key={node.id}
                onMouseDown={(e) => handleMouseDown(node.id, e)}
                className={`absolute flex flex-col items-center gap-2 transition-transform duration-200 ${isActive ? "z-50 scale-110" : "z-40"}`}
                style={{ left: node.x, top: node.y, transform: "translate(-50%, -50%)" }}
              >
                <div className={`relative w-16 h-16 rounded-2xl flex items-center justify-center border-2 transition-all shadow-2xl ${
                  isActive 
                    ? "border-orange-500 bg-orange-600/20 shadow-orange-500/20" 
                    : "border-slate-700 bg-slate-900/90 group-hover:border-slate-600"
                }`}>
                  {node.type === "inventory" && <Database className="w-7 h-7 text-blue-500" />}
                  {node.type === "machine" && <Cpu className="w-7 h-7 text-orange-500" />}
                  {node.type === "sink" && <Box className="w-7 h-7 text-green-500" />}
                  
                  {/* Status Indicator */}
                  {mData && (
                    <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-900 ${
                      mData.status === 'Operativa' ? 'bg-green-500' : mData.status === 'Mantenimiento' ? 'bg-yellow-500' : 'bg-red-500'
                    }`} />
                  )}
                </div>
                
                <div className="text-center px-2 py-1 bg-slate-900/80 backdrop-blur-sm rounded border border-slate-800">
                  <p className="text-[10px] font-bold text-white whitespace-nowrap uppercase tracking-tighter">{node.name}</p>
                  {node.type === "machine" && <p className="text-[8px] text-slate-500 font-mono">{node.capacity} KG/H</p>}
                  {node.inventory !== undefined && <p className="text-[8px] text-blue-400 font-mono">{node.inventory.toLocaleString()} KG</p>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sidebar Derecha: Configuración del Nodo */}
      {selectedNode && (
        <aside className="w-80 bg-[#12121a] border-l border-slate-800 flex flex-col animate-in slide-in-from-right duration-300">
           <div className="p-4 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Configuración del Nodo</h4>
              <button onClick={() => setSelectedNodeId(null)} className="text-slate-500 hover:text-white">
                 <X className="w-4 h-4" />
              </button>
           </div>
           
           <div className="p-6 space-y-6 overflow-y-auto">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 rounded-xl bg-orange-600/10 flex items-center justify-center border border-orange-500/20">
                    {selectedNode.type === "machine" ? <Cpu className="w-6 h-6 text-orange-500" /> : <Database className="w-6 h-6 text-blue-500" />}
                 </div>
                 <div>
                    <h5 className="text-white font-bold">{selectedNode.name}</h5>
                    <p className="text-[10px] text-slate-500 font-mono uppercase">ID: {selectedNode.id}</p>
                 </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-800">
                 <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Parámetros del Modelo</label>
                    <div className="space-y-3">
                       <div className="flex flex-col gap-1.5">
                          <span className="text-xs text-slate-400">Velocidad Nominal (kg/h)</span>
                          <input type="number" defaultValue={selectedNode.capacity} className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500" />
                       </div>
                       <div className="flex flex-col gap-1.5">
                          <span className="text-xs text-slate-400">Factor de Eficiencia</span>
                          <input type="text" defaultValue="0.95" className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-white focus:outline-none focus:ring-1 focus:ring-orange-500" />
                       </div>
                    </div>
                 </div>

                 {selectedMachine && (
                    <div className="space-y-2 pt-4 border-t border-slate-800">
                       <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Productos Permitidos</label>
                       <div className="flex flex-wrap gap-2">
                          {selectedMachine.products.map(p => (
                            <span key={p} className="px-2 py-1 bg-slate-800 text-[10px] text-slate-300 rounded-full border border-slate-700 flex items-center gap-1">
                               {p} <X className="w-2 h-2 cursor-pointer hover:text-red-500" />
                            </span>
                          ))}
                          <button className="px-2 py-1 border border-dashed border-slate-700 text-[10px] text-slate-500 rounded-full hover:border-orange-500 hover:text-orange-500">+ Añadir</button>
                       </div>
                    </div>
                 )}

                 <div className="bg-orange-600/5 border border-orange-500/10 rounded-xl p-4 mt-6">
                    <div className="flex items-center gap-2 mb-2">
                       <AlertTriangle className="w-3.5 h-3.5 text-orange-500" />
                       <span className="text-[10px] font-bold text-orange-500 uppercase">Restricción Activa</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-tight">No procesar productos con humedad mayor al 15% en este nodo debido a mantenimiento preventivo.</p>
                 </div>
              </div>

              <div className="pt-6 mt-auto space-y-3">
                 <button className="w-full py-2.5 bg-orange-600 text-white rounded-lg text-xs font-bold hover:bg-orange-700 transition-all">GUARDAR CAMBIOS</button>
                 <button className="w-full py-2.5 bg-slate-800 text-slate-400 rounded-lg text-xs font-bold hover:text-red-500 transition-all border border-slate-700">DESACOPLAR DEL MODELO</button>
              </div>
           </div>
        </aside>
      )}
    </div>
  );
}
