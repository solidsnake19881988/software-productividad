import { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { ArrowLeft, Search } from 'lucide-react';
import { toast } from 'sonner';

interface DatabasePageProps {
  onBack: () => void;
}

export function DatabasePage({ onBack }: DatabasePageProps) {
  const [startDate, setStartDate] = useState('2026-01-01');
  const [endDate, setEndDate] = useState('2026-01-16');
  const [feedback, setFeedback] = useState('');

  const handleQuery = () => {
    // Aquí se conectaría con la base de datos
    const mockFeedback = `
Consulta ejecutada exitosamente.

Rango de fechas: ${startDate} a ${endDate}

Total de registros encontrados: 157
- Máquinas: 15 registros
- Mantenedores: 8 registros
- Productos: 45 registros
- Optimizaciones: 23 registros
- Operaciones: 66 registros

Última actualización: ${new Date().toLocaleString('es-ES')}
Estado de la conexión: Activa
Tiempo de consulta: 0.342 segundos
    `.trim();

    setFeedback(mockFeedback);
    toast.success('Consulta ejecutada correctamente');
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Base de Datos</h1>
            <p className="text-muted-foreground">
              Consulte datos por rango de fechas
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Consulta de Datos</CardTitle>
            <CardDescription>
              Seleccione el rango de fechas para obtener información de la base de datos
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Fecha Desde</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate">Fecha Hasta</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>
            <Button onClick={handleQuery} className="w-full">
              <Search className="mr-2 h-4 w-4" />
              Consultar Base de Datos
            </Button>
          </CardContent>
        </Card>

        {feedback && (
          <Card>
            <CardHeader>
              <CardTitle>Resultado de la Consulta</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-muted rounded-md p-4">
                <pre className="text-sm whitespace-pre-wrap font-mono">{feedback}</pre>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}