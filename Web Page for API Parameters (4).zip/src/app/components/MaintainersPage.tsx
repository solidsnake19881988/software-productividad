import { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/app/components/ui/table';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';

interface ProductsPageProps {
  onBack: () => void;
}

export default function ProductsPage({ onBack }: ProductsPageProps) {
  // Lista de máquinas disponibles
  const machines = ["Máquina A", "Máquina B", "Máquina C", "Máquina D"];

  // Estado de productos alimenticios
  const [products, setProducts] = useState([
    { id: 1, code: "P001", name: "Pan Integral", machines: ["Máquina A"] },
    { id: 2, code: "P002", name: "Yogur Natural", machines: ["Máquina B"] },
    { id: 3, code: "P003", name: "Jugo de Naranja", machines: ["Máquina C"] },
    { id: 4, code: "P004", name: "Queso Fresco", machines: ["Máquina A", "Máquina D"] },
    { id: 5, code: "P005", name: "Galletas de Avena", machines: [] },
  ]);

  // Agregar producto nuevo
  const addProduct = () => {
    const newId = products.length + 1;
    const newProduct = { id: newId, code: `P00${newId}`, name: "Nuevo Producto", machines: [] };
    setProducts([...products, newProduct]);
  };

  // Eliminar producto
  const deleteProduct = (id: number) => {
    setProducts(products.filter(p => p.id !== id));
  };

  // Actualizar nombre del producto
  const updateName = (id: number, newName: string) => {
    setProducts(products.map(p => p.id === id ? { ...p, name: newName } : p));
  };

  // Actualizar máquina en posición específica
  const updateMachine = (id: number, index: number, newMachine: string) => {
    setProducts(products.map(p =>
      p.id === id
        ? { ...p, machines: p.machines.map((m, i) => i === index ? newMachine : m) }
        : p
    ));
  };

  // Agregar nueva máquina a un producto
  const addMachine = (id: number) => {
    setProducts(products.map(p =>
      p.id === id ? { ...p, machines: [...p.machines, machines[0]] } : p
    ));
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Productos Alimenticios</h1>
            <p className="text-muted-foreground">
              Gestione los productos y las máquinas que los procesan
            </p>
          </div>
          <Button onClick={addProduct}>
            <Plus className="mr-2 h-4 w-4" />
            Nuevo Producto
          </Button>
        </div>

        {/* Tabla de productos */}
        <Card>
          <CardHeader>
            <CardTitle>Lista de Productos</CardTitle>
            <CardDescription>
              Vista detallada de todos los productos del sistema
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Código</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead>Máquinas Asignadas</TableHead>
                  <TableHead className="text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="font-medium">{p.id}</TableCell>
                    <TableCell>{p.code}</TableCell>
                    <TableCell>
                      <input
                        type="text"
                        value={p.name}
                        onChange={(e) => updateName(p.id, e.target.value)}
                        className="border rounded px-2 py-1 w-full"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-2">
                        {p.machines.map((machine, index) => (
                          <select
                            key={index}
                            value={machine}
                            onChange={(e) => updateMachine(p.id, index, e.target.value)}
                            className="border rounded px-2 py-1 w-full"
                          >
                            {machines.map((m) => (
                              <option key={m} value={m}>{m}</option>
                            ))}
                          </select>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => addMachine(p.id)}
                        >
                          + Agregar máquina
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" onClick={() => deleteProduct(p.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}