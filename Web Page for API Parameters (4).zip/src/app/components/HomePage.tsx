import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Database, Settings, Users, LineChart, BarChart3, Network } from 'lucide-react';
import { Button } from '@/app/components/ui/button';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const menuItems = [
    {
      id: 'dashboard',
      title: 'Dashboard',
      description: 'KPIs, gráficos y analíticas',
      icon: BarChart3,
      color: 'text-cyan-600',
      bgColor: 'bg-cyan-50',
    },
    {
      id: 'database',
      title: 'Base de Datos',
      description: 'Acceder a la base de datos del sistema',
      icon: Database,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      id: 'machines',
      title: 'Máquinas',
      description: 'Ver y configurar máquinas del sistema',
      icon: Settings,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      id: 'maintainers',
      title: 'Mantenedores',
      description: 'Gestionar mantenedores del sistema',
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
    },
    {
      id: 'processflow',
      title: 'Plano del Proceso',
      description: 'Visualizar flujo de producción',
      icon: Network,
      color: 'text-pink-600',
      bgColor: 'bg-pink-50',
    },
    {
      id: 'optimization',
      title: 'Modelo de Optimización',
      description: 'Ejecutar y ver resultados del modelo',
      icon: LineChart,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
    },
  ];

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold">Interfaz de Optimización</h1>
          <p className="text-muted-foreground text-lg">
            Seleccione una opción para continuar
          </p>
          <p className="text-sm text-blue-600 font-medium mt-4">
            Fecha Actual: {new Date().toLocaleDateString('es-ES', { 
              year: 'numeric', 
              month: '2-digit', 
              day: '2-digit' 
            })}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Card 
                key={item.id} 
                className="hover:shadow-lg transition-shadow cursor-pointer border-2"
                onClick={() => onNavigate(item.id)}
              >
                <CardHeader className="space-y-4">
                  <div className={`w-16 h-16 rounded-lg ${item.bgColor} flex items-center justify-center mx-auto`}>
                    <Icon className={`w-8 h-8 ${item.color}`} />
                  </div>
                  <CardTitle className="text-center">{item.title}</CardTitle>
                  <CardDescription className="text-center">
                    {item.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center pb-6">
                  <Button 
                    onClick={() => onNavigate(item.id)}
                    className="w-full"
                  >
                    Acceder
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}