import { X, Play, Settings, TrendingUp, CheckCircle } from "lucide-react";
import { useState } from "react";

interface NewSimulationFlowProps {
  isOpen: boolean;
  onClose: () => void;
}

type Step = 1 | 2 | 3;

export function NewSimulationFlow({ isOpen, onClose }: NewSimulationFlowProps) {
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [selectedBase, setSelectedBase] = useState<string | null>(null);
  const [selectedAdjustment, setSelectedAdjustment] = useState<string | null>(null);

  if (!isOpen) return null;

  const bases = [
    { id: "current", name: "Planificación Optimizada Actual", description: "Última optimización ejecutada", status: "Óptimo" },
    { id: "sim-1", name: "Simulación - Escenario Alta Demanda", description: "Creada hace 2 días", status: "Factible" },
    { id: "process", name: "Proceso Actual (Sin optimizar)", description: "Estado manual", status: "Sin validar" }
  ];

  const adjustments = [
    { id: "capacity", name: "Cambio de Capacidad", description: "Modificar capacidad de una o más máquinas", icon: "⚙️" },
    { id: "disable", name: "Desactivación de Máquina", description: "Simular mantenimiento o falla", icon: "🔧" },
    { id: "demand", name: "Cambio de Demanda", description: "Ajustar demanda objetivo de productos", icon: "📈" }
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1a1a24] border border-slate-800 rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white">Nueva Simulación</h3>
            <p className="text-xs text-slate-400 mt-1">Flujo visual en 3 pasos - Blueprint Mode</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Steps */}
        <div className="px-6 py-4 bg-slate-900/30 border-b border-slate-800">
          <div className="flex items-center justify-between max-w-2xl mx-auto">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-colors ${
                    currentStep === step
                      ? "bg-orange-600 text-white"
                      : currentStep > step
                      ? "bg-green-600 text-white"
                      : "bg-slate-800 text-slate-500"
                  }`}>
                    {currentStep > step ? <CheckCircle className="w-5 h-5" /> : step}
                  </div>
                  <p className="text-xs text-slate-400 mt-2 font-medium">
                    {step === 1 && "Base"}
                    {step === 2 && "Ajustes"}
                    {step === 3 && "Resultado"}
                  </p>
                </div>
                {step < 3 && (
                  <div className={`h-[2px] flex-1 mx-2 transition-colors ${
                    currentStep > step ? "bg-green-600" : "bg-slate-800"
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-280px)]">
          {/* Step 1: Base Selection */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="bg-blue-600/10 border border-blue-600/30 rounded-lg p-4 mb-6">
                <p className="text-sm text-blue-400">
                  <strong>Paso 1:</strong> Selecciona la planificación base sobre la cual crearás la simulación
                </p>
              </div>

              <div className="space-y-3">
                {bases.map((base) => (
                  <button
                    key={base.id}
                    onClick={() => setSelectedBase(base.id)}
                    className={`w-full text-left p-4 rounded-lg border transition-all ${
                      selectedBase === base.id
                        ? "bg-orange-600/20 border-orange-600/50"
                        : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="text-sm font-semibold text-white mb-1">{base.name}</h4>
                        <p className="text-xs text-slate-400">{base.description}</p>
                      </div>
                      <span className={`px-2 py-1 text-xs rounded ${
                        base.status === "Óptimo"
                          ? "bg-green-600/20 text-green-400"
                          : base.status === "Factible"
                          ? "bg-blue-600/20 text-blue-400"
                          : "bg-slate-700 text-slate-400"
                      }`}>
                        {base.status}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Adjustments */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div className="bg-blue-600/10 border border-blue-600/30 rounded-lg p-4 mb-6">
                <p className="text-sm text-blue-400">
                  <strong>Paso 2:</strong> Define los ajustes del escenario (qué parámetros cambiarás)
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {adjustments.map((adj) => (
                  <button
                    key={adj.id}
                    onClick={() => setSelectedAdjustment(adj.id)}
                    className={`text-left p-4 rounded-lg border transition-all ${
                      selectedAdjustment === adj.id
                        ? "bg-orange-600/20 border-orange-600/50"
                        : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 bg-slate-800 rounded-lg flex items-center justify-center text-2xl flex-shrink-0">
                        {adj.icon}
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-semibold text-white mb-1">{adj.name}</h4>
                        <p className="text-xs text-slate-400">{adj.description}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {selectedAdjustment && (
                <div className="mt-6 bg-slate-900/50 border border-slate-800 rounded-lg p-4">
                  <p className="text-xs text-slate-400 mb-3 uppercase tracking-wider">Configuración del ajuste:</p>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-2">Parámetro a modificar</label>
                      <div className="bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-slate-500">
                        [Selector - no funcional]
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-2">Nuevo valor</label>
                      <div className="bg-slate-800 border border-slate-700 rounded px-3 py-2 text-sm text-slate-500">
                        [Input numérico - no funcional]
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 3: Expected Result */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="bg-green-600/10 border border-green-600/30 rounded-lg p-4 mb-6">
                <p className="text-sm text-green-400">
                  <strong>Paso 3:</strong> Vista previa del resultado esperado de la simulación
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
                  <h4 className="text-xs text-slate-400 uppercase tracking-wider mb-3">KPIs Simulados</h4>
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-slate-400">Producción Total</p>
                      <p className="text-2xl font-bold text-white">11,850 kg</p>
                      <p className="text-xs text-red-400 mt-1">-4.8% vs base</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Costo Operativo</p>
                      <p className="text-2xl font-bold text-white">$8,400</p>
                      <p className="text-xs text-green-400 mt-1">-12% vs base</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Utilización Promedio</p>
                      <p className="text-2xl font-bold text-white">78%</p>
                      <p className="text-xs text-amber-400 mt-1">-9% vs base</p>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-4">
                  <h4 className="text-xs text-slate-400 uppercase tracking-wider mb-3">Estado de la Simulación</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded">
                      <span className="text-xs text-slate-400">Base seleccionada</span>
                      <span className="text-xs text-white">Planificación Actual</span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-slate-800/50 rounded">
                      <span className="text-xs text-slate-400">Tipo de ajuste</span>
                      <span className="text-xs text-white">Cambio de Capacidad</span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-green-600/20 border border-green-600/30 rounded">
                      <span className="text-xs text-green-400 font-semibold">Estado MILP</span>
                      <span className="text-xs text-green-400 font-semibold">✓ Factible</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-purple-600/10 border border-purple-600/30 rounded-lg p-4 mt-4">
                <h4 className="text-xs text-purple-400 uppercase tracking-wider mb-2 font-semibold">Comparación Visual</h4>
                <div className="flex items-center gap-4">
                  <div className="flex-1 bg-slate-800/50 rounded-lg p-3 text-center">
                    <p className="text-xs text-slate-400 mb-1">Base</p>
                    <p className="text-lg font-bold text-white">12,450 kg</p>
                  </div>
                  <div className="text-2xl text-slate-600">→</div>
                  <div className="flex-1 bg-orange-600/20 border border-orange-600/30 rounded-lg p-3 text-center">
                    <p className="text-xs text-orange-400 mb-1">Simulación</p>
                    <p className="text-lg font-bold text-white">11,850 kg</p>
                  </div>
                </div>
              </div>

              <div className="bg-amber-600/10 border border-amber-600/30 rounded-lg p-3 mt-4">
                <p className="text-xs text-amber-400">
                  <strong>Nota:</strong> Las simulaciones no afectan la producción real. Los resultados se guardan 
                  en la sección "Simulaciones" para comparación posterior.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-900/50 flex items-center justify-between">
          <div>
            {currentStep > 1 && (
              <button
                onClick={() => setCurrentStep((currentStep - 1) as Step)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm transition-colors"
              >
                ← Anterior
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm transition-colors"
            >
              Cancelar
            </button>
            
            {currentStep < 3 ? (
              <button
                disabled={
                  (currentStep === 1 && !selectedBase) ||
                  (currentStep === 2 && !selectedAdjustment)
                }
                onClick={() => setCurrentStep((currentStep + 1) as Step)}
                className={`px-4 py-2 rounded-lg text-sm transition-colors flex items-center gap-2 ${
                  (currentStep === 1 && selectedBase) || (currentStep === 2 && selectedAdjustment)
                    ? "bg-orange-600 hover:bg-orange-700 text-white"
                    : "bg-slate-700 text-slate-500 cursor-not-allowed"
                }`}
              >
                Siguiente →
              </button>
            ) : (
              <button
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors flex items-center gap-2"
              >
                <Play className="w-4 h-4" />
                Crear Simulación (Mock)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
