import React, { useState } from "react";
import { 
  Settings, 
  Power, 
  Activity, 
  AlertCircle, 
  Clock, 
  Plus, 
  MoreHorizontal,
  Box,
  ChevronDown,
  ChevronRight,
  Cpu,
  ArrowUpRight,
  Trash2,
  ExternalLink
} from "lucide-react";
import { toast } from "sonner";
import { Machine, Line } from "@/app/App";

interface MachinesViewProps {
  machines: Machine[];
  lines: Line[];
  onUpdateMachine: (m: Machine) => void;
}

export function MachinesView({ machines, lines, onUpdateMachine }: MachinesViewProps) {
  const [expandedLines, setExpandedLines] = useState<string[]>(lines.map(l => l.id));

  const toggleLine = (id: string) => {
    setExpandedLines(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleStatusToggle = (machine: Machine) => {
    const nextStatusMap: Record<string, Machine["status"]> = {
      "Operativa": "Mantenimiento",
      "Mantenimiento": "No operativa",
      "No operativa": "Operativa"
    };
    onUpdateMachine({ ...machine, status: nextStatusMap[machine.status] });
    toast.info(`Estado de ${machine.name} actualizado a ${nextStatusMap[machine.status]}`);
  };

  return (
    <div className="p-8 space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-end mb-4">
        <div>
          <h3 className="text-2xl font-bold text-white tracking-tight">Estructura de Planta</h3>
          <p className="text-sm text-slate-500">Jerarquía maestra de activos y capacidades operativas.</p>
        </div>
        <div className="flex gap-3">
           <button className="flex items-center gap-2 bg-slate-800 text-slate-300 rounded-lg px-4 py-2 text-sm font-bold hover:bg-slate-700 transition-all border border-slate-700">
            <Settings className="w-4 h-4" /> Configuración Global
          </button>
          <button className="flex items-center gap-2 bg-orange-600 text-white rounded-lg px-4 py-2 text-sm font-bold hover:bg-orange-700 transition-all shadow-lg shadow-orange-900/20">
            <Plus className="w-4 h-4" /> Nueva Máquina
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {lines.map((line) => (
          <div key={line.id} className="bg-[#12121a] rounded-xl border border-slate-800 overflow-hidden shadow-2xl transition-all">
            <div 
              className="w-full flex items-center justify-between p-5 bg-slate-900/30 border-b border-slate-800"
            >
              <div className="flex items-center gap-4 cursor-pointer" onClick={() => toggleLine(line.id)}>
                <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-slate-400 group">
                   {expandedLines.includes(line.id) ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
                </div>
                <div className="text-left">
                  <h4 className="font-bold text-white text-lg flex items-center gap-2">
                    {line.name}
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded uppercase tracking-widest border border-slate-700">Línea Jerárquica</span>
                  </h4>
                  <p className="text-xs text-slate-500 font-mono">ID: {line.id.toUpperCase()}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-8">
                <div className="hidden lg:flex gap-10">
                   <div className="text-center">
                      <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">Capacidad Total</p>
                      <p className="text-white font-mono font-bold">
                        {machines.filter(m => m.lineId === line.id).reduce((acc, m) => acc + m.capacity, 0).toLocaleString()} kg/h
                      </p>
                   </div>
                   <div className="text-center">
                      <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">Máquinas</p>
                      <p className="text-white font-mono font-bold">
                        {machines.filter(m => m.lineId === line.id).length}
                      </p>
                   </div>
                   <div className="text-center">
                      <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">OEE Agregado</p>
                      <p className="text-green-500 font-mono font-bold">88.5%</p>
                   </div>
                </div>
                <button 
                  onClick={() => toast.success("Enviando configuración al plano...")}
                  className="flex items-center gap-2 px-3 py-2 bg-orange-600/10 text-orange-500 rounded-lg text-xs font-bold border border-orange-500/20 hover:bg-orange-600 hover:text-white transition-all"
                >
                  <ExternalLink className="w-3.5 h-3.5" /> Enviar al Plano
                </button>
              </div>
            </div>

            {expandedLines.includes(line.id) && (
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 animate-in slide-in-from-top-2 duration-300">
                {machines.filter(m => m.lineId === line.id).map((machine) => (
                  <MachineCard key={machine.id} machine={machine} onStatusToggle={() => handleStatusToggle(machine)} />
                ))}
                <button className="group border-2 border-dashed border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center gap-3 text-slate-500 hover:border-orange-500/50 hover:bg-orange-500/5 transition-all bg-slate-900/10 min-h-[220px]">
                  <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center group-hover:bg-orange-600 transition-colors">
                     <Plus className="w-6 h-6 group-hover:text-white" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-slate-300">Añadir Activo</p>
                    <p className="text-xs text-slate-600">Crear máquina en {line.name}</p>
                  </div>
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function MachineCard({ machine, onStatusToggle }: { machine: Machine; onStatusToggle: () => void }) {
  const statusConfig = {
    "Operativa": { color: "bg-green-500", text: "text-green-500", label: "OPERATIVA" },
    "Mantenimiento": { color: "bg-yellow-500", text: "text-yellow-500", label: "MANTENCIÓN" },
    "No operativa": { color: "bg-red-500", text: "text-red-500", label: "DETENIDA" }
  };

  const config = statusConfig[machine.status];

  return (
    <div className="bg-slate-900/40 rounded-xl border border-slate-800 p-5 hover:border-slate-600 transition-all group relative flex flex-col justify-between min-h-[220px] hover:shadow-xl hover:shadow-black/40">
      <div className={`absolute top-0 left-0 w-full h-1 ${config.color}`} />
      
      <div className="space-y-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-1">{machine.type}</p>
            <h5 className="text-white font-bold text-base leading-tight">{machine.name}</h5>
          </div>
          <button className="text-slate-600 hover:text-white transition-colors">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">Capacidad</p>
            <p className="text-white font-mono text-sm">{machine.capacity.toLocaleString()} <span className="text-slate-600 text-[9px]">KG/H</span></p>
          </div>
          <div className="text-right">
            <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">Eficiencia</p>
            <div className="flex items-center justify-end gap-1.5">
               <span className={`font-mono font-bold text-sm ${machine.efficiency > 90 ? 'text-green-500' : 'text-orange-500'}`}>{machine.efficiency}%</span>
               <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
           <div className="flex justify-between items-center text-[10px] text-slate-500">
              <span>UTILIZACIÓN</span>
              <span>{machine.efficiency}%</span>
           </div>
           <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
             <div 
               className={`h-full rounded-full transition-all duration-1000 ${machine.efficiency > 90 ? 'bg-green-500' : 'bg-orange-500'}`} 
               style={{ width: `${machine.efficiency}%` }}
             />
           </div>
        </div>
      </div>

      <div className="pt-4 mt-4 border-t border-slate-800/50 flex items-center justify-between">
        <button 
          onClick={onStatusToggle}
          className="flex items-center gap-2 group/status"
        >
          <div className={`w-2.5 h-2.5 rounded-full ${config.color} ${machine.status === 'Operativa' ? 'animate-pulse' : ''} shadow-[0_0_8px_rgba(34,197,94,0.3)]`} />
          <span className={`text-[11px] font-bold ${config.text} group-hover/status:underline`}>{config.label}</span>
        </button>
        <div className="flex gap-2">
           <button className="p-1.5 text-slate-600 hover:text-white hover:bg-slate-800 rounded transition-all">
              <Settings className="w-4 h-4" />
           </button>
           <button className="p-1.5 text-slate-600 hover:text-red-500 hover:bg-red-500/10 rounded transition-all">
              <Trash2 className="w-4 h-4" />
           </button>
        </div>
      </div>
    </div>
  );
}
