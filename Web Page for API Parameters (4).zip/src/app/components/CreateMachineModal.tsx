import { X, Zap, Settings } from "lucide-react";
import { MachineProfileLibrary } from "./MachineProfileLibrary";
import { useState } from "react";

interface CreateMachineModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedMachine?: string | null;
}

export function CreateMachineModal({ isOpen, onClose }: CreateMachineModalProps) {
  const [creationMode, setCreationMode] = useState<"profile" | "custom" | null>(null);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#1a1a24] border border-slate-800 rounded-lg shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white">Crear Nueva Máquina</h3>
            <p className="text-xs text-slate-400 mt-1">Selecciona el método de creación (Blueprint Mode)</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {!creationMode ? (
            /* Selection Mode */
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setCreationMode("profile")}
                className="bg-slate-900/50 border border-slate-800 rounded-lg p-6 hover:border-orange-600/50 transition-all group text-left"
              >
                <div className="w-14 h-14 bg-orange-600/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-orange-600/30 transition-colors">
                  <Zap className="w-7 h-7 text-orange-500" />
                </div>
                <h4 className="font-semibold text-white mb-2">Crear desde Perfil Predefinido</h4>
                <p className="text-xs text-slate-400 leading-relaxed mb-3">
                  Utiliza perfiles estándar con parámetros preconfigurados para tipos comunes de máquinas.
                </p>
                <div className="flex items-center gap-2 text-xs text-orange-400">
                  <span className="font-semibold">Recomendado</span>
                  <span className="px-2 py-0.5 bg-orange-600/20 rounded">Rápido</span>
                </div>
              </button>

              <button
                onClick={() => setCreationMode("custom")}
                className="bg-slate-900/50 border border-slate-800 rounded-lg p-6 hover:border-blue-600/50 transition-all group text-left"
              >
                <div className="w-14 h-14 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-600/30 transition-colors">
                  <Settings className="w-7 h-7 text-blue-500" />
                </div>
                <h4 className="font-semibold text-white mb-2">Crear Máquina Personalizada</h4>
                <p className="text-xs text-slate-400 leading-relaxed mb-3">
                  Define todos los parámetros manualmente para máquinas con características específicas.
                </p>
                <div className="flex items-center gap-2 text-xs text-blue-400">
                  <span className="font-semibold">Avanzado</span>
                  <span className="px-2 py-0.5 bg-blue-600/20 rounded">Flexible</span>
                </div>
              </button>
            </div>
          ) : creationMode === "profile" ? (
            /* Profile Library */
            <div>
              <button
                onClick={() => setCreationMode(null)}
                className="mb-4 text-xs text-slate-400 hover:text-white transition-colors"
              >
                ← Volver a selección
              </button>
              <MachineProfileLibrary />
            </div>
          ) : (
            /* Custom Form (Visual Only) */
            <div>
              <button
                onClick={() => setCreationMode(null)}
                className="mb-4 text-xs text-slate-400 hover:text-white transition-colors"
              >
                ← Volver a selección
              </button>

              <div className="bg-blue-600/10 border border-blue-600/30 rounded-lg p-4 mb-6">
                <p className="text-xs text-blue-400 leading-relaxed">
                  <strong>Formulario personalizado (Mock):</strong> En la versión funcional, aquí aparecerían 
                  campos editables para: nombre, tipo, capacidad, productos permitidos, costos operativos, 
                  restricciones especiales, etc. Los valores se validarían contra las restricciones del modelo MILP.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-slate-400 mb-2 uppercase tracking-wider">Nombre de la máquina</label>
                  <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-slate-500">
                    [Campo de texto - no funcional]
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-2 uppercase tracking-wider">Tipo</label>
                    <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-slate-500">
                      [Selector - no funcional]
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-2 uppercase tracking-wider">Capacidad (kg/h)</label>
                    <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-slate-500">
                      [Campo numérico - no funcional]
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-2 uppercase tracking-wider">Productos permitidos</label>
                  <div className="bg-slate-900 border border-slate-800 rounded px-3 py-2 text-sm text-slate-500 h-20">
                    [Multi-selector - no funcional]
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-900/50">
          <p className="text-xs text-slate-500">
            Esta máquina se agregará a la sección "Máquinas & Líneas" y estará disponible en el Plano de Proceso
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-sm transition-colors"
            >
              Cancelar
            </button>
            <button
              disabled
              className="px-4 py-2 bg-slate-700 text-slate-500 rounded-lg text-sm cursor-not-allowed"
            >
              Crear Máquina (Mock)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}