
  # Web Page for API Parameters

  This is a code bundle for Web Page for API Parameters. The original project is available at https://www.figma.com/design/FxD2td5u46QLNy6QPSWdeg/Web-Page-for-API-Parameters.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  