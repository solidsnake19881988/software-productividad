import { Activity, Move, X, CheckCircle, AlertCircle, Clock } from "lucide-react";
import { useState } from "react";

interface EngineStatusPanelProps {
  initialPosition?: "top-right" | "bottom-right" | "bottom-left";
  engineState?: "idle" | "optimal" | "running" | "error";
}

export function EngineStatusPanel({ initialPosition = "bottom-right", engineState = "idle" }: EngineStatusPanelProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [position, setPosition] = useState<"top-right" | "bottom-right" | "bottom-left">(initialPosition);

  const getEngineStateConfig = () => {
    switch (engineState) {
      case "idle":
        return {
          label: "IDLE",
          color: "slate",
          borderColor: "border-slate-600/40",
          bgColor: "from-slate-600/10 to-slate-700/10",
          textColor: "text-slate-400",
          dotColor: "bg-slate-500"
        };
      case "optimal":
        return {
          label: "OPTIMAL",
          color: "green",
          borderColor: "border-green-600/40",
          bgColor: "from-green-600/10 to-green-700/10",
          textColor: "text-green-400",
          dotColor: "bg-green-500"
        };
      case "running":
        return {
          label: "RUNNING",
          color: "blue",
          borderColor: "border-blue-600/40",
          bgColor: "from-blue-600/10 to-blue-700/10",
          textColor: "text-blue-400",
          dotColor: "bg-blue-500"
        };
      case "error":
        return {
          label: "ERROR",
          color: "red",
          borderColor: "border-red-600/40",
          bgColor: "from-red-600/10 to-red-700/10",
          textColor: "text-red-400",
          dotColor: "bg-red-500"
        };
    }
  };

  const stateConfig = getEngineStateConfig();

  const getPositionStyles = () => {
    switch (position) {
      case "top-right":
        return "top-20 right-6";
      case "bottom-right":
        return "bottom-6 right-6";
      case "bottom-left":
        return "bottom-6 left-6";
    }
  };

  // Collapsed state
  if (!isExpanded) {
    return (
      <div className={`fixed ${getPositionStyles()} z-30 group`}>
        <button
          onClick={() => setIsExpanded(true)}
          className={`bg-slate-900/95 border ${stateConfig.borderColor} rounded-lg px-4 py-2 shadow-2xl backdrop-blur-sm hover:border-${stateConfig.color}-500/60 transition-all hover:scale-105`}
        >
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${stateConfig.dotColor} ${engineState === 'running' ? 'animate-pulse' : ''}`} />
            <span className="text-xs font-mono text-slate-300">
              ENGINE: <span className={`${stateConfig.textColor} font-bold`}>{stateConfig.label}</span>
            </span>
          </div>
        </button>

        {/* Tooltip */}
        <div className="absolute top-full left-0 mt-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <div className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 shadow-xl whitespace-nowrap">
            <p className="text-xs text-slate-300">📍 Panel movible - Click para expandir</p>
          </div>
        </div>
      </div>
    );
  }

  // Expanded state
  return (
    <div className={`fixed ${getPositionStyles()} z-30 w-80 bg-[#1a1a24] border ${stateConfig.borderColor} rounded-lg shadow-2xl`}>
      {/* Header */}
      <div className={`px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r ${stateConfig.bgColor}`}>
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 bg-gradient-to-br from-${stateConfig.color}-600 to-${stateConfig.color}-700 rounded-lg flex items-center justify-center`}>
            <Activity className="w-4 h-4 text-white" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-white">Motor de Optimización</h4>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 ${stateConfig.dotColor} rounded-full ${engineState === 'running' ? 'animate-pulse' : ''}`} />
              <p className={`text-xs ${stateConfig.textColor} font-mono`}>{stateConfig.label}</p>
            </div>
          </div>
        </div>
        <button
          onClick={() => setIsExpanded(false)}
          className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* UX Note */}
      <div className="px-4 py-2 bg-blue-600/10 border-b border-blue-600/20">
        <p className="text-xs text-blue-400 flex items-center gap-2">
          <Move className="w-3 h-3" />
          <strong>UX:</strong> El estado del motor puede reposicionarse para no interferir con la operación
        </p>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Status Cards */}
        <div className="space-y-2">
          <div className={`bg-${stateConfig.color}-600/10 border border-${stateConfig.color}-600/30 rounded-lg p-3 flex items-start gap-3`}>
            <CheckCircle className={`w-5 h-5 ${stateConfig.textColor} mt-0.5`} />
            <div className="flex-1">
              <p className={`text-xs font-semibold ${stateConfig.textColor} mb-1`}>Solver: {stateConfig.label}</p>
              <p className="text-xs text-slate-400">Última ejecución: 2.3 seg</p>
            </div>
          </div>

          <div className="bg-blue-600/10 border border-blue-600/30 rounded-lg p-3 flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-blue-400 mt-0.5" />
            <div className="flex-1">
              <p className="text-xs font-semibold text-blue-400 mb-1">Sync: SAP_ERP</p>
              <p className="text-xs text-slate-400">Conectado - Última sync: 14:42</p>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400">Variables del modelo:</span>
              <span className="text-xs font-mono text-white">1,247</span>
            </div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400">Restricciones activas:</span>
              <span className="text-xs font-mono text-white">856</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">Gap de optimalidad:</span>
              <span className="text-xs font-mono text-green-400">0.02%</span>
            </div>
          </div>
        </div>

        {/* Position Anchors */}
        <div className="pt-4 border-t border-slate-800">
          <p className="text-xs text-slate-400 mb-2">Anclaje del panel:</p>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setPosition("top-right")}
              className={`px-2 py-1.5 text-xs rounded transition-colors ${
                position === "top-right" 
                  ? `bg-${stateConfig.color}-600 text-white` 
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              ↗ Superior
            </button>
            <button
              onClick={() => setPosition("bottom-right")}
              className={`px-2 py-1.5 text-xs rounded transition-colors ${
                position === "bottom-right" 
                  ? `bg-${stateConfig.color}-600 text-white` 
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              ↘ Inf. Der.
            </button>
            <button
              onClick={() => setPosition("bottom-left")}
              className={`px-2 py-1.5 text-xs rounded transition-colors ${
                position === "bottom-left" 
                  ? `bg-${stateConfig.color}-600 text-white` 
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              ↙ Inf. Izq.
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}