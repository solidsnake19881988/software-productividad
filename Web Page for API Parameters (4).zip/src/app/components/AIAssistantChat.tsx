import { Bot, Send, X, AlertTriangle, TrendingUp, Lightbulb, Move } from "lucide-react";
import { useState } from "react";

interface ChatMessage {
  id: string;
  type: "ai" | "user";
  message: string;
  timestamp: string;
  action?: {
    label: string;
    type: "info" | "warning" | "success";
  };
}

export function AIAssistantChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState<"free" | "bottom-right" | "bottom-left" | "right">("bottom-right");
  const [isDragging, setIsDragging] = useState(false);

  const mockMessages: ChatMessage[] = [
    {
      id: "1",
      type: "ai",
      message: "Hola, soy tu asistente IA para optimización. He analizado tu planificación actual y detecté algunas oportunidades.",
      timestamp: "14:32"
    },
    {
      id: "2",
      type: "ai",
      message: "⚠️ Detecté un cuello de botella en la Línea 3 (Packer Auto 500). La capacidad actual es 1500 kg/h pero el flujo de entrada es 2200 kg/h.",
      timestamp: "14:33",
      action: {
        label: "Ver en Plano",
        type: "warning"
      }
    },
    {
      id: "3",
      type: "user",
      message: "¿Qué opciones tengo para resolver esto?",
      timestamp: "14:34"
    },
    {
      id: "4",
      type: "ai",
      message: "Tengo 3 sugerencias:\n\n1. Reducir el flujo de entrada (limitar producción upstream)\n2. Activar IQF Tunnel 02 que está en mantenimiento\n3. Agregar una máquina empacadora adicional\n\n¿Deseas que simule alguna de estas opciones?",
      timestamp: "14:34",
      action: {
        label: "Simular Opciones",
        type: "success"
      }
    },
    {
      id: "5",
      type: "ai",
      message: "💡 Sugerencia: Basado en datos históricos, la opción 2 (activar IQF Tunnel 02) aumentaría la producción total en 18% con un costo operativo adicional de $2,400/día.",
      timestamp: "14:35",
      action: {
        label: "Ver Análisis Detallado",
        type: "info"
      }
    }
  ];

  const getPositionStyles = () => {
    switch (position) {
      case "bottom-right":
        return "bottom-6 right-6";
      case "bottom-left":
        return "bottom-6 left-6";
      case "right":
        return "top-24 right-6";
      default:
        return "bottom-6 right-6";
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed ${getPositionStyles()} z-40 w-14 h-14 bg-gradient-to-br from-purple-600 to-purple-700 rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-transform group`}
      >
        <Bot className="w-7 h-7 text-white" />
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-[#0a0a0f] animate-pulse" />
        
        {/* Tooltip */}
        <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <div className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 shadow-xl whitespace-nowrap">
            <p className="text-xs text-slate-300">Asistente IA - Soporte a la planificación</p>
            <p className="text-xs text-purple-400 mt-1">📍 Puede reposicionarse libremente</p>
          </div>
        </div>
      </button>
    );
  }

  if (isMinimized) {
    return (
      <div className={`fixed ${getPositionStyles()} z-40 w-80 bg-[#1a1a24] border border-purple-600/30 rounded-lg shadow-2xl`}>
        <button
          onClick={() => setIsMinimized(false)}
          className="w-full px-4 py-3 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-purple-700 rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div className="text-left">
              <h4 className="text-sm font-semibold text-white">Asistente IA</h4>
              <p className="text-xs text-slate-400">Soporte a la planificación</p>
            </div>
          </div>
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
        </button>
        
        {/* Position Anchors */}
        <div className="px-4 pb-3 border-t border-slate-800">
          <p className="text-xs text-slate-500 mb-2">Anclaje:</p>
          <div className="flex gap-2">
            <button
              onClick={() => setPosition("bottom-right")}
              className={`flex-1 px-2 py-1 text-xs rounded transition-colors ${
                position === "bottom-right" ? "bg-purple-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              ↘ Inferior Der.
            </button>
            <button
              onClick={() => setPosition("bottom-left")}
              className={`flex-1 px-2 py-1 text-xs rounded transition-colors ${
                position === "bottom-left" ? "bg-purple-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              ↙ Inferior Izq.
            </button>
            <button
              onClick={() => setPosition("right")}
              className={`flex-1 px-2 py-1 text-xs rounded transition-colors ${
                position === "right" ? "bg-purple-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              → Lateral
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`fixed ${getPositionStyles()} z-40 w-96 h-[600px] bg-[#1a1a24] border border-purple-600/30 rounded-lg shadow-2xl flex flex-col`}>
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-purple-600/10 to-purple-700/10 cursor-move">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-purple-700 rounded-full flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-white">Asistente IA</h4>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <p className="text-xs text-slate-400">En línea</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
            title="Minimizar (ver opciones de anclaje)"
          >
            <span className="text-lg">−</span>
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Badge */}
      <div className="px-4 py-2 bg-purple-600/10 border-b border-purple-600/20">
        <p className="text-xs text-purple-400 text-center">
          <strong>Blueprint Mode:</strong> Asistente IA conceptual - Mensajes mock
        </p>
      </div>
      
      {/* Position Annotation */}
      <div className="px-4 py-2 bg-blue-600/10 border-b border-blue-600/20">
        <p className="text-xs text-blue-400 flex items-center gap-2">
          <Move className="w-3 h-3" />
          <strong>UX:</strong> El asistente puede reposicionarse para no interferir con el análisis visual
        </p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {mockMessages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}
          >
            <div className={`max-w-[85%] ${msg.type === "user" ? "order-2" : "order-1"}`}>
              <div
                className={`rounded-lg p-3 ${
                  msg.type === "user"
                    ? "bg-orange-600 text-white"
                    : "bg-slate-900/50 border border-slate-800 text-slate-200"
                }`}
              >
                <p className="text-xs leading-relaxed whitespace-pre-line">{msg.message}</p>
                
                {msg.action && (
                  <button
                    className={`mt-2 w-full px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                      msg.action.type === "warning"
                        ? "bg-amber-600/20 text-amber-400 border border-amber-600/30 hover:bg-amber-600/30"
                        : msg.action.type === "success"
                        ? "bg-green-600/20 text-green-400 border border-green-600/30 hover:bg-green-600/30"
                        : "bg-blue-600/20 text-blue-400 border border-blue-600/30 hover:bg-blue-600/30"
                    }`}
                  >
                    {msg.action.label}
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1 px-1">{msg.timestamp}</p>
            </div>
          </div>
        ))}

        {/* Typing Indicator */}
        <div className="flex justify-start">
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg px-4 py-2">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
              <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
              <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
          </div>
        </div>
      </div>

      {/* Input Area (Disabled) */}
      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="Escribe tu pregunta... (deshabilitado en blueprint)"
            disabled
            className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-600 placeholder-slate-700 cursor-not-allowed"
          />
          <button
            disabled
            className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-slate-600 cursor-not-allowed"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-xs text-slate-500 mt-2 text-center">
          Input deshabilitado - Solo visualización de conversación mock
        </p>
      </div>
    </div>
  );
}