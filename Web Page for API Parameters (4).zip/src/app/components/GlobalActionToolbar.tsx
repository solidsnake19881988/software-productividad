import {
  Play,
  Beaker,
  RotateCcw,
  CheckCircle,
  Loader2,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { ButtonWithTooltip } from "./ButtonWithTooltip";
import { useEffect, useState } from "react";

type ExecutionState = "idle" | "executing" | "completed" | "failed";

export function GlobalActionToolbar() {
  const [optimizationState, setOptimizationState] =
    useState<ExecutionState>("idle");
  const [simulationState, setSimulationState] =
    useState<ExecutionState>("idle");
  const [isExpanded, setIsExpanded] = useState(true);

  /* =========================
     DRAG STATE
  ========================== */
  const [top, setTop] = useState(80);
  const [dragging, setDragging] = useState(false);
  const [startY, setStartY] = useState(0);
  const [startTop, setStartTop] = useState(0);

  const onMouseDown = (e: React.MouseEvent) => {
    setDragging(true);
    setStartY(e.clientY);
    setStartTop(top);
  };

  const onMouseMove = (e: MouseEvent) => {
    if (!dragging) return;
    const deltaY = e.clientY - startY;

    const newTop = startTop + deltaY;

    // límites (no se va fuera de pantalla)
    const minTop = 20;
    const maxTop = window.innerHeight - 120;

    setTop(Math.min(Math.max(newTop, minTop), maxTop));
  };

  const onMouseUp = () => {
    setDragging(false);
  };

  useEffect(() => {
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
    };
  });

  /* ========================= */

  const stateMessages = {
    idle: { text: "Sin ejecutar", color: "text-slate-400" },
    executing: { text: "Ejecutando modelo MILP...", color: "text-blue-400" },
    completed: {
      text: "Resultados cargados en el plano",
      color: "text-green-400"
    },
    failed: { text: "Error en la ejecución", color: "text-red-400" }
  };

  /* =========================
     COLLAPSED
  ========================== */
  if (!isExpanded) {
    return (
      <div
        className="fixed right-8 z-30 bg-[#1a1a24]/95 backdrop-blur-xl border border-slate-800 rounded-lg shadow-2xl"
        style={{ top }}
      >
        <div
          className="px-3 py-2 flex items-center gap-3 cursor-grab active:cursor-grabbing"
          onMouseDown={onMouseDown}
        >
          <div className="flex items-center gap-2">
            <div
              className={`w-2 h-2 rounded-full ${
                optimizationState === "executing"
                  ? "bg-blue-500 animate-pulse"
                  : optimizationState === "completed"
                  ? "bg-green-500"
                  : "bg-slate-600"
              }`}
            />
            <span className="text-xs font-mono text-slate-400">
              ENGINE:{" "}
              {optimizationState === "completed"
                ? "OPTIMAL"
                : optimizationState.toUpperCase()}
            </span>
          </div>

          <button
            onClick={() => setIsExpanded(true)}
            className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  /* =========================
     EXPANDED
  ========================== */
  return (
    <div
      className="fixed right-8 z-30 bg-[#1a1a24]/95 backdrop-blur-xl border border-slate-800 rounded-lg shadow-2xl"
      style={{ top }}
    >
      {/* HEADER / DRAG HANDLE */}
      <div
        className="px-4 py-2 border-b border-slate-800 flex items-center justify-between gap-2 cursor-grab active:cursor-grabbing select-none"
        onMouseDown={onMouseDown}
      >
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-orange-500" />
          <span className="text-xs font-semibold text-white uppercase tracking-wider">
            Acciones Globales
          </span>
        </div>

        <button
          onClick={() => setIsExpanded(false)}
          className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="px-3 py-2 bg-blue-600/10 border-b border-blue-600/20">
        <p className="text-xs text-blue-400">
          💡 Arrastra este panel para moverlo verticalmente
        </p>
      </div>

      <div className="p-4 space-y-4">
        {/* OPTIMIZE */}
        <div className="space-y-2">
          <ButtonWithTooltip
            icon={optimizationState === "executing" ? Loader2 : Play}
            label={
              optimizationState === "executing"
                ? "Optimizando..."
                : "Optimizar"
            }
            tooltip="Ejecuta el solver MILP en backend"
            variant="primary"
            onClick={() => {
              setOptimizationState("executing");
              setTimeout(() => setOptimizationState("completed"), 2000);
            }}
            size="md"
          />

          {optimizationState !== "idle" && (
            <p className={`text-xs ${stateMessages[optimizationState].color}`}>
              {stateMessages[optimizationState].text}
            </p>
          )}
        </div>

        {/* SIMULATE */}
        <div className="pt-3 border-t border-slate-800">
          <ButtonWithTooltip
            icon={Beaker}
            label="Simular Escenario"
            tooltip="Ejecuta simulación sin afectar planificación real"
            variant="secondary"
            onClick={() => {
              setSimulationState("executing");
              setTimeout(() => setSimulationState("completed"), 1800);
            }}
            size="md"
          />
        </div>

        {/* RESET */}
        <div className="pt-3 border-t border-slate-800">
          <ButtonWithTooltip
            icon={RotateCcw}
            label="Resetear Estados"
            tooltip="Limpia estados visuales"
            variant="ghost"
            onClick={() => {
              setOptimizationState("idle");
              setSimulationState("idle");
            }}
            size="sm"
          />
        </div>
      </div>
    </div>
  );
}
