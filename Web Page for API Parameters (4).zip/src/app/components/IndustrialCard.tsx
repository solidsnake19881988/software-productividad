import { ReactNode } from "react";

interface IndustrialCardProps {
  title?: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
  headerAction?: ReactNode;
  variant?: "default" | "orange" | "blue" | "green";
}

export function IndustrialCard({ 
  title, 
  subtitle, 
  children, 
  className = "", 
  headerAction,
  variant = "default" 
}: IndustrialCardProps) {
  const borderColors = {
    default: "border-slate-800",
    orange: "border-orange-600/30",
    blue: "border-blue-600/30",
    green: "border-green-600/30"
  };

  return (
    <div className={`bg-[#1a1a24] border ${borderColors[variant]} rounded-lg overflow-hidden ${className}`}>
      {(title || headerAction) && (
        <div className="px-6 py-4 border-b border-slate-800/50 flex items-center justify-between">
          <div>
            {title && <h3 className="font-semibold text-white">{title}</h3>}
            {subtitle && <p className="text-xs text-slate-400 mt-1">{subtitle}</p>}
          </div>
          {headerAction}
        </div>
      )}
      <div className="p-6">
        {children}
      </div>
    </div>
  );
}
