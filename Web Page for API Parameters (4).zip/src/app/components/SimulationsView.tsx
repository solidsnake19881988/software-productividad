import React, { useState } from "react";
import { 
  Activity, 
  Play, 
  Save, 
  RotateCcw, 
  Plus, 
  TrendingUp, 
  Zap, 
  Clock, 
  ChevronRight,
  Filter,
  BarChart2,
  AlertCircle,
  CheckCircle2,
  Copy
} from "lucide-react";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from "recharts";
import { toast } from "sonner";

const mockComparison = [
  { hour: '08:00', real: 1200, sim: 1250 },
  { hour: '10:00', real: 1500, sim: 1600 },
  { hour: '12:00', real: 1800, sim: 2100 },
  { hour: '14:00', real: 1700, sim: 1950 },
  { hour: '16:00', real: 1900, sim: 2200 },
  { hour: '18:00', real: 1400, sim: 1800 },
  { hour: '20:00', real: 1100, sim: 1400 },
];

export function SimulationsView() {
  const [activeScenario, setActiveScenario] = useState("Escenario_A_Optimizado");
  const [isSimulating, setIsSimulating] = useState(false);

  const runSimulation = () => {
    setIsSimulating(true);
    toast.loading("Ejecutando simulación de Monte Carlo...", { duration: 2000 });
    setTimeout(() => {
      setIsSimulating(false);
      toast.success("Simulación finalizada. Mejora de rendimiento detectada: +4.2%");
    }, 2000);
  };

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h3 className="text-2xl font-bold text-white tracking-tight">Centro de Simulaciones</h3>
          <p className="text-sm text-slate-500">Prueba escenarios hipotéticos sin impacto en la producción real.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 bg-slate-800 text-slate-300 rounded-lg px-4 py-2 text-sm font-bold hover:bg-slate-700 transition-all border border-slate-700">
            <Copy className="w-4 h-4" /> Clonar de Actual
          </button>
          <button 
            onClick={runSimulation}
            disabled={isSimulating}
            className="flex items-center gap-2 bg-orange-600 text-white rounded-lg px-6 py-2 text-sm font-bold hover:bg-orange-700 transition-all shadow-lg shadow-orange-900/20 disabled:opacity-50"
          >
            {isSimulating ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            Ejecutar Simulación
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Scenarios Sidebar */}
        <div className="space-y-4">
           <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 block">Escenarios Guardados</label>
              <div className="space-y-2">
                 <ScenarioCard 
                  name="Escenario_A_Optimizado" 
                  date="Hace 10 min" 
                  isActive={activeScenario === "Escenario_A_Optimizado"} 
                  onClick={() => setActiveScenario("Escenario_A_Optimizado")}
                 />
                 <ScenarioCard 
                  name="Stress_Test_IQF_L1" 
                  date="Ayer, 18:24" 
                  isActive={activeScenario === "Stress_Test_IQF_L1"} 
                  onClick={() => setActiveScenario("Stress_Test_IQF_L1")}
                 />
                 <ScenarioCard 
                  name="Mantenimiento_V2_Shift" 
                  date="25 Ene, 2026" 
                  isActive={activeScenario === "Mantenimiento_V2_Shift"} 
                  onClick={() => setActiveScenario("Mantenimiento_V2_Shift")}
                 />
              </div>
              <button className="w-full mt-4 py-2 flex items-center justify-center gap-2 border border-dashed border-slate-700 text-[10px] font-bold text-slate-500 rounded-lg hover:border-orange-500 hover:text-orange-500 transition-all">
                 <Plus className="w-3 h-3" /> NUEVO ESCENARIO
              </button>
           </div>

           <div className="p-4 bg-orange-600/5 border border-orange-500/10 rounded-xl space-y-4">
              <h4 className="text-[10px] font-bold text-orange-500 uppercase tracking-widest">Variables de Control</h4>
              <div className="space-y-4">
                 <ControlRange label="Carga de Inventario" value="85%" />
                 <ControlRange label="Factor de Falla" value="1.2%" />
                 <ControlRange label="Velocidad Línea 1" value="+10%" />
              </div>
           </div>
        </div>

        {/* Main Simulation View */}
        <div className="lg:col-span-3 space-y-6">
           {/* Chart Comparison */}
           <div className="bg-[#12121a] rounded-xl border border-slate-800 p-6 shadow-2xl">
              <div className="flex justify-between items-center mb-8">
                 <h4 className="text-white font-bold flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-orange-500" />
                    Impacto en Producción (kg/h)
                 </h4>
                 <div className="flex gap-4 text-[10px] font-bold">
                    <div className="flex items-center gap-2">
                       <div className="w-3 h-1 bg-slate-600" />
                       <span className="text-slate-500">PLAN REAL</span>
                    </div>
                    <div className="flex items-center gap-2">
                       <div className="w-3 h-1 bg-orange-500" />
                       <span className="text-orange-500">SIMULACIÓN</span>
                    </div>
                 </div>
              </div>
              <div className="h-[350px]">
                 <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={mockComparison}>
                       <defs>
                          <linearGradient id="colorSim" x1="0" y1="0" x2="0" y2="1">
                             <stop offset="5%" stopColor="#f97316" stopOpacity={0.2}/>
                             <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                          </linearGradient>
                       </defs>
                       <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                       <XAxis dataKey="hour" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                       <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                       <Tooltip 
                        contentStyle={{ backgroundColor: "#0f172a", border: "1px solid #1e293b", borderRadius: "8px" }}
                        itemStyle={{ fontSize: "12px" }}
                       />
                       <Area type="monotone" dataKey="real" stroke="#475569" strokeWidth={2} fill="transparent" />
                       <Area type="monotone" dataKey="sim" stroke="#f97316" strokeWidth={3} fillOpacity={1} fill="url(#colorSim)" />
                    </AreaChart>
                 </ResponsiveContainer>
              </div>
           </div>

           {/* Results Grid */}
           <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <ResultCard 
                label="INCREMENTO KG" 
                value="+2,450 kg" 
                sub="Respecto a plan actual" 
                icon={Zap} 
                trend="up"
              />
              <ResultCard 
                label="FACTOR DE RIESGO" 
                value="LOW" 
                sub="Probabilidad de stockout 2%" 
                icon={CheckCircle2} 
                trend="neutral"
              />
              <ResultCard 
                label="TIEMPO CICLO" 
                value="-12 min" 
                sub="Optimización en cuello Línea 2" 
                icon={Clock} 
                trend="up"
              />
           </div>

           <div className="flex gap-4">
              <button className="flex-1 py-3 bg-slate-800 text-white rounded-lg font-bold text-sm hover:bg-slate-700 transition-all border border-slate-700">DESCARGAR REPORTE TÉCNICO</button>
              <button className="flex-1 py-3 bg-orange-600 text-white rounded-lg font-bold text-sm hover:bg-orange-700 transition-all shadow-lg shadow-orange-900/20">OFICIALIZAR ESTE PLAN</button>
           </div>
        </div>
      </div>
    </div>
  );
}

function ScenarioCard({ name, date, isActive, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      className={`w-full p-3 rounded-lg border text-left transition-all ${
        isActive 
          ? "bg-orange-600/10 border-orange-500 shadow-lg shadow-orange-900/10" 
          : "bg-slate-800/30 border-slate-800 hover:border-slate-700"
      }`}
    >
       <div className="flex justify-between items-center mb-1">
          <span className={`text-[10px] font-bold ${isActive ? "text-orange-500" : "text-slate-300"} truncate`}>{name}</span>
          {isActive && <CheckCircle2 className="w-3 h-3 text-orange-500" />}
       </div>
       <span className="text-[9px] text-slate-500">{date}</span>
    </button>
  );
}

function ControlRange({ label, value }: any) {
  return (
    <div className="space-y-1.5">
       <div className="flex justify-between text-[10px]">
          <span className="text-slate-400 font-medium">{label}</span>
          <span className="text-white font-mono">{value}</span>
       </div>
       <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
          <div className="h-full bg-orange-500" style={{ width: value }} />
       </div>
    </div>
  );
}

function ResultCard({ label, value, sub, icon: Icon, trend }: any) {
  return (
    <div className="bg-[#12121a] border border-slate-800 rounded-xl p-5 shadow-xl">
       <div className="flex justify-between items-start mb-4">
          <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
             <Icon className="w-5 h-5 text-orange-500" />
          </div>
          <div className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${
            trend === 'up' ? "bg-green-500/10 text-green-500" : "bg-blue-500/10 text-blue-500"
          }`}>
             {trend === 'up' ? "OPTIMAL" : "STABLE"}
          </div>
       </div>
       <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">{label}</p>
       <p className="text-xl font-bold text-white mb-1">{value}</p>
       <p className="text-[10px] text-slate-500 italic">{sub}</p>
    </div>
  );
}
