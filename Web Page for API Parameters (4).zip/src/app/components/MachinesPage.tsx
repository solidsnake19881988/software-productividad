import { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { ArrowLeft, Plus, Save, Trash2, X } from 'lucide-react';
import { toast } from 'sonner';
import { Separator } from '@/app/components/ui/separator';

interface MachinesPageProps {
  onBack: () => void;
}

interface Machine {
  id: number;
  name: string;
  type: string;
  productType: string;
  speed: number;
  workingHours: number;
  efficiency: number;
  status: string;
  line: number; // Nueva propiedad para agrupar por línea
}

// Mapeo de tipos de productos y sus velocidades
const PRODUCT_SPEEDS: Record<string, number> = {
  'Pech s/hp': 1800,
  'P s/hp cortada': 1800,
  'Pech c/hp': 1800,
  'Alas': 1800,
  'Filetillo': 1800,
  'Trufro Pollo': 1600,
  'Trufro Pavo': 1600,
  'Bistec_Escalopa Pavo': 1600,
  'Pech s/hp 5kg': 1800,
  'P s/hp Tronchada': 1800,
  'Frambuesas': 1500,
  'Arándanos': 1500,
  'Frutillas': 1500,
  'Mix de Berries': 1400,
};

export function MachinesPage({ onBack }: MachinesPageProps) {
  const [machines, setMachines] = useState<Machine[]>([
    {
      id: 1,
      name: 'IQF-01',
      type: 'Congelador IQF',
      productType: 'Frambuesas',
      speed: 1500,
      workingHours: 8,
      efficiency: 95,
      status: 'Activa',
      line: 1,
    },
    {
      id: 2,
      name: 'CALIBRADO-01',
      type: 'Máquina de Calibrado',
      productType: 'Arándanos',
      speed: 1500,
      workingHours: 12,
      efficiency: 92,
      status: 'Activa',
      line: 1,
    },
    {
      id: 3,
      name: 'IQF-02',
      type: 'Congelador IQF',
      productType: 'Frutillas',
      speed: 1500,
      workingHours: 8,
      efficiency: 88,
      status: 'Mantenimiento',
      line: 1,
    },
    {
      id: 4,
      name: 'EMPAQUE-01',
      type: 'Máquina de Empaque',
      productType: 'Mix de Berries',
      speed: 1400,
      workingHours: 16,
      efficiency: 97,
      status: 'Activa',
      line: 1,
    },
  ]);

  const [showNewMachineForm, setShowNewMachineForm] = useState(false);
  const [expandedMachineId, setExpandedMachineId] = useState<number | null>(null);
  const [newMachine, setNewMachine] = useState<Partial<Machine>>({
    name: '',
    type: '',
    productType: '',
    speed: 1800,
    workingHours: 8,
    efficiency: 95,
    status: 'Activa',
    line: 1,
  });

  const handleMachineChange = (id: number, field: keyof Machine, value: string | number) => {
    setMachines(machines.map(machine => 
      machine.id === id ? { ...machine, [field]: value } : machine
    ));
  };

  const handleProductTypeChange = (id: number, productType: string) => {
    const speed = PRODUCT_SPEEDS[productType] || 1800;
    setMachines(machines.map(machine => 
      machine.id === id ? { ...machine, productType, speed } : machine
    ));
  };

  const handleNewMachineProductTypeChange = (productType: string) => {
    const speed = PRODUCT_SPEEDS[productType] || 1800;
    setNewMachine({ ...newMachine, productType, speed });
  };

  const handleSaveMachine = (id: number) => {
    toast.success('Configuración guardada correctamente');
  };

  const handleDeleteMachine = (id: number) => {
    setMachines(machines.filter(machine => machine.id !== id));
    toast.success('Máquina eliminada');
  };

  const handleAddMachine = () => {
    if (!newMachine.name || !newMachine.type || !newMachine.productType) {
      toast.error('Complete todos los campos obligatorios');
      return;
    }

    const machine: Machine = {
      id: Math.max(...machines.map(m => m.id)) + 1,
      name: newMachine.name,
      type: newMachine.type,
      productType: newMachine.productType,
      speed: newMachine.speed || 100,
      workingHours: newMachine.workingHours || 8,
      efficiency: newMachine.efficiency || 95,
      status: newMachine.status || 'Activa',
      line: newMachine.line || 1,
    };

    setMachines([...machines, machine]);
    setShowNewMachineForm(false);
    setNewMachine({
      name: '',
      type: '',
      productType: '',
      speed: 100,
      workingHours: 8,
      efficiency: 95,
      status: 'Activa',
      line: 1,
    });
    toast.success('Máquina agregada correctamente');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Activa':
        return 'bg-green-500';
      case 'Mantenimiento':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  // Agrupar máquinas por línea
  const machinesByLine = machines.reduce((acc, machine) => {
    if (!acc[machine.line]) {
      acc[machine.line] = [];
    }
    acc[machine.line].push(machine);
    return acc;
  }, {} as Record<number, Machine[]>);

  const sortedLines = Object.keys(machinesByLine).map(Number).sort((a, b) => a - b);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Máquinas</h1>
            <p className="text-muted-foreground">
              Gestione las máquinas y sus configuraciones
            </p>
          </div>
          <Button onClick={() => setShowNewMachineForm(!showNewMachineForm)}>
            {showNewMachineForm ? (
              <>
                <X className="mr-2 h-4 w-4" />
                Cancelar
              </>
            ) : (
              <>
                <Plus className="mr-2 h-4 w-4" />
                Nueva Máquina
              </>
            )}
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Total de Máquinas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{machines.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Máquinas Activas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-600">
                {machines.filter(m => m.status === 'Activa').length}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">En Mantenimiento</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-yellow-600">
                {machines.filter(m => m.status === 'Mantenimiento').length}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Eficiencia Promedio</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">
                {(machines.reduce((sum, m) => sum + m.efficiency, 0) / machines.length).toFixed(1)}%
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Formulario para nueva máquina */}
        {showNewMachineForm && (
          <Card className="border-2 border-primary">
            <CardHeader>
              <CardTitle>Agregar Nueva Máquina</CardTitle>
              <CardDescription>
                Configure los parámetros de la nueva máquina
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="new-name">Nombre *</Label>
                  <Input
                    id="new-name"
                    value={newMachine.name}
                    onChange={(e) => setNewMachine({ ...newMachine, name: e.target.value })}
                    placeholder="Ej: IQF-03"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-type">Tipo *</Label>
                  <Input
                    id="new-type"
                    value={newMachine.type}
                    onChange={(e) => setNewMachine({ ...newMachine, type: e.target.value })}
                    placeholder="Ej: Congelador IQF"
                  />
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="new-speed">Velocidad (prod/h)</Label>
                  <Input
                    id="new-speed"
                    type="number"
                    value={newMachine.speed}
                    onChange={(e) => setNewMachine({ ...newMachine, speed: parseFloat(e.target.value) })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-hours">Horas de Funcionamiento</Label>
                  <Input
                    id="new-hours"
                    type="number"
                    value={newMachine.workingHours}
                    onChange={(e) => setNewMachine({ ...newMachine, workingHours: parseFloat(e.target.value) })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-efficiency">Eficiencia (%)</Label>
                  <Input
                    id="new-efficiency"
                    type="number"
                    value={newMachine.efficiency}
                    onChange={(e) => setNewMachine({ ...newMachine, efficiency: parseFloat(e.target.value) })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-productType">Tipo de Producto</Label>
                <select
                  id="new-productType"
                  value={newMachine.productType}
                  onChange={(e) => handleNewMachineProductTypeChange(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md bg-background"
                >
                  <option value="">Seleccionar</option>
                  {Object.keys(PRODUCT_SPEEDS).map(productType => (
                    <option key={productType} value={productType}>{productType}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-status">Estado</Label>
                <select
                  id="new-status"
                  value={newMachine.status}
                  onChange={(e) => setNewMachine({ ...newMachine, status: e.target.value })}
                  className="w-full px-3 py-2 border rounded-md bg-background"
                >
                  <option value="Activa">Activa</option>
                  <option value="Mantenimiento">Mantenimiento</option>
                  <option value="Inactiva">Inactiva</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-line">Línea</Label>
                <Input
                  id="new-line"
                  type="number"
                  value={newMachine.line}
                  onChange={(e) => setNewMachine({ ...newMachine, line: parseInt(e.target.value) })}
                />
              </div>

              <Button onClick={handleAddMachine} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                Agregar Máquina
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Lista de máquinas existentes */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Máquinas Configuradas</h2>
          
          {sortedLines.map(line => (
            <div key={line} className="space-y-2">
              <h3 className="text-lg font-bold">Línea {line}</h3>
              {machinesByLine[line].map((machine) => (
                <div key={machine.id} className="space-y-2">
                  {/* Botón grande para la máquina */}
                  <button
                    onClick={() => setExpandedMachineId(expandedMachineId === machine.id ? null : machine.id)}
                    className="w-full p-6 bg-card border rounded-lg hover:bg-accent transition-colors flex items-center justify-between"
                  >
                    <div className="flex items-center gap-4">
                      <h3 className="text-2xl font-bold">{machine.name}</h3>
                      <Badge variant="secondary" className="gap-2">
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(machine.status)}`} />
                        {machine.status}
                      </Badge>
                    </div>
                    <div className="text-muted-foreground">
                      {expandedMachineId === machine.id ? '▼' : '▶'}
                    </div>
                  </button>

                  {/* Contenido expandible */}
                  {expandedMachineId === machine.id && (
                    <Card>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardDescription>{machine.type}</CardDescription>
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleSaveMachine(machine.id)}
                            >
                              <Save className="mr-2 h-4 w-4" />
                              Guardar
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleDeleteMachine(machine.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor={`hours-${machine.id}`}>Horas Útiles (h/día)</Label>
                            <Input
                              id={`hours-${machine.id}`}
                              type="number"
                              value={machine.workingHours}
                              onChange={(e) => handleMachineChange(machine.id, 'workingHours', parseFloat(e.target.value))}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor={`productType-${machine.id}`}>Destino (Tipo de Producto)</Label>
                            <select
                              id={`productType-${machine.id}`}
                              value={machine.productType}
                              onChange={(e) => handleProductTypeChange(machine.id, e.target.value)}
                              className="w-full px-3 py-2 border rounded-md bg-background"
                            >
                              <option value="">Seleccionar</option>
                              {Object.keys(PRODUCT_SPEEDS).map(productType => (
                                <option key={productType} value={productType}>{productType}</option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor={`efficiency-${machine.id}`}>Eficiencia (%)</Label>
                            <Input
                              id={`efficiency-${machine.id}`}
                              type="number"
                              value={machine.efficiency}
                              onChange={(e) => handleMachineChange(machine.id, 'efficiency', parseFloat(e.target.value))}
                              max={100}
                              min={0}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`status-${machine.id}`}>Estado</Label>
                          <select
                            id={`status-${machine.id}`}
                            value={machine.status}
                            onChange={(e) => handleMachineChange(machine.id, 'status', e.target.value)}
                            className="w-full px-3 py-2 border rounded-md bg-background"
                          >
                            <option value="Activa">Activa</option>
                            <option value="Mantenimiento">Mantenimiento</option>
                            <option value="Inactiva">Inactiva</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`line-${machine.id}`}>Línea</Label>
                          <Input
                            id={`line-${machine.id}`}
                            type="number"
                            value={machine.line}
                            onChange={(e) => handleMachineChange(machine.id, 'line', parseInt(e.target.value))}
                          />
                        </div>

                        <Separator />

                        {/* Tabla de productos/hora */}
                        <div className="space-y-2">
                          <h4 className="font-semibold">Tabla de Producto/Hora</h4>
                          <div className="border rounded-lg overflow-hidden">
                            <table className="w-full">
                              <thead className="bg-muted">
                                <tr>
                                  <th className="text-left p-3 font-medium">Producto</th>
                                  <th className="text-right p-3 font-medium">Velocidad (kg/h)</th>
                                </tr>
                              </thead>
                              <tbody>
                                {Object.entries(PRODUCT_SPEEDS).map(([product, speed], index) => (
                                  <tr key={product} className={index % 2 === 0 ? 'bg-background' : 'bg-muted/30'}>
                                    <td className="p-3">{product}</td>
                                    <td className="text-right p-3 font-mono">{speed}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}