import { useState } from 'react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Loader2 } from 'lucide-react';
import { Separator } from '@/app/components/ui/separator';

interface OptimizationFormProps {
  onSubmit: (params: Record<string, any>) => void;
  loading: boolean;
}

export function OptimizationForm({ onSubmit, loading }: OptimizationFormProps) {
  const [params, setParams] = useState({
    // Parámetros de la máquina
    workingHours: '8',
    speed: '100',
    efficiency: '95',
    setupTime: '30',
    maintenanceInterval: '240',
    
    // Parámetros de optimización
    objective: 'maximize',
    budget: '10000',
    constraints: '5',
    timeLimit: '60',
    precision: '0.01',
  });

  const handleChange = (field: string, value: string) => {
    setParams(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      // Parámetros de la máquina
      workingHours: parseFloat(params.workingHours),
      speed: parseFloat(params.speed),
      efficiency: parseFloat(params.efficiency),
      setupTime: parseFloat(params.setupTime),
      maintenanceInterval: parseFloat(params.maintenanceInterval),
      
      // Parámetros de optimización
      objective: params.objective,
      budget: parseFloat(params.budget),
      constraints: parseInt(params.constraints),
      timeLimit: parseInt(params.timeLimit),
      precision: parseFloat(params.precision),
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Parámetros del Sistema</CardTitle>
        <CardDescription>
          Configure los parámetros de la máquina y el modelo de optimización
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Sección de Parámetros de la Máquina */}
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-3">Parámetros de la Máquina</h3>
            </div>

            <div className="space-y-2">
              <Label htmlFor="workingHours">Horas de Funcionamiento (horas/día)</Label>
              <Input
                id="workingHours"
                type="number"
                value={params.workingHours}
                onChange={(e) => handleChange('workingHours', e.target.value)}
                placeholder="8"
                step="0.5"
                min="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="speed">Velocidad (productos/hora)</Label>
              <Input
                id="speed"
                type="number"
                value={params.speed}
                onChange={(e) => handleChange('speed', e.target.value)}
                placeholder="100"
                step="1"
                min="1"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="efficiency">Eficiencia (%)</Label>
              <Input
                id="efficiency"
                type="number"
                value={params.efficiency}
                onChange={(e) => handleChange('efficiency', e.target.value)}
                placeholder="95"
                step="0.1"
                min="0"
                max="100"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="setupTime">Tiempo de Preparación (minutos)</Label>
              <Input
                id="setupTime"
                type="number"
                value={params.setupTime}
                onChange={(e) => handleChange('setupTime', e.target.value)}
                placeholder="30"
                step="1"
                min="0"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maintenanceInterval">Intervalo de Mantenimiento (horas)</Label>
              <Input
                id="maintenanceInterval"
                type="number"
                value={params.maintenanceInterval}
                onChange={(e) => handleChange('maintenanceInterval', e.target.value)}
                placeholder="240"
                step="1"
                min="1"
              />
            </div>
          </div>

          <Separator />

          {/* Sección de Parámetros de Optimización */}
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-3">Parámetros de Optimización</h3>
            </div>

            <div className="space-y-2">
              <Label htmlFor="objective">Objetivo</Label>
              <select
                id="objective"
                value={params.objective}
                onChange={(e) => handleChange('objective', e.target.value)}
                className="w-full px-3 py-2 border rounded-md bg-background"
              >
                <option value="maximize">Maximizar</option>
                <option value="minimize">Minimizar</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="budget">Presupuesto</Label>
              <Input
                id="budget"
                type="number"
                value={params.budget}
                onChange={(e) => handleChange('budget', e.target.value)}
                placeholder="10000"
                step="0.01"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="constraints">Número de Restricciones</Label>
              <Input
                id="constraints"
                type="number"
                value={params.constraints}
                onChange={(e) => handleChange('constraints', e.target.value)}
                placeholder="5"
                min="1"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="timeLimit">Límite de Tiempo (segundos)</Label>
              <Input
                id="timeLimit"
                type="number"
                value={params.timeLimit}
                onChange={(e) => handleChange('timeLimit', e.target.value)}
                placeholder="60"
                min="1"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="precision">Precisión</Label>
              <Input
                id="precision"
                type="number"
                value={params.precision}
                onChange={(e) => handleChange('precision', e.target.value)}
                placeholder="0.01"
                step="0.001"
              />
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Optimizando...
              </>
            ) : (
              'Ejecutar Optimización'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}