import React, { useState, useEffect } from "react";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  ChevronRight, 
  CheckCircle2, 
  AlertTriangle,
  Zap,
  Clock,
  BarChart3,
  Search,
  Download,
  Terminal,
  Cpu,
  Binary,
  Target,
  Activity
} from "lucide-react";
import { toast } from "sonner";

export function OptimizationView() {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState<"idle" | "running" | "completed">("idle");
  const [logs, setLogs] = useState<string[]>([]);

  const solverMessages = [
    "Iniciando solver MILP...",
    "Generando 1,420 variables enteras...",
    "Construyendo matriz de restricciones (Capacidad, Flujo, Turnos)...",
    "Buscando solución factible (Primal Bound)...",
    "Iteración 42: Gap = 12.4%",
    "Iteración 89: Gap = 4.2%",
    "Iteración 156: Gap = 0.04% - Criterio de parada alcanzado.",
    "Optimalidad detectada. Extrayendo resultados..."
  ];

  useEffect(() => {
    let interval: any;
    if (isRunning && progress < 100) {
      interval = setInterval(() => {
        setProgress(prev => {
          const next = prev + 1.5;
          if (next >= 100) {
            setIsRunning(false);
            setStatus("completed");
            toast.success("Optimización finalizada satisfactoriamente.");
            return 100;
          }
          // Add logs occasionally
          if (Math.floor(next) % 15 === 0) {
             const msgIdx = Math.floor(next / 15);
             if (solverMessages[msgIdx]) {
                setLogs(prevLogs => [...prevLogs, `[${new Date().toLocaleTimeString()}] ${solverMessages[msgIdx]}`]);
             }
          }
          return next;
        });
      }, 50);
    }
    return () => clearInterval(interval);
  }, [isRunning, progress]);

  const startOptimization = () => {
    setIsRunning(true);
    setStatus("running");
    setProgress(0);
    setLogs([`[${new Date().toLocaleTimeString()}] Inicializando motor Gurobi/CBC...`]);
    toast.info("Ejecutando modelo matemático...");
  };

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
           <h3 className="text-2xl font-bold text-white tracking-tight">Motor de Optimización</h3>
           <p className="text-sm text-slate-500 font-medium">Configuración y ejecución del modelo matemático MILP.</p>
        </div>
        <div className="flex gap-4">
           <div className="flex items-center gap-3 px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg">
              <span className="text-[10px] font-bold text-slate-500 uppercase">Solver Status:</span>
              <div className="flex items-center gap-2">
                 <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-orange-500 animate-pulse' : status === 'completed' ? 'bg-green-500' : 'bg-slate-700'}`} />
                 <span className={`text-[10px] font-bold ${isRunning ? 'text-orange-500' : 'text-slate-400'}`}>{isRunning ? 'COMPUTING' : status === 'completed' ? 'READY' : 'IDLE'}</span>
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Control & Input Column */}
        <div className="space-y-6">
           <div className="bg-[#12121a] rounded-xl border border-slate-800 p-6 space-y-6 shadow-2xl">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                 <Settings className="w-4 h-4 text-orange-500" />
                 Parámetros de Entrada
              </h4>
              
              <div className="space-y-4">
                 <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-center mb-1">
                       <span className="text-[10px] font-bold text-slate-400 uppercase">GAP de Optimalidad</span>
                       <span className="text-[10px] font-mono text-orange-500">0.01%</span>
                    </div>
                    <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                       <div className="h-full bg-orange-600" style={{ width: '85%' }} />
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                       <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Corte de Tiempo</p>
                       <p className="text-sm font-bold text-white">300s</p>
                    </div>
                    <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                       <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Hilos (CPU)</p>
                       <p className="text-sm font-bold text-white">8 Cores</p>
                    </div>
                 </div>

                 <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Función Objetivo</label>
                    <select className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-white font-medium focus:outline-none focus:ring-1 focus:ring-orange-500">
                       <option>Maximizar Rendimiento Total (kg)</option>
                       <option>Minimizar Cambios de Formato</option>
                       <option>Maximizar Prioridad de Clientes</option>
                       <option>Equilibrar Carga de Máquinas</option>
                    </select>
                 </div>
              </div>

              <div className="pt-4 space-y-3">
                 <button 
                  onClick={startOptimization}
                  disabled={isRunning}
                  className="w-full py-4 bg-orange-600 text-white rounded-xl font-bold text-sm hover:bg-orange-700 transition-all shadow-lg shadow-orange-900/20 disabled:opacity-50 flex items-center justify-center gap-2"
                 >
                    {isRunning ? <RotateCcw className="w-5 h-5 animate-spin" /> : <Play className="w-5 h-5" />}
                    EJECUTAR OPTIMIZADOR
                 </button>
                 {status === 'completed' && (
                    <button 
                     onClick={() => setStatus('idle')}
                     className="w-full py-3 bg-slate-800 text-slate-400 rounded-xl font-bold text-xs hover:text-white transition-all border border-slate-700"
                    >
                       RESETEAR SOLUCIÓN
                    </button>
                 )}
              </div>
           </div>

           {/* Real-time Feasibility Card */}
           <div className="bg-blue-600/5 border border-blue-500/10 rounded-xl p-6">
              <div className="flex justify-between items-center mb-4">
                 <h4 className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Data Health</h4>
                 <Activity className="w-4 h-4 text-blue-500" />
              </div>
              <ul className="space-y-3">
                 <li className="flex justify-between text-[11px]">
                    <span className="text-slate-400">Inventarios Disponibles</span>
                    <span className="text-green-500 font-bold">READY</span>
                 </li>
                 <li className="flex justify-between text-[11px]">
                    <span className="text-slate-400">Capacidades de Máquinas</span>
                    <span className="text-green-500 font-bold">SYNC</span>
                 </li>
                 <li className="flex justify-between text-[11px]">
                    <span className="text-slate-400">Restricciones de Personal</span>
                    <span className="text-yellow-500 font-bold">WARNING</span>
                 </li>
              </ul>
           </div>
        </div>

        {/* Execution & Logs Column */}
        <div className="lg:col-span-2 space-y-6">
           {/* Progress / Terminal */}
           <div className="bg-[#0a0a0f] rounded-xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col h-[500px]">
              <div className="bg-slate-900/80 border-b border-slate-800 px-6 py-3 flex items-center justify-between">
                 <div className="flex items-center gap-3">
                    <Terminal className="w-4 h-4 text-slate-500" />
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Solver Output Console</span>
                 </div>
                 {isRunning && (
                    <div className="flex items-center gap-2">
                       <div className="w-1 h-1 rounded-full bg-orange-500 animate-ping" />
                       <span className="text-[10px] font-mono text-orange-500">{progress.toFixed(1)}%</span>
                    </div>
                 )}
              </div>
              
              <div className="flex-1 p-6 font-mono text-xs overflow-y-auto space-y-2 scrollbar-hide">
                 {logs.length === 0 && (
                   <div className="flex flex-col items-center justify-center h-full text-slate-700 gap-4 opacity-50">
                      <Binary className="w-12 h-12" />
                      <p className="text-[10px] font-bold uppercase tracking-widest text-center">Esperando comando de ejecución...<br/>El modelo está listo para procesar 14,285 restricciones.</p>
                   </div>
                 )}
                 {logs.map((log, i) => (
                   <div key={i} className="flex gap-4 group">
                      <span className="text-slate-700 select-none">[{i.toString().padStart(3, '0')}]</span>
                      <span className={log.includes('Optimal') ? 'text-green-500 font-bold' : 'text-slate-400'}>{log}</span>
                   </div>
                 ))}
                 {isRunning && (
                    <div className="flex gap-4 animate-pulse">
                       <span className="text-slate-700">[{logs.length.toString().padStart(3, '0')}]</span>
                       <span className="text-orange-500">_</span>
                    </div>
                 )}
              </div>

              {/* Visualization during run */}
              <div className="h-1.5 bg-slate-800">
                 <div 
                  className="h-full bg-orange-600 transition-all duration-300" 
                  style={{ width: `${progress}%` }} 
                 />
              </div>
           </div>

           {/* Result Overview (Post-Run) */}
           {status === 'completed' && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 animate-in slide-in-from-bottom-4 duration-500">
                 <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 border-l-4 border-l-green-500">
                    <p className="text-[9px] font-bold text-slate-500 uppercase mb-1">Resultado</p>
                    <p className="text-sm font-bold text-white uppercase">Optimal Solution Found</p>
                 </div>
                 <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                    <p className="text-[9px] font-bold text-slate-500 uppercase mb-1">Valor Objetivo</p>
                    <p className="text-sm font-bold text-green-500">28,450 kg</p>
                 </div>
                 <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                    <p className="text-[9px] font-bold text-slate-500 uppercase mb-1">Runtime</p>
                    <p className="text-sm font-bold text-white">12.4s</p>
                 </div>
                 <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 flex items-center justify-center">
                    <button className="flex items-center gap-2 text-xs font-bold text-orange-500 hover:text-orange-400">
                       VER REPORTE <ChevronRight className="w-4 h-4" />
                    </button>
                 </div>
              </div>
           )}
        </div>
      </div>
    </div>
  );
}
