import { Info, AlertCircle, CheckCircle } from "lucide-react";

interface AnnotationBadgeProps {
  type?: "info" | "warning" | "success";
  children: React.ReactNode;
  className?: string;
}

export function AnnotationBadge({ type = "info", children, className = "" }: AnnotationBadgeProps) {
  const styles = {
    info: "bg-blue-600/10 border-blue-600/30 text-blue-400",
    warning: "bg-amber-600/10 border-amber-600/30 text-amber-400",
    success: "bg-green-600/10 border-green-600/30 text-green-400"
  };

  const icons = {
    info: Info,
    warning: AlertCircle,
    success: CheckCircle
  };

  const Icon = icons[type];

  return (
    <div className={`flex items-start gap-3 p-4 rounded-lg border ${styles[type]} ${className}`}>
      <Icon className="w-5 h-5 mt-0.5 flex-shrink-0" />
      <p className="text-sm leading-relaxed">{children}</p>
    </div>
  );
}
