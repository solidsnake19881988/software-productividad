import { Cpu, ChevronDown, ChevronRight, Gauge, Package, AlertCircle, CheckCircle, Edit, MapPin, Plus } from "lucide-react";
import { SectionHeader } from "./SectionHeader";
import { AnnotationBadge } from "./AnnotationBadge";
import { IndustrialCard } from "./IndustrialCard";
import { ButtonWithTooltip } from "./ButtonWithTooltip";
import { CreateMachineModal } from "./CreateMachineModal";
import { useState } from "react";

interface Machine {
  id: string;
  name: string;
  type: string;
  capacity: number;
  status: "Operativa" | "Mantenimiento" | "No operativa";
  efficiency: number;
  products: string[];
  usedInProcess: boolean;
}

interface Line {
  id: string;
  name: string;
  color: string;
  machines: Machine[];
}

export function MachinesLinesView() {
  const [expandedLines, setExpandedLines] = useState<string[]>(["line-1"]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<string | null>(null);

  const linesData: Line[] = [
    {
      id: "line-1",
      name: "Línea 1 - IQF (Congelación Rápida)",
      color: "#f97316",
      machines: [
        {
          id: "m1",
          name: "IQF Tunnel 01",
          type: "Congelador IQF",
          capacity: 2500,
          status: "Operativa",
          efficiency: 94,
          products: ["Arándanos", "Frambuesas", "Mixtos"],
          usedInProcess: true
        },
        {
          id: "m2",
          name: "Pre-Cooler A",
          type: "Enfriador Previo",
          capacity: 3000,
          status: "Operativa",
          efficiency: 88,
          products: ["Todos los productos"],
          usedInProcess: true
        },
        {
          id: "m3",
          name: "IQF Tunnel 02",
          type: "Congelador IQF",
          capacity: 2200,
          status: "Mantenimiento",
          efficiency: 0,
          products: ["Arándanos", "Frambuesas"],
          usedInProcess: false
        }
      ]
    },
    {
      id: "line-2",
      name: "Línea 2 - Calibrado y Empaque",
      color: "#3b82f6",
      machines: [
        {
          id: "m4",
          name: "Sorter Optical X1",
          type: "Calibrador Óptico",
          capacity: 4000,
          status: "Operativa",
          efficiency: 91,
          products: ["Premium Grade", "Regular Grade"],
          usedInProcess: true
        },
        {
          id: "m5",
          name: "Packer Auto 500",
          type: "Empacadora Automática",
          capacity: 1500,
          status: "Operativa",
          efficiency: 75,
          products: ["Bolsa 1kg", "Bolsa 500g", "Granel"],
          usedInProcess: true
        },
        {
          id: "m6",
          name: "Label Printer LX200",
          type: "Etiquetadora",
          capacity: 2000,
          status: "Operativa",
          efficiency: 82,
          products: ["Todos"],
          usedInProcess: false
        }
      ]
    }
  ];

  const toggleLine = (lineId: string) => {
    setExpandedLines(prev =>
      prev.includes(lineId)
        ? prev.filter(id => id !== lineId)
        : [...prev, lineId]
    );
  };

  const getStatusColor = (status: Machine["status"]) => {
    switch (status) {
      case "Operativa": return "bg-green-600/20 text-green-400 border-green-600/30";
      case "Mantenimiento": return "bg-amber-600/20 text-amber-400 border-amber-600/30";
      case "No operativa": return "bg-red-600/20 text-red-400 border-red-600/30";
    }
  };

  const getStatusIcon = (status: Machine["status"]) => {
    switch (status) {
      case "Operativa": return CheckCircle;
      case "Mantenimiento": 
      case "No operativa": return AlertCircle;
    }
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto">
      <SectionHeader
        icon={Cpu}
        title="Máquinas & Líneas de Producción"
        subtitle="Gestión jerárquica de activos industriales - Fuente de verdad del modelo"
        badge="MASTER DATA"
      >
        <ButtonWithTooltip
          icon={Plus}
          label="Agregar Máquina"
          tooltip="Crea una nueva máquina desde perfiles predefinidos o de forma personalizada. La máquina estará disponible para agregar al Plano de Proceso."
          state="normal"
          variant="primary"
          onClick={() => setShowCreateModal(true)}
          size="sm"
        />
      </SectionHeader>

      <AnnotationBadge type="info" className="mb-8">
        <strong>Fuente de verdad:</strong> Las máquinas y líneas definidas aquí son las entidades reales del modelo MILP. 
        Cada máquina representa un nodo con restricciones de capacidad (kg/h), productos permitidos y estado operativo. 
        Los cambios en esta sección afectan directamente las restricciones del modelo de optimización.
      </AnnotationBadge>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-[#1a1a24] border border-green-600/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Operativas</span>
            <CheckCircle className="w-4 h-4 text-green-500" />
          </div>
          <p className="text-2xl font-bold text-white">5</p>
          <p className="text-xs text-slate-500 mt-1">Disponibles en plano</p>
        </div>

        <div className="bg-[#1a1a24] border border-amber-600/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Mantenimiento</span>
            <AlertCircle className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-bold text-white">1</p>
          <p className="text-xs text-slate-500 mt-1">No disponible</p>
        </div>

        <div className="bg-[#1a1a24] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Capacidad Total</span>
            <Gauge className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-white">15,200</p>
          <p className="text-xs text-slate-500 mt-1">kg/h agregado</p>
        </div>

        <div className="bg-[#1a1a24] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Eficiencia Promedio</span>
            <Gauge className="w-4 h-4 text-orange-500" />
          </div>
          <p className="text-2xl font-bold text-white">86.7%</p>
          <p className="text-xs text-slate-500 mt-1">Basado en OEE</p>
        </div>
      </div>

      {/* Hierarchical Lines & Machines */}
      <div className="space-y-4">
        {linesData.map((line) => {
          const isExpanded = expandedLines.includes(line.id);
          const operativeMachines = line.machines.filter(m => m.status === "Operativa").length;

          return (
            <div key={line.id} className="bg-[#1a1a24] border border-slate-800 rounded-lg overflow-hidden">
              {/* Line Header */}
              <button
                onClick={() => toggleLine(line.id)}
                className="w-full px-6 py-4 flex items-center justify-between hover:bg-slate-800/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    {isExpanded ? (
                      <ChevronDown className="w-5 h-5 text-slate-400" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-slate-400" />
                    )}
                    <div
                      className="w-4 h-4 rounded"
                      style={{ backgroundColor: line.color }}
                    />
                  </div>
                  <div className="text-left">
                    <h3 className="font-semibold text-white">{line.name}</h3>
                    <p className="text-xs text-slate-400 mt-1">
                      {operativeMachines}/{line.machines.length} máquinas operativas
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 text-xs font-mono bg-slate-800 text-slate-400 rounded border border-slate-700">
                    ID: {line.id}
                  </span>
                </div>
              </button>

              {/* Machines List */}
              {isExpanded && (
                <div className="px-6 pb-4 space-y-3 border-t border-slate-800/50">
                  {line.machines.map((machine) => {
                    const StatusIcon = getStatusIcon(machine.status);

                    return (
                      <div
                        key={machine.id}
                        className="bg-[#12121a] border border-slate-800 rounded-lg p-4 hover:border-slate-700 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-start gap-3 flex-1">
                            <div className="w-10 h-10 bg-gradient-to-br from-orange-600 to-orange-700 rounded-lg flex items-center justify-center shadow-lg shadow-orange-900/30 flex-shrink-0">
                              <Cpu className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h4 className="font-semibold text-white">{machine.name}</h4>
                                <span className={`px-2 py-1 text-xs border rounded ${getStatusColor(machine.status)}`}>
                                  {machine.status}
                                </span>
                                {machine.usedInProcess && (
                                  <span className="px-2 py-1 text-xs bg-blue-600/20 text-blue-400 border border-blue-600/30 rounded flex items-center gap-1">
                                    <MapPin className="w-3 h-3" />
                                    En Plano
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-400">{machine.type}</p>
                            </div>
                          </div>

                          <button className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors">
                            <Edit className="w-4 h-4" />
                          </button>
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                          <div className="bg-slate-900/50 rounded-lg p-3">
                            <div className="flex items-center gap-2 mb-1">
                              <Gauge className="w-3 h-3 text-blue-400" />
                              <span className="text-xs text-slate-400">Capacidad</span>
                            </div>
                            <p className="text-lg font-bold text-white">{machine.capacity.toLocaleString()}</p>
                            <p className="text-xs text-slate-500">kg/h</p>
                          </div>

                          <div className="bg-slate-900/50 rounded-lg p-3">
                            <div className="flex items-center gap-2 mb-1">
                              <StatusIcon className="w-3 h-3 text-green-400" />
                              <span className="text-xs text-slate-400">Eficiencia</span>
                            </div>
                            <p className={`text-lg font-bold ${machine.efficiency >= 90 ? "text-green-400" : machine.efficiency >= 80 ? "text-amber-400" : "text-red-400"}`}>
                              {machine.efficiency}%
                            </p>
                            <p className="text-xs text-slate-500">OEE actual</p>
                          </div>

                          <div className="bg-slate-900/50 rounded-lg p-3">
                            <div className="flex items-center gap-2 mb-1">
                              <Package className="w-3 h-3 text-orange-400" />
                              <span className="text-xs text-slate-400">Productos</span>
                            </div>
                            <p className="text-lg font-bold text-white">{machine.products.length}</p>
                            <p className="text-xs text-slate-500">permitidos</p>
                          </div>
                        </div>

                        <div className="mt-3 pt-3 border-t border-slate-800">
                          <p className="text-xs text-slate-400 mb-2">Productos permitidos:</p>
                          <div className="flex flex-wrap gap-2">
                            {machine.products.map((product, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-1 text-xs bg-slate-800 text-slate-300 rounded border border-slate-700"
                              >
                                {product}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer Annotations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <AnnotationBadge type="warning">
          <strong>Restricciones del modelo:</strong> Cada máquina genera restricciones del tipo: 
          <code className="ml-1 px-2 py-0.5 bg-slate-900 rounded text-xs">flujo_entrada ≤ capacidad × eficiencia</code>. 
          Las máquinas en mantenimiento tienen capacidad = 0 en el modelo.
        </AnnotationBadge>

        <AnnotationBadge type="success">
          <strong>Sincronización:</strong> Los estados operativos y eficiencias se actualizan desde el sistema CMMS 
          (Computerized Maintenance Management System) cada hora. Los cambios de estado activan recálculos automáticos del MILP.
        </AnnotationBadge>
      </div>

      {/* Create Machine Modal */}
      <CreateMachineModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        selectedMachine={selectedMachine}
      />

      {/* Add Machine Button */}
      <div className="mt-8">
        <ButtonWithTooltip
          tooltip="Agregar nueva máquina"
          onClick={() => setShowCreateModal(true)}
        >
          <Plus className="w-5 h-5 text-green-500" />
        </ButtonWithTooltip>
      </div>
    </div>
  );
}