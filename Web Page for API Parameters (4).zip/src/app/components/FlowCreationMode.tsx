import { Link, X, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";

type FlowState = "idle" | "connecting" | "valid" | "invalid";

interface FlowCreationModeProps {
  onAdd: (fromId: string, toId: string) => void;
}

export function FlowCreationMode({ onAdd }: FlowCreationModeProps) {
  const [isActive, setIsActive] = useState(false);
  const [flowState, setFlowState] = useState<FlowState>("idle");
  const [fromNodeId, setFromNodeId] = useState<string>("");
  const [toNodeId, setToNodeId] = useState<string>("");

  const handleCreateFlow = () => {
    if (fromNodeId && toNodeId) {
      onAdd(fromNodeId, toNodeId);
      setFromNodeId("");
      setToNodeId("");
      setFlowState("idle");
    }
  };

  if (!isActive) {
    return (
      <button
        onClick={() => {
          setIsActive(true);
          setFlowState("idle");
        }}
        className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow-lg transition-all"
      >
        <Link className="w-4 h-4" />
        <span className="text-sm font-medium">Modo Crear Flujo</span>
      </button>
    );
  }

  return (
    <div className="w-80 bg-[#1a1a24]/95 backdrop-blur-xl border border-slate-800 rounded-lg shadow-2xl">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link className="w-4 h-4 text-blue-500" />
          <span className="text-sm font-semibold text-white">Modo Crear Flujo</span>
        </div>
        <button
          onClick={() => {
            setIsActive(false);
            setFlowState("idle");
          }}
          className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Info Badge */}
      <div className="px-4 py-2 bg-blue-600/10 border-b border-blue-600/20">
        <p className="text-xs text-blue-400">
          📌 Modo ejemplo: Conecta dos nodos para crear un flujo de proceso
        </p>
      </div>

      {/* Instructions */}
      <div className="p-4 space-y-3">
        <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800">
          <p className="text-xs font-semibold text-white mb-2">Instrucciones:</p>
          <ol className="text-xs text-slate-400 space-y-1 list-decimal list-inside">
            <li>Haz clic en el nodo origen</li>
            <li>Arrastra hacia el nodo destino</li>
            <li>Suelta para crear el flujo</li>
          </ol>
        </div>

        {/* Current State */}
        <div className="space-y-2">
          <p className="text-xs text-slate-400 uppercase tracking-wider">Estado actual:</p>
          
          <div className="flex items-center gap-2 p-2 bg-slate-900/50 rounded border border-slate-800">
            {flowState === "idle" && (
              <>
                <div className="w-2 h-2 rounded-full bg-slate-600" />
                <span className="text-xs text-slate-400">Esperando selección...</span>
              </>
            )}
            {flowState === "connecting" && (
              <>
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                <span className="text-xs text-blue-400">Conectando nodos...</span>
              </>
            )}
            {flowState === "valid" && (
              <>
                <CheckCircle className="w-3 h-3 text-green-400" />
                <span className="text-xs text-green-400">Flujo permitido ✓</span>
              </>
            )}
            {flowState === "invalid" && (
              <>
                <XCircle className="w-3 h-3 text-red-400" />
                <span className="text-xs text-red-400">Flujo no permitido ✗</span>
              </>
            )}
          </div>
        </div>

        {/* Visual Examples */}
        <div className="space-y-2">
          <p className="text-xs text-slate-400 uppercase tracking-wider">Validación visual:</p>
          
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-2 bg-green-600/10 rounded border border-green-600/30">
              <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs text-green-400 font-semibold">Flujo Permitido</p>
                <p className="text-xs text-slate-400">Conexión respeta precedencia</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-2 bg-red-600/10 rounded border border-red-600/30">
              <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-xs text-red-400 font-semibold">Flujo No Permitido</p>
                <p className="text-xs text-slate-400">Crearía ciclo o viola restricción</p>
              </div>
            </div>
          </div>
        </div>

        {/* Test Buttons */}
        <div className="pt-3 border-t border-slate-800 space-y-2">
          <p className="text-xs text-slate-500">Simular estados (solo visual):</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setFlowState("connecting")}
              className="px-3 py-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 rounded text-xs transition-colors"
            >
              Conectando
            </button>
            <button
              onClick={() => setFlowState("valid")}
              className="px-3 py-1.5 bg-green-600/20 hover:bg-green-600/30 text-green-400 rounded text-xs transition-colors"
            >
              Válido
            </button>
            <button
              onClick={() => setFlowState("invalid")}
              className="px-3 py-1.5 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded text-xs transition-colors"
            >
              Inválido
            </button>
            <button
              onClick={() => setFlowState("idle")}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded text-xs transition-colors"
            >
              Reset
            </button>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="px-4 py-2 bg-slate-900/50 border-t border-slate-800">
        <p className="text-xs text-slate-500 leading-relaxed">
          <strong className="text-slate-400">Leyenda:</strong> Los flujos representan restricciones 
          de precedencia del modelo MILP.
        </p>
      </div>
    </div>
  );
}