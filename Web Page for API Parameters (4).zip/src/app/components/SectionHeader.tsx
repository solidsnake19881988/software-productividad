import { LucideIcon } from "lucide-react";

interface SectionHeaderProps {
  icon: LucideIcon;
  title: string;
  subtitle?: string;
  badge?: string;
  children?: React.ReactNode;
}

export function SectionHeader({ icon: Icon, title, subtitle, badge, children }: SectionHeaderProps) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 bg-gradient-to-br from-orange-600 to-orange-700 rounded-lg flex items-center justify-center shadow-lg shadow-orange-900/30">
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-white tracking-tight">{title}</h1>
            {badge && (
              <span className="px-3 py-1 text-xs font-mono bg-slate-800 text-slate-400 rounded-full border border-slate-700">
                {badge}
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-sm text-slate-400 mt-2">{subtitle}</p>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}
