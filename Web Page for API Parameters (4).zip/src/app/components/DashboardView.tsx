import { LayoutDashboard, TrendingUp, Package, Zap, Target, Info, Database, Calendar, Filter, Download, RefreshCw } from "lucide-react";
import { SectionHeader } from "./SectionHeader";
import { AnnotationBadge } from "./AnnotationBadge";
import { IndustrialCard } from "./IndustrialCard";
import { ButtonWithTooltip, StateBadge } from "./ButtonWithTooltip";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { useState } from "react";

export function DashboardView() {
  const [selectedPeriod, setSelectedPeriod] = useState<"week" | "month" | "year">("week");
  const [filterActive, setFilterActive] = useState(false);

  // Mock data estático para visualización - cambia según período
  const kpiDataByPeriod = {
    week: [
      {
        title: "Producción Planificada",
        value: "12,450",
        unit: "kg",
        change: "+8.2%",
        trend: "up",
        icon: Package,
        color: "blue"
      },
      {
        title: "Producción Real",
        value: "11,890",
        unit: "kg",
        change: "+6.5%",
        trend: "up",
        icon: Zap,
        color: "green"
      },
      {
        title: "Cumplimiento",
        value: "95.5",
        unit: "%",
        change: "-1.2%",
        trend: "down",
        icon: Target,
        color: "orange"
      },
      {
        title: "Eficiencia Global",
        value: "88.3",
        unit: "%",
        change: "+3.1%",
        trend: "up",
        icon: TrendingUp,
        color: "purple"
      }
    ],
    month: [
      {
        title: "Producción Planificada",
        value: "52,340",
        unit: "kg",
        change: "+12.4%",
        trend: "up",
        icon: Package,
        color: "blue"
      },
      {
        title: "Producción Real",
        value: "49,880",
        unit: "kg",
        change: "+10.2%",
        trend: "up",
        icon: Zap,
        color: "green"
      },
      {
        title: "Cumplimiento",
        value: "93.8",
        unit: "%",
        change: "-2.5%",
        trend: "down",
        icon: Target,
        color: "orange"
      },
      {
        title: "Eficiencia Global",
        value: "89.7",
        unit: "%",
        change: "+4.3%",
        trend: "up",
        icon: TrendingUp,
        color: "purple"
      }
    ],
    year: [
      {
        title: "Producción Planificada",
        value: "624k",
        unit: "kg",
        change: "+18.9%",
        trend: "up",
        icon: Package,
        color: "blue"
      },
      {
        title: "Producción Real",
        value: "589k",
        unit: "kg",
        change: "+15.7%",
        trend: "up",
        icon: Zap,
        color: "green"
      },
      {
        title: "Cumplimiento",
        value: "94.4",
        unit: "%",
        change: "+1.8%",
        trend: "up",
        icon: Target,
        color: "orange"
      },
      {
        title: "Eficiencia Global",
        value: "91.2",
        unit: "%",
        change: "+6.5%",
        trend: "up",
        icon: TrendingUp,
        color: "purple"
      }
    ]
  };

  const kpiData = kpiDataByPeriod[selectedPeriod];

  const productionDataByPeriod = {
    week: [
      { name: "Lun", planificado: 1800, real: 1650 },
      { name: "Mar", planificado: 2100, real: 2050 },
      { name: "Mié", planificado: 1950, real: 1900 },
      { name: "Jue", planificado: 2300, real: 2200 },
      { name: "Vie", planificado: 2200, real: 2100 },
      { name: "Sáb", planificado: 1900, real: 1890 },
      { name: "Dom", planificado: 1200, real: 1100 }
    ],
    month: [
      { name: "Sem 1", planificado: 11500, real: 10800 },
      { name: "Sem 2", planificado: 12800, real: 12200 },
      { name: "Sem 3", planificado: 13200, real: 12900 },
      { name: "Sem 4", planificado: 14840, real: 14080 }
    ],
    year: [
      { name: "Ene", planificado: 48000, real: 45500 },
      { name: "Feb", planificado: 52000, real: 49200 },
      { name: "Mar", planificado: 51000, real: 48800 },
      { name: "Abr", planificado: 54000, real: 51200 },
      { name: "May", planificado: 53500, real: 50900 },
      { name: "Jun", planificado: 55800, real: 53000 },
      { name: "Jul", planificado: 52400, real: 49800 },
      { name: "Ago", planificado: 51200, real: 48600 },
      { name: "Sep", planificado: 53600, real: 51000 },
      { name: "Oct", planificado: 54800, real: 52100 },
      { name: "Nov", planificado: 56200, real: 53500 },
      { name: "Dic", planificado: 49500, real: 47100 }
    ]
  };

  const productionData = productionDataByPeriod[selectedPeriod];

  const lineEfficiencyData = [
    { name: "Línea 1 (IQF)", efficiency: 94, capacity: 2500 },
    { name: "Línea 2 (Calibrado)", efficiency: 91, capacity: 4000 },
    { name: "Línea 3 (Empaque)", efficiency: 75, capacity: 1500 },
    { name: "Línea 4 (Pre-Cool)", efficiency: 88, capacity: 3000 }
  ];

  const historicalData = [
    { date: "Sem 1", kg: 52000 },
    { date: "Sem 2", kg: 58000 },
    { date: "Sem 3", kg: 55000 },
    { date: "Sem 4", kg: 61000 },
    { date: "Sem 5", kg: 59000 },
    { date: "Sem 6", kg: 64000 }
  ];

  return (
    <div className="p-8 max-w-[1800px] mx-auto">
      <SectionHeader
        icon={LayoutDashboard}
        title="Dashboard de Optimización"
        subtitle="Monitoreo de KPIs del modelo MILP y desempeño operativo"
        badge="BLUEPRINT VIEW"
      >
        <div className="flex items-center gap-3">
          {/* Period Selector with States */}
          <div className="flex items-center gap-2 bg-slate-900/50 rounded-lg p-1 border border-slate-800">
            {(["week", "month", "year"] as const).map((period) => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period)}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-all ${
                  selectedPeriod === period
                    ? "bg-orange-600 text-white shadow-lg"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {period === "week" && "Semana"}
                {period === "month" && "Mes"}
                {period === "year" && "Año"}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <ButtonWithTooltip
              icon={Filter}
              label="Filtros"
              tooltip="Filtra los KPIs por línea de producción, producto o máquina específica. Los datos provienen del modelo MILP ejecutado."
              state={filterActive ? "active" : "normal"}
              variant="ghost"
              onClick={() => setFilterActive(!filterActive)}
              size="sm"
            />
            
            <ButtonWithTooltip
              icon={RefreshCw}
              label="Actualizar"
              tooltip="Actualiza la vista con los últimos datos sincronizados desde SAP ERP. Última actualización: hace 5 min."
              state="normal"
              variant="ghost"
              size="sm"
            />

            <ButtonWithTooltip
              icon={Download}
              label="Exportar"
              tooltip="Exporta el reporte completo del dashboard en formato PDF o Excel con todos los KPIs y gráficos del período seleccionado."
              state="disabled"
              variant="ghost"
              size="sm"
            />
          </div>
        </div>
      </SectionHeader>

      <AnnotationBadge type="info" className="mb-8">
        <strong>Fuente de datos:</strong> Los KPIs provienen del modelo de optimización MILP (producción planificada) 
        y del sistema ERP integrado (producción real). Esta vista es de solo lectura y refleja el estado actual del gemelo digital.
      </AnnotationBadge>

      {/* Period Indicator */}
      <div className="mb-6 bg-blue-600/10 border border-blue-600/30 rounded-lg p-4">
        <p className="text-sm text-blue-400 flex items-center gap-2">
          <Info className="w-4 h-4" />
          <strong>Vista activa:</strong> {selectedPeriod === "week" ? "Vista semanal" : selectedPeriod === "month" ? "Vista mensual" : "Vista anual"} — 
          Los indicadores se ajustan al horizonte seleccionado. Los datos reflejan las métricas correspondientes al período elegido.
        </p>
      </div>

      {/* KPIs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {kpiData.map((kpi, idx) => {
          const Icon = kpi.icon;
          const colorClasses = {
            blue: "from-blue-600 to-blue-700 shadow-blue-900/30",
            green: "from-green-600 to-green-700 shadow-green-900/30",
            orange: "from-orange-600 to-orange-700 shadow-orange-900/30",
            purple: "from-purple-600 to-purple-700 shadow-purple-900/30"
          };

          return (
            <div
              key={idx}
              className="bg-[#1a1a24] border border-slate-800 rounded-lg p-6 hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-10 h-10 bg-gradient-to-br ${colorClasses[kpi.color as keyof typeof colorClasses]} rounded-lg flex items-center justify-center shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <span className={`text-xs font-mono px-2 py-1 rounded ${
                  kpi.trend === "up" ? "bg-green-600/20 text-green-400" : "bg-red-600/20 text-red-400"
                }`}>
                  {kpi.change}
                </span>
              </div>
              <p className="text-xs text-slate-400 mb-1 uppercase tracking-wider">{kpi.title}</p>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-white">{kpi.value}</span>
                <span className="text-sm text-slate-500">{kpi.unit}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Planificado vs Real */}
        <IndustrialCard 
          title="Producción: Planificado vs Real" 
          subtitle={`Vista filtrada por horizonte temporal: ${
            selectedPeriod === "week" ? "última semana (7 días)" : 
            selectedPeriod === "month" ? "último mes (4 semanas)" : 
            "último año (12 meses)"
          }`}
        >
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={productionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a35" />
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1a1a24",
                  border: "1px solid #2a2a35",
                  borderRadius: "8px",
                  color: "#fff"
                }}
              />
              <Bar dataKey="planificado" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="real" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-6 mt-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-600 rounded" />
              <span className="text-slate-400">Planificado (MILP)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-600 rounded" />
              <span className="text-slate-400">Real (ERP)</span>
            </div>
          </div>
        </IndustrialCard>

        {/* Eficiencia por Línea */}
        <IndustrialCard title="Eficiencia por Línea de Producción" subtitle="% de utilización vs capacidad nominal">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={lineEfficiencyData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a35" />
              <XAxis type="number" stroke="#94a3b8" fontSize={12} domain={[0, 100]} />
              <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={11} width={120} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#1a1a24",
                  border: "1px solid #2a2a35",
                  borderRadius: "8px",
                  color: "#fff"
                }}
              />
              <Bar dataKey="efficiency" radius={[0, 4, 4, 0]}>
                {lineEfficiencyData.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={entry.efficiency >= 90 ? "#10b981" : entry.efficiency >= 80 ? "#f59e0b" : "#ef4444"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-600 rounded" />
              <span className="text-slate-400">≥ 90%</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-amber-600 rounded" />
              <span className="text-slate-400">80-89%</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-600 rounded" />
              <span className="text-slate-400">&lt; 80%</span>
            </div>
          </div>
        </IndustrialCard>
      </div>

      {/* Historical Trend */}
      <IndustrialCard title="Historial de Producción" subtitle="Últimas 6 semanas (acumulado)">
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={historicalData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2a2a35" />
            <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} />
            <YAxis stroke="#94a3b8" fontSize={12} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1a1a24",
                border: "1px solid #2a2a35",
                borderRadius: "8px",
                color: "#fff"
              }}
            />
            <Line
              type="monotone"
              dataKey="kg"
              stroke="#f97316"
              strokeWidth={3}
              dot={{ fill: "#f97316", r: 5 }}
              activeDot={{ r: 7 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </IndustrialCard>

      {/* Footer Annotations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <AnnotationBadge type="warning">
          <strong>Modelo Matemático:</strong> El objetivo del MILP es maximizar la función: 
          <code className="ml-1 px-2 py-0.5 bg-slate-900 rounded text-xs">max Σ(kg_salida)</code> 
          respetando restricciones de capacidad, inventarios y políticas operativas.
        </AnnotationBadge>

        <AnnotationBadge type="success">
          <strong>Sincronización ERP:</strong> Los datos reales se actualizan cada 15 minutos desde SAP. 
          Las desviaciones superiores al 5% activan alertas automáticas al equipo de planificación.
        </AnnotationBadge>
      </div>
    </div>
  );
}