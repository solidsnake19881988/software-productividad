import { Settings, Package, Code, FileText, Database, Edit, Trash2, Plus, RefreshCw, CheckCircle } from "lucide-react";
import { SectionHeader } from "./SectionHeader";
import { AnnotationBadge } from "./AnnotationBadge";
import { IndustrialCard } from "./IndustrialCard";
import { useState } from "react";

type DataCategory = "products" | "parameters" | "policies" | "sync";

interface Product {
  id: string;
  code: string;
  name: string;
  unitCost: number;
  minBatch: number;
  maxBatch: number;
  allowedMachines: string[];
}

interface MILPParameter {
  id: string;
  name: string;
  value: string;
  unit: string;
  description: string;
  category: string;
}

interface OperationalPolicy {
  id: string;
  name: string;
  rule: string;
  enabled: boolean;
  priority: number;
}

export function MaintainersDataView() {
  const [activeCategory, setActiveCategory] = useState<DataCategory>("products");
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const products: Product[] = [
    {
      id: "p001",
      code: "ARN-PREM-1KG",
      name: "Arándanos Premium 1kg",
      unitCost: 12.50,
      minBatch: 500,
      maxBatch: 5000,
      allowedMachines: ["IQF Tunnel 01", "IQF Tunnel 02"]
    },
    {
      id: "p002",
      code: "FRM-IQF-500G",
      name: "Frambuesas IQF 500g",
      unitCost: 15.20,
      minBatch: 300,
      maxBatch: 3000,
      allowedMachines: ["IQF Tunnel 01", "Pre-Cooler A"]
    },
    {
      id: "p003",
      code: "MIX-CAL-1KG",
      name: "Mixtos Calibrados 1kg",
      unitCost: 9.80,
      minBatch: 1000,
      maxBatch: 8000,
      allowedMachines: ["Sorter Optical X1", "Packer Auto 500"]
    }
  ];

  const parameters: MILPParameter[] = [
    {
      id: "prm001",
      name: "tiempo_setup",
      value: "30",
      unit: "minutos",
      description: "Tiempo de cambio entre productos en máquinas",
      category: "Operacional"
    },
    {
      id: "prm002",
      name: "factor_perdida",
      value: "0.02",
      unit: "ratio",
      description: "Factor de pérdida/merma en procesamiento",
      category: "Calidad"
    },
    {
      id: "prm003",
      name: "costo_energia_kwh",
      value: "0.15",
      unit: "USD/kWh",
      description: "Costo de energía eléctrica",
      category: "Costos"
    },
    {
      id: "prm004",
      name: "max_overtime_hours",
      value: "4",
      unit: "horas",
      description: "Máximo de horas extra permitidas por día",
      category: "Restricciones"
    },
    {
      id: "prm005",
      name: "inventory_buffer",
      value: "0.10",
      unit: "ratio",
      description: "Buffer de seguridad de inventario (10%)",
      category: "Inventario"
    }
  ];

  const policies: OperationalPolicy[] = [
    {
      id: "pol001",
      name: "FIFO - Primero en Entrar, Primero en Salir",
      rule: "IF product.arrivalTime < other.arrivalTime THEN priority = HIGH",
      enabled: true,
      priority: 1
    },
    {
      id: "pol002",
      name: "Prioridad: Producto sin marinar",
      rule: "IF product.marinationType == 'NONE' THEN priority = HIGH",
      enabled: true,
      priority: 2
    },
    {
      id: "pol003",
      name: "Prioridad: Producto marinado",
      rule: "IF product.marinationType == 'MARINATED' THEN priority = MEDIUM",
      enabled: false,
      priority: 3
    },
    {
      id: "pol004",
      name: "Ventanas de colación (pausas programadas)",
      rule: "IF time IN [12:00-13:00, 18:00-18:30] THEN capacity = 0",
      enabled: true,
      priority: 4
    },
    {
      id: "pol005",
      name: "Penalización por espera excesiva",
      rule: "IF waitTime > 120min THEN cost += waitTime * penaltyFactor",
      enabled: true,
      priority: 5
    },
    {
      id: "pol006",
      name: "Batch mínimo económico",
      rule: "IF batch_size < 500kg THEN reject_order",
      enabled: false,
      priority: 6
    }
  ];

  const categories = [
    { id: "products", name: "Productos", icon: Package, count: products.length },
    { id: "parameters", name: "Parámetros MILP", icon: Code, count: parameters.length },
    { id: "policies", name: "Políticas Operativas", icon: FileText, count: policies.length },
    { id: "sync", name: "Sincronización ERP", icon: RefreshCw, count: 0 }
  ];

  return (
    <div className="p-8 max-w-[1800px] mx-auto">
      <SectionHeader
        icon={Settings}
        title="Mantenedores - Master Data"
        subtitle="Gestión de productos, parámetros del modelo MILP y políticas operativas"
        badge="CONFIG"
      />

      <AnnotationBadge type="info" className="mb-8">
        <strong>Fuente maestra de datos:</strong> Los mantenedores contienen la configuración esencial del modelo MILP: 
        catálogo de productos (con códigos ERP), parámetros matemáticos del modelo (costos, factores, límites), 
        y políticas operativas (reglas de negocio). Cualquier cambio aquí afecta directamente el comportamiento del optimizador.
      </AnnotationBadge>

      {/* Category Tabs */}
      <div className="flex gap-2 mb-6 bg-[#1a1a24] border border-slate-800 rounded-lg p-2">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as DataCategory)}
              className={`flex-1 flex items-center justify-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive
                  ? "bg-orange-600 text-white shadow-lg shadow-orange-900/30"
                  : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{cat.name}</span>
              {cat.count > 0 && (
                <span className={`px-2 py-0.5 text-xs rounded-full ${
                  isActive ? "bg-orange-700" : "bg-slate-700"
                }`}>
                  {cat.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main List */}
        <div className="lg:col-span-2">
          {/* Products View */}
          {activeCategory === "products" && (
            <IndustrialCard
              title="Catálogo de Productos"
              subtitle="Productos definidos en el sistema con sus restricciones"
              headerAction={
                <button className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded text-xs transition-colors flex items-center gap-2">
                  <Plus className="w-3 h-3" />
                  Nuevo
                </button>
              }
            >
              <div className="space-y-3">
                {products.map((product) => (
                  <div
                    key={product.id}
                    onClick={() => setSelectedItem(product)}
                    className={`bg-slate-900/50 rounded-lg p-4 border cursor-pointer transition-colors ${
                      selectedItem?.id === product.id ? "border-orange-600" : "border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold text-white">{product.name}</h4>
                          <span className="px-2 py-0.5 text-xs font-mono bg-slate-800 text-slate-400 rounded">
                            {product.code}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500">ID: {product.id}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors">
                          <Edit className="w-3 h-3" />
                        </button>
                        <button className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded transition-colors">
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-3 text-xs">
                      <div>
                        <p className="text-slate-400 mb-1">Costo Unitario</p>
                        <p className="text-white font-semibold">${product.unitCost}</p>
                      </div>
                      <div>
                        <p className="text-slate-400 mb-1">Batch Mínimo</p>
                        <p className="text-white font-semibold">{product.minBatch} kg</p>
                      </div>
                      <div>
                        <p className="text-slate-400 mb-1">Batch Máximo</p>
                        <p className="text-white font-semibold">{product.maxBatch} kg</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </IndustrialCard>
          )}

          {/* Parameters View */}
          {activeCategory === "parameters" && (
            <IndustrialCard
              title="Parámetros del Modelo MILP"
              subtitle="Constantes y coeficientes utilizados en la optimización"
              headerAction={
                <button className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded text-xs transition-colors flex items-center gap-2">
                  <Plus className="w-3 h-3" />
                  Nuevo
                </button>
              }
            >
              <div className="space-y-2">
                {parameters.map((param) => (
                  <div
                    key={param.id}
                    onClick={() => setSelectedItem(param)}
                    className={`bg-slate-900/50 rounded-lg p-4 border cursor-pointer transition-colors ${
                      selectedItem?.id === param.id ? "border-orange-600" : "border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <code className="text-sm font-mono text-orange-400">{param.name}</code>
                          <span className="px-2 py-0.5 text-xs bg-blue-600/20 text-blue-400 border border-blue-600/30 rounded">
                            {param.category}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mb-2">{param.description}</p>
                        <div className="flex items-center gap-4 text-xs">
                          <div>
                            <span className="text-slate-500">Valor: </span>
                            <span className="text-white font-semibold">{param.value}</span>
                          </div>
                          <div>
                            <span className="text-slate-500">Unidad: </span>
                            <span className="text-slate-400">{param.unit}</span>
                          </div>
                        </div>
                      </div>
                      <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors">
                        <Edit className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </IndustrialCard>
          )}

          {/* Policies View */}
          {activeCategory === "policies" && (
            <IndustrialCard
              title="Políticas Operativas"
              subtitle="Reglas de negocio aplicadas al modelo"
              headerAction={
                <button className="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded text-xs transition-colors flex items-center gap-2">
                  <Plus className="w-3 h-3" />
                  Nueva
                </button>
              }
            >
              <div className="space-y-3">
                {policies.map((policy) => (
                  <div
                    key={policy.id}
                    onClick={() => setSelectedItem(policy)}
                    className={`bg-slate-900/50 rounded-lg p-4 border cursor-pointer transition-colors ${
                      selectedItem?.id === policy.id ? "border-orange-600" : "border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold text-white">{policy.name}</h4>
                          <span className={`px-2 py-1 text-xs rounded border flex items-center gap-1 ${
                            policy.enabled
                              ? "bg-green-600/20 text-green-400 border-green-600/30"
                              : "bg-slate-600/20 text-slate-400 border-slate-600/30"
                          }`}>
                            <div className={`w-1.5 h-1.5 rounded-full ${policy.enabled ? "bg-green-500" : "bg-slate-500"}`} />
                            {policy.enabled ? "Activa" : "Inactiva"}
                          </span>
                          <span className="px-2 py-1 text-xs bg-blue-600/20 text-blue-400 border border-blue-600/30 rounded">
                            P{policy.priority}
                          </span>
                        </div>
                        <code className="text-xs font-mono text-blue-400 bg-slate-800/50 px-2 py-1 rounded block">
                          {policy.rule}
                        </code>
                        
                        {/* Impact description */}
                        <div className="mt-3 pt-3 border-t border-slate-800">
                          <p className="text-xs text-slate-400">
                            <strong className="text-slate-300">Impacto operativo:</strong>
                            {policy.id === "pol001" && " Define el orden de procesamiento de productos en inventario."}
                            {policy.id === "pol002" && " Productos sin marinar se procesan primero para maximizar frescura."}
                            {policy.id === "pol003" && " Productos marinados tienen prioridad media (si está activa)."}
                            {policy.id === "pol004" && " Pausa la producción en horarios de colación del personal."}
                            {policy.id === "pol005" && " Penaliza órdenes con tiempos de espera prolongados en la función objetivo."}
                            {policy.id === "pol006" && " Rechaza órdenes por debajo del lote mínimo económico (si está activa)."}
                          </p>
                        </div>
                      </div>
                      <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors">
                        <Edit className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </IndustrialCard>
          )}

          {/* Sync View */}
          {activeCategory === "sync" && (
            <IndustrialCard title="Sincronización con ERP" subtitle="Estado de integración con sistemas externos">
              <div className="space-y-4">
                <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-800">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-600/20 rounded-lg flex items-center justify-center">
                        <Database className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">SAP ERP</h4>
                        <p className="text-xs text-slate-400">Sistema de gestión empresarial</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                      <span className="text-xs text-green-400 font-semibold">CONECTADO</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-xs">
                    <div className="bg-slate-800/50 rounded p-3">
                      <p className="text-slate-400 mb-1">Última Sync</p>
                      <p className="text-white font-mono">14:35:22</p>
                    </div>
                    <div className="bg-slate-800/50 rounded p-3">
                      <p className="text-slate-400 mb-1">Frecuencia</p>
                      <p className="text-white font-mono">15 min</p>
                    </div>
                    <div className="bg-slate-800/50 rounded p-3">
                      <p className="text-slate-400 mb-1">Registros</p>
                      <p className="text-white font-mono">1,247</p>
                    </div>
                  </div>

                  <button className="w-full mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors flex items-center justify-center gap-2">
                    <RefreshCw className="w-4 h-4" />
                    Sincronizar Ahora
                  </button>
                </div>

                <div className="bg-green-600/10 border border-green-600/30 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-semibold text-green-400 mb-1">Sincronización Activa</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Los datos de producción real, inventarios y órdenes de compra se sincronizan automáticamente 
                        desde SAP cada 15 minutos. La última sincronización fue exitosa.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </IndustrialCard>
          )}
        </div>

        {/* Detail Sidebar */}
        <div className="lg:col-span-1">
          <IndustrialCard title="Detalle del Registro" subtitle={selectedItem ? "Vista completa" : "Selecciona un item"}>
            {selectedItem ? (
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-wider mb-2">ID</p>
                  <p className="text-sm font-mono text-white bg-slate-900 px-3 py-2 rounded border border-slate-800">
                    {selectedItem.id}
                  </p>
                </div>

                {selectedItem.code && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider mb-2">Código</p>
                    <p className="text-sm font-mono text-white bg-slate-900 px-3 py-2 rounded border border-slate-800">
                      {selectedItem.code}
                    </p>
                  </div>
                )}

                {selectedItem.name && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider mb-2">Nombre</p>
                    <p className="text-sm text-white bg-slate-900 px-3 py-2 rounded border border-slate-800">
                      {selectedItem.name}
                    </p>
                  </div>
                )}

                {selectedItem.allowedMachines && (
                  <div>
                    <p className="text-xs text-slate-400 uppercase tracking-wider mb-2">Máquinas Permitidas</p>
                    <div className="space-y-1">
                      {selectedItem.allowedMachines.map((machine: string, idx: number) => (
                        <div key={idx} className="text-xs bg-slate-900 px-3 py-2 rounded border border-slate-800 text-slate-300">
                          {machine}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-4 border-t border-slate-800">
                  <button className="w-full px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm transition-colors flex items-center justify-center gap-2">
                    <Edit className="w-4 h-4" />
                    Editar Registro (Mock)
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <Database className="w-12 h-12 text-slate-700 mx-auto mb-4" />
                <p className="text-sm text-slate-500">
                  Selecciona un registro de la lista para ver sus detalles completos
                </p>
              </div>
            )}
          </IndustrialCard>
        </div>
      </div>

      {/* Footer Annotations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <AnnotationBadge type="warning">
          <strong>Impacto en el modelo:</strong> Los parámetros MILP son coeficientes directos de la función objetivo 
          y restricciones. Modificar <code className="mx-1 px-2 py-0.5 bg-slate-900 rounded text-xs">costo_energia_kwh</code> 
          afecta inmediatamente los términos de costo en la optimización.
        </AnnotationBadge>

        <AnnotationBadge type="success">
          <strong>Trazabilidad:</strong> Todos los cambios en mantenedores se registran con timestamp, usuario y razón. 
          Las políticas pueden activarse/desactivarse sin eliminarlas, permitiendo experimentos controlados.
        </AnnotationBadge>
      </div>
    </div>
  );
}