import React, { useState } from "react";
import { 
  Clock, 
  Calendar, 
  ChevronLeft, 
  ChevronRight, 
  GripHorizontal, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  Play, 
  Save, 
  RefreshCw,
  MoreVertical,
  Cpu,
  ArrowRight
} from "lucide-react";
import { toast } from "sonner";
import { Machine } from "@/app/App";

interface ManualPlannerProps {
  machines: Machine[];
}

interface ScheduleItem {
  id: string;
  machineId: string;
  product: string;
  startTime: number; // minutes from 08:00
  duration: number; // minutes
  color: string;
  isFeasible: boolean;
  error?: string;
}

export function ManualPlanner({ machines }: ManualPlannerProps) {
  const [schedule, setSchedule] = useState<ScheduleItem[]>([
    { id: "1", machineId: "m-1", product: "Arándano IQF", startTime: 60, duration: 180, color: "#f97316", isFeasible: true },
    { id: "2", machineId: "m-1", product: "Frambuesa Premium", startTime: 300, duration: 120, color: "#ef4444", isFeasible: false, error: "Conflicto con mantenimiento preventivo" },
    { id: "3", machineId: "m-3", product: "Mix Berries 1kg", startTime: 120, duration: 240, color: "#3b82f6", isFeasible: true },
    { id: "4", machineId: "m-4", product: "Bolsa Regular", startTime: 0, duration: 400, color: "#22c55e", isFeasible: true },
  ]);

  const hours = Array.from({ length: 18 }).map((_, i) => i + 8); // 08:00 to 01:00

  const handleDragOver = (e: React.DragEvent) => e.preventDefault();
  
  const handleDrop = (e: React.DragEvent, machineId: string, hour: number) => {
    e.preventDefault();
    const itemId = e.dataTransfer.getData("itemId");
    const newStartTime = (hour - 8) * 60;
    
    setSchedule(prev => prev.map(item => 
      item.id === itemId 
        ? { ...item, machineId, startTime: newStartTime, isFeasible: Math.random() > 0.3 } 
        : item
    ));
    toast.info("Planificación actualizada manualmente");
  };

  const validatePlan = () => {
    toast.promise(new Promise(res => setTimeout(res, 1000)), {
      loading: 'Validando restricciones del modelo...',
      success: 'Validación completada. 3 advertencias detectadas.',
      error: 'Error en validación',
    });
  };

  return (
    <div className="p-8 space-y-6 flex flex-col h-full animate-in fade-in duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h3 className="text-2xl font-bold text-white tracking-tight">Planificador Manual</h3>
          <p className="text-sm text-slate-500">Intervención directa sobre el scheduling optimizado.</p>
        </div>
        <div className="flex gap-3">
           <button 
            onClick={() => setSchedule(prev => prev.map(s => ({ ...s, isFeasible: true })))}
            className="flex items-center gap-2 bg-slate-800 text-slate-300 rounded-lg px-4 py-2 text-sm font-bold hover:bg-slate-700 transition-all border border-slate-700"
           >
              <RefreshCw className="w-4 h-4" /> Recalcular Tiempos
           </button>
           <button 
            onClick={validatePlan}
            className="flex items-center gap-2 bg-slate-800 text-orange-500 rounded-lg px-4 py-2 text-sm font-bold hover:bg-slate-700 transition-all border border-orange-500/20"
           >
              <CheckCircle2 className="w-4 h-4" /> Validar Factibilidad
           </button>
           <button className="flex items-center gap-2 bg-orange-600 text-white rounded-lg px-6 py-2 text-sm font-bold hover:bg-orange-700 transition-all shadow-lg shadow-orange-900/20">
              <Save className="w-4 h-4" /> Guardar Planificación
           </button>
        </div>
      </div>

      <div className="flex-1 bg-[#12121a] rounded-xl border border-slate-800 flex flex-col overflow-hidden shadow-2xl">
        {/* Timeline Header */}
        <div className="flex border-b border-slate-800 bg-slate-900/50 sticky top-0 z-20">
           <div className="w-64 p-4 border-r border-slate-800 flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Activos / Máquinas</span>
              <Settings className="w-3.5 h-3.5 text-slate-600" />
           </div>
           <div className="flex-1 flex overflow-x-auto scrollbar-hide">
              {hours.map(h => (
                <div key={h} className="min-w-[120px] p-3 text-center border-r border-slate-800/50 flex flex-col gap-1">
                   <span className="text-xs font-mono font-bold text-white">{(h % 24).toString().padStart(2, '0')}:00</span>
                   <span className="text-[8px] text-slate-600 font-bold uppercase tracking-tighter">Bloque 60m</span>
                </div>
              ))}
           </div>
        </div>

        {/* Timeline Content */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden">
           {machines.map(machine => (
             <div key={machine.id} className="flex border-b border-slate-800 min-h-[100px] group/row">
                {/* Machine Info Side */}
                <div className="w-64 p-4 border-r border-slate-800 bg-slate-900/20 flex flex-col justify-between group-hover/row:bg-slate-900/40 transition-colors">
                   <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center border border-slate-700">
                         <Cpu className="w-4 h-4 text-slate-400" />
                      </div>
                      <div>
                         <p className="text-xs font-bold text-white truncate">{machine.name}</p>
                         <p className="text-[9px] text-slate-500 uppercase">{machine.type}</p>
                      </div>
                   </div>
                   <div className="flex items-center justify-between text-[9px] font-mono">
                      <span className="text-slate-600">CAP: {machine.capacity} kg/h</span>
                      <span className="text-green-500 font-bold">{machine.status}</span>
                   </div>
                </div>

                {/* Grid Drop Zones */}
                <div className="flex-1 relative flex">
                   {hours.map(h => (
                     <div 
                      key={h} 
                      className="min-w-[120px] border-r border-slate-800/30 relative"
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleDrop(e, machine.id, h)}
                     >
                        {/* Grid Lines */}
                        <div className="absolute left-1/2 top-0 h-full w-[1px] bg-slate-800/10 pointer-events-none" />
                     </div>
                   ))}

                   {/* Scheduled Items Overlay */}
                   {schedule.filter(s => s.machineId === machine.id).map(item => (
                     <div 
                      key={item.id}
                      draggable
                      onDragStart={(e) => e.dataTransfer.setData("itemId", item.id)}
                      className={`absolute top-4 h-[70px] rounded-lg border-2 flex flex-col p-3 cursor-grab active:cursor-grabbing transition-all hover:scale-[1.02] shadow-xl group/item ${
                        item.isFeasible 
                          ? "bg-slate-800 border-slate-700 hover:border-orange-500" 
                          : "bg-red-500/10 border-red-500/50 shadow-red-500/10"
                      }`}
                      style={{ 
                        left: `${(item.startTime / 60) * 120}px`, 
                        width: `${(item.duration / 60) * 120}px` 
                      }}
                     >
                        <div className="flex justify-between items-start">
                           <div className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: item.color }} />
                              <span className="text-[10px] font-bold text-white uppercase truncate max-w-[100px]">{item.product}</span>
                           </div>
                           <MoreVertical className="w-3 h-3 text-slate-600 opacity-0 group-hover/item:opacity-100 transition-opacity" />
                        </div>
                        <div className="mt-auto flex items-center justify-between">
                           <div className="flex items-center gap-1.5">
                              <Clock className="w-2.5 h-2.5 text-slate-500" />
                              <span className="text-[9px] font-mono text-slate-500">{(item.duration/60).toFixed(1)}h</span>
                           </div>
                           {!item.isFeasible && (
                             <div className="group relative">
                                <AlertTriangle className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                                <div className="absolute bottom-full right-0 mb-2 w-48 p-2 bg-slate-900 border border-red-500/50 rounded-lg text-[9px] text-red-400 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 shadow-2xl">
                                   <p className="font-bold mb-1 underline">RESTRICCIÓN VIOLADA:</p>
                                   {item.error}
                                </div>
                             </div>
                           )}
                           {item.isFeasible && <CheckCircle2 className="w-3.5 h-3.5 text-green-500/50" />}
                        </div>
                     </div>
                   ))}
                </div>
             </div>
           ))}
        </div>
      </div>

      {/* Footer / Stats Recalculated */}
      <div className="grid grid-cols-4 gap-6">
         <PlanStat label="PRODUCCIÓN ESTIMADA" value="28.4 Tons" color="text-white" />
         <PlanStat label="UTILIZACIÓN MEDIA" value="78.2%" color="text-orange-500" />
         <PlanStat label="FEASIBILITY SCORE" value="94/100" color="text-green-500" />
         <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center">
               <AlertTriangle className="w-5 h-5 text-red-500" />
            </div>
            <div>
               <p className="text-[10px] font-bold text-red-500 uppercase">Conflictos Pendientes</p>
               <p className="text-xl font-bold text-white">01</p>
            </div>
         </div>
      </div>
    </div>
  );
}

function PlanStat({ label, value, color }: any) {
  return (
    <div className="bg-[#12121a] border border-slate-800 rounded-xl p-4 shadow-lg">
       <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">{label}</p>
       <p className={`text-xl font-bold ${color} tracking-tight`}>{value}</p>
    </div>
  );
}
