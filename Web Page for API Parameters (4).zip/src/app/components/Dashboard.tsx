import React from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell,
  AreaChart,
  Area
} from "recharts";
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Zap,
  Package,
  Activity
} from "lucide-react";

const data = [
  { name: "Lun", planificado: 4000, real: 3800 },
  { name: "Mar", planificado: 3000, real: 3200 },
  { name: "Mie", planificado: 2000, real: 1900 },
  { name: "Jue", planificado: 2780, real: 2780 },
  { name: "Vie", planificado: 1890, real: 2100 },
  { name: "Sab", planificado: 2390, real: 2300 },
  { name: "Dom", planificado: 3490, real: 3100 },
];

const efficiencyData = [
  { name: "Línea 1 (IQF)", value: 88, color: "#f97316" },
  { name: "Línea 2 (Calibrado)", value: 92, color: "#22c55e" },
  { name: "Línea 3 (Empaque)", value: 75, color: "#ef4444" },
];

const productDistribution = [
  { name: "Producto A", value: 400 },
  { name: "Producto B", value: 300 },
  { name: "Producto C", value: 300 },
  { name: "Producto D", value: 200 },
  { name: "Producto E", value: 150 },
];

const COLORS = ["#f97316", "#22c55e", "#3b82f6", "#a855f7", "#ec4899"];

export function Dashboard() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Top Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Producción Planificada" 
          value="24.5 tons" 
          change="+4.5%" 
          isPositive={true}
          icon={Package}
        />
        <StatCard 
          title="Eficiencia Global (OEE)" 
          value="84.2%" 
          change="-1.2%" 
          isPositive={false}
          icon={Zap}
        />
        <StatCard 
          title="Fulfillment" 
          value="98.5%" 
          change="+0.5%" 
          isPositive={true}
          icon={CheckCircle2}
        />
        <StatCard 
          title="Tiempo Operativo" 
          value="16.5h / 17h" 
          change="On Track" 
          isPositive={true}
          icon={Clock}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-[#12121a] rounded-xl border border-slate-800 p-6">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-semibold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-orange-500" />
              Producción: Planificado vs Real
            </h3>
            <select className="bg-slate-800 border-none rounded px-3 py-1 text-xs text-slate-300 focus:ring-1 focus:ring-orange-500">
              <option>Esta Semana</option>
              <option>Hoy</option>
              <option>Mes Pasado</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorPlan" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f97316" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorReal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `${v/1000}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#1e293b", border: "none", borderRadius: "8px", color: "#fff" }}
                  itemStyle={{ color: "#fff" }}
                />
                <Area type="monotone" dataKey="planificado" stroke="#f97316" fillOpacity={1} fill="url(#colorPlan)" strokeWidth={2} />
                <Area type="monotone" dataKey="real" stroke="#22c55e" fillOpacity={1} fill="url(#colorReal)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Efficiency by Line */}
        <div className="bg-[#12121a] rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-8 flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-500" />
            Eficiencia por Línea
          </h3>
          <div className="space-y-6">
            {efficiencyData.map((line) => (
              <div key={line.name} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">{line.name}</span>
                  <span className="text-white font-medium">{line.value}%</span>
                </div>
                <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all duration-1000" 
                    style={{ width: `${line.value}%`, backgroundColor: line.color }}
                  />
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-10 pt-6 border-t border-slate-800">
            <div className="flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-500 shrink-0" />
              <div>
                <p className="text-sm font-medium text-red-400">Alerta de Cuello de Botella</p>
                <p className="text-xs text-red-400/80">Línea 3 operando al 110% de capacidad.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Distribution & History */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-[#12121a] rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Distribución de Productos</h3>
          <div className="flex items-center">
            <div className="h-[250px] w-1/2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={productDistribution}
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {productDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="w-1/2 space-y-3">
              {productDistribution.map((p, i) => (
                <div key={p.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-xs text-slate-400">{p.name}</span>
                  <span className="ml-auto text-xs text-white font-medium">{p.value} kg</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-[#12121a] rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-6">Historial Reciente</h3>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-4 p-3 rounded-lg hover:bg-slate-800/50 transition-colors border border-transparent hover:border-slate-700">
                <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-orange-500">
                  <LineChart className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-white">Planificación_2026_01_2{i}</p>
                  <p className="text-xs text-slate-500">24 de Enero, 2026 • Finalizado</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-green-500">98% Cumplimiento</p>
                  <p className="text-xs text-slate-500">22.4 tons</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-2 text-sm text-orange-500 hover:text-orange-400 font-medium border border-orange-500/20 rounded-lg hover:bg-orange-500/5">
            Ver todos los informes
          </button>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, change, isPositive, icon: Icon }: any) {
  return (
    <div className="bg-[#12121a] p-6 rounded-xl border border-slate-800 hover:border-orange-500/30 transition-all group">
      <div className="flex justify-between items-start mb-4">
        <div className="p-2 rounded-lg bg-orange-500/10 text-orange-500 group-hover:scale-110 transition-transform">
          <Icon className="w-5 h-5" />
        </div>
        <div className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${
          isPositive ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
        }`}>
          {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          {change}
        </div>
      </div>
      <div>
        <p className="text-sm text-slate-400 font-medium mb-1">{title}</p>
        <p className="text-2xl font-bold text-white tracking-tight">{value}</p>
      </div>
    </div>
  );
}
