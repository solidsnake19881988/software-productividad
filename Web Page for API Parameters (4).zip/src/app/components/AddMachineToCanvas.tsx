import { Plus, X, Grid3x3 } from "lucide-react";
import { useState } from "react";

interface MachinePreview {
  id: string;
  name: string;
  type: string;
  icon: string;
  capacity: number;
}

interface AddMachineToCanvasProps {
  onAdd: (profile: { id: string; name: string; capacity: number }) => void;
}

export function AddMachineToCanvas({ onAdd }: AddMachineToCanvasProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<string | null>(null);

  const availableProfiles: MachinePreview[] = [
    { id: "iqf", name: "IQF Estándar", type: "Congelador", icon: "❄️", capacity: 2500 },
    { id: "sorter", name: "Calibradora Óptica", type: "Calibrador", icon: "🔍", capacity: 4000 },
    { id: "packer", name: "Empacadora Auto", type: "Empaque", icon: "📦", capacity: 1500 },
    { id: "precooler", name: "Pre-Cooler", type: "Enfriador", icon: "🌡️", capacity: 3000 }
  ];

  const handleInsert = () => {
    const profile = availableProfiles.find(p => p.id === selectedProfile);
    if (profile) {
      onAdd({ id: profile.id, name: profile.name, capacity: profile.capacity });
      setSelectedProfile(null);
      setIsOpen(false);
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg shadow-lg transition-all group"
      >
        <Plus className="w-4 h-4" />
        <span className="text-sm font-medium">Agregar Máquina al Proceso</span>
      </button>
    );
  }

  return (
    <div className="w-80 bg-[#1a1a24]/95 backdrop-blur-xl border border-slate-800 rounded-lg shadow-2xl">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Plus className="w-4 h-4 text-orange-500" />
          <span className="text-sm font-semibold text-white">Agregar al Diagrama</span>
        </div>
        <button
          onClick={() => setIsOpen(false)}
          className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Info Badge */}
      <div className="px-4 py-2 bg-blue-600/10 border-b border-blue-600/20">
        <p className="text-xs text-blue-400">
          📌 Modo ejemplo: Selecciona un perfil de máquina para insertarlo en el diagrama
        </p>
      </div>

      {/* Machine Profiles */}
      <div className="p-4 space-y-2 max-h-96 overflow-y-auto">
        {availableProfiles.map((profile) => (
          <button
            key={profile.id}
            onClick={() => setSelectedProfile(profile.id)}
            className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all text-left ${
              selectedProfile === profile.id
                ? "bg-orange-600/20 border-orange-600/50"
                : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
            }`}
          >
            <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center text-xl flex-shrink-0">
              {profile.icon}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{profile.name}</p>
              <p className="text-xs text-slate-400">{profile.type}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500">Capacidad</p>
              <p className="text-xs font-semibold text-white">{profile.capacity} kg/h</p>
            </div>
          </button>
        ))}
      </div>

      {/* Preview Section */}
      {selectedProfile && (
        <div className="px-4 py-3 border-t border-slate-800 bg-slate-900/30">
          <p className="text-xs text-slate-400 mb-2 uppercase tracking-wider">Vista previa del nodo</p>
          <div className="flex items-center justify-center p-4 bg-slate-800/50 rounded-lg border border-slate-700">
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-600/20 border-2 border-orange-600 rounded-lg flex items-center justify-center text-2xl mx-auto mb-2">
                {availableProfiles.find(p => p.id === selectedProfile)?.icon}
              </div>
              <p className="text-xs text-white font-semibold">
                {availableProfiles.find(p => p.id === selectedProfile)?.name}
              </p>
              <p className="text-xs text-slate-400 mt-1">Sin conexiones</p>
            </div>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="p-4 border-t border-slate-800">
        <button
          disabled={!selectedProfile}
          onClick={handleInsert}
          className={`w-full px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
            selectedProfile
              ? "bg-orange-600 hover:bg-orange-700 text-white"
              : "bg-slate-800 text-slate-600 cursor-not-allowed"
          }`}
        >
          <Grid3x3 className="w-4 h-4" />
          Insertar en el Diagrama
        </button>
        <p className="text-xs text-slate-500 text-center mt-2">
          El nodo aparecerá con estado: <span className="text-amber-400">"Pendiente de conexión"</span>
        </p>
      </div>

      {/* Note */}
      <div className="px-4 py-2 bg-slate-900/50 border-t border-slate-800">
        <p className="text-xs text-slate-500 leading-relaxed">
          <strong className="text-slate-400">Nota:</strong> Después de insertar, podrás moverlo libremente 
          y conectarlo con otros nodos creando flujos.
        </p>
      </div>
    </div>
  );
}