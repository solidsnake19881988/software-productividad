import { Cpu, Package, Gauge, Zap } from "lucide-react";

interface MachineProfile {
  id: string;
  name: string;
  type: string;
  icon: string;
  nominalSpeed: number;
  compatibleProducts: string[];
  baseParameters: {
    setupTime: number;
    efficiency: number;
    energyCost: number;
  };
}

export function MachineProfileLibrary() {
  const profiles: MachineProfile[] = [
    {
      id: "profile-iqf",
      name: "IQF Estándar",
      type: "Congelador IQF",
      icon: "❄️",
      nominalSpeed: 2500,
      compatibleProducts: ["Arándanos", "Frambuesas", "Mixtos"],
      baseParameters: {
        setupTime: 30,
        efficiency: 92,
        energyCost: 45
      }
    },
    {
      id: "profile-sorter",
      name: "Calibradora Óptica",
      type: "Calibrador",
      icon: "🔍",
      nominalSpeed: 4000,
      compatibleProducts: ["Premium", "Regular", "Export"],
      baseParameters: {
        setupTime: 20,
        efficiency: 88,
        energyCost: 25
      }
    },
    {
      id: "profile-packer",
      name: "Empacadora Automática",
      type: "Empaque",
      icon: "📦",
      nominalSpeed: 1500,
      compatibleProducts: ["Bolsa 1kg", "Bolsa 500g", "Granel"],
      baseParameters: {
        setupTime: 15,
        efficiency: 85,
        energyCost: 18
      }
    },
    {
      id: "profile-precooler",
      name: "Pre-Cooler Estándar",
      type: "Enfriador",
      icon: "🌡️",
      nominalSpeed: 3000,
      compatibleProducts: ["Todos los productos"],
      baseParameters: {
        setupTime: 25,
        efficiency: 90,
        energyCost: 35
      }
    }
  ];

  return (
    <div className="space-y-4">
      <div className="mb-4">
        <p className="text-xs text-slate-400 leading-relaxed">
          <strong className="text-white">Perfiles predefinidos:</strong> Permiten crear máquinas rápidamente 
          con parámetros estándar del modelo. Los valores pueden ajustarse después de la creación.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {profiles.map((profile) => (
          <div
            key={profile.id}
            className="bg-slate-900/50 border border-slate-800 rounded-lg p-4 hover:border-orange-600/50 transition-colors cursor-pointer group"
          >
            <div className="flex items-start gap-3 mb-3">
              <div className="w-12 h-12 bg-orange-600/20 rounded-lg flex items-center justify-center text-2xl flex-shrink-0 group-hover:bg-orange-600/30 transition-colors">
                {profile.icon}
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-white mb-1">{profile.name}</h4>
                <p className="text-xs text-slate-400">{profile.type}</p>
              </div>
              <button className="px-3 py-1 bg-orange-600 hover:bg-orange-700 text-white text-xs rounded transition-colors opacity-0 group-hover:opacity-100">
                Usar Perfil
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs mb-3">
              <div className="bg-slate-800/50 rounded p-2">
                <p className="text-slate-400 mb-1">Velocidad Nominal</p>
                <p className="text-white font-semibold">{profile.nominalSpeed.toLocaleString()} kg/h</p>
              </div>
              <div className="bg-slate-800/50 rounded p-2">
                <p className="text-slate-400 mb-1">Eficiencia Base</p>
                <p className="text-white font-semibold">{profile.baseParameters.efficiency}%</p>
              </div>
            </div>

            <div className="border-t border-slate-800 pt-2">
              <p className="text-xs text-slate-400 mb-1">Productos compatibles:</p>
              <div className="flex flex-wrap gap-1">
                {profile.compatibleProducts.map((product, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 text-xs bg-slate-800 text-slate-300 rounded"
                  >
                    {product}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
