import React, { useState } from "react";
import { 
  Search, 
  Filter, 
  Download, 
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  MoreVertical,
  Eye,
  FileText
} from "lucide-react";
import { format } from "date-fns";

const mockData = Array.from({ length: 15 }).map((_, i) => ({
  id: `PLAN-2026-${100 + i}`,
  date: new Date(2026, 0, 27 - i),
  production: (20000 + Math.random() * 5000).toFixed(0),
  efficiency: (85 + Math.random() * 10).toFixed(1),
  status: Math.random() > 0.2 ? "Completado" : "Pendiente",
  productType: ["IQF Berries", "Calibrado", "Empaque Mixto"][Math.floor(Math.random() * 3)],
  operator: "Admin_0" + (i % 5)
}));

export function DatabaseView() {
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input 
            type="text" 
            placeholder="Buscar por ID, producto u operador..." 
            className="w-full bg-[#12121a] border border-slate-800 rounded-lg py-2 pl-10 pr-4 text-sm text-slate-200 focus:outline-none focus:ring-1 focus:ring-orange-500 transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-[#12121a] border border-slate-800 rounded-lg px-3 py-2 cursor-pointer hover:border-slate-700 transition-all">
            <CalendarIcon className="w-4 h-4 text-slate-400" />
            <span className="text-sm text-slate-300">Rango de fechas</span>
          </div>
          <button className="flex items-center gap-2 bg-[#12121a] border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-300 hover:bg-slate-800 transition-all">
            <Filter className="w-4 h-4" />
            Filtros
          </button>
          <button className="flex items-center gap-2 bg-orange-500 text-white rounded-lg px-4 py-2 text-sm font-medium hover:bg-orange-600 transition-all">
            <Download className="w-4 h-4" />
            Exportar
          </button>
        </div>
      </div>

      <div className="bg-[#12121a] rounded-xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/50">
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">ID Planificación</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Fecha</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Producto Principal</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Producción (kg)</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Eficiencia</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Estado</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {mockData.map((row) => (
                <tr key={row.id} className="hover:bg-slate-800/30 transition-colors group">
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium text-white">{row.id}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-slate-400">{format(row.date, "dd MMM, yyyy")}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-slate-300">{row.productType}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-white font-medium">{parseInt(row.production).toLocaleString()} kg</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 w-16 bg-slate-800 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-orange-500 rounded-full" 
                          style={{ width: `${row.efficiency}%` }}
                        />
                      </div>
                      <span className="text-xs text-slate-400">{row.efficiency}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      row.status === "Completado" 
                        ? "bg-green-500/10 text-green-500" 
                        : "bg-yellow-500/10 text-yellow-500"
                    }`}>
                      {row.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-all">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-all">
                        <FileText className="w-4 h-4" />
                      </button>
                      <button className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded transition-all">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between">
          <p className="text-xs text-slate-500">Mostrando 15 de 142 resultados</p>
          <div className="flex items-center gap-2">
            <button className="p-1 text-slate-400 hover:text-white disabled:opacity-30" disabled>
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-1">
              {[1, 2, 3].map(i => (
                <button 
                  key={i}
                  className={`w-8 h-8 rounded text-xs font-medium ${
                    i === 1 ? "bg-orange-500 text-white" : "text-slate-400 hover:bg-slate-800"
                  }`}
                >
                  {i}
                </button>
              ))}
            </div>
            <button className="p-1 text-slate-400 hover:text-white">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
