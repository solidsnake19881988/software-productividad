import { useState } from 'react';
import { ResultsDisplay } from '@/app/components/ResultsDisplay';
import { Button } from '@/app/components/ui/button';
import { toast } from 'sonner';
import { ArrowLeft } from 'lucide-react';

interface OptimizationPageProps {
  onBack: () => void;
}

export default function OptimizationPage({ onBack }: OptimizationPageProps) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleOptimize = async () => {
    setLoading(true);
    setResult(null);

    try {
      // Simulación de llamada a la API
      await new Promise((resolve) => setTimeout(resolve, 2000));

      // Resultado simulado
      const mockResult = {
        status: 'success',
        optimalValue: Math.random() * 1000,
        solution: Array.from({ length: 5 }, () => Math.random() * 100),
        iterations: Math.floor(Math.random() * 100) + 50,
        executionTime: Math.random() * 5 + 1,
        convergence: true,
        message: 'Optimización completada exitosamente',
      };

      setResult(mockResult);
      toast.success('Optimización completada');
    } catch (error) {
      console.error('Error:', error);
      setResult({
        status: 'error',
        message: error instanceof Error ? error.message : 'Error desconocido',
      });
      toast.error('Error en la optimización');
    } finally {
      setLoading(false);
    }
  };

  // Exportar resultados a JSON
  const exportToJSON = () => {
    if (!result) {
      toast.error('No hay resultados para exportar');
      return;
    }

    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'resultados_optimizacion.json';
    a.click();

    URL.revokeObjectURL(url);
    toast.success('Resultados exportados a JSON');
  };

  // Exportar resultados a CSV
  const exportToCSV = () => {
    if (!result) {
      toast.error('No hay resultados para exportar');
      return;
    }

    const headers = Object.keys(result).join(',');
    const values = Object.values(result).join(',');

    const csvContent = headers + '\n' + values;
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = 'resultados_optimizacion.csv';
    a.click();

    URL.revokeObjectURL(url);
    toast.success('Resultados exportados a CSV');
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>
          <div className="flex-1">
            <h1 className="text-3xl font-bold">Modelo de Optimización</h1>
            <p className="text-muted-foreground">
              Ejecute el modelo y exporte los resultados
            </p>
          </div>
        </div>

        {/* Botones de acción */}
        <div className="flex gap-4">
          <Button onClick={handleOptimize} disabled={loading}>
            {loading ? 'Resolviendo...' : 'Resolver Modelo'}
          </Button>
          <Button variant="outline" onClick={exportToJSON} disabled={!result}>
            Exportar a JSON
          </Button>
          <Button variant="outline" onClick={exportToCSV} disabled={!result}>
            Exportar a CSV
          </Button>
        </div>

        {/* Resultados */}
        <ResultsDisplay result={result} />
      </div>
    </div>
  );
}