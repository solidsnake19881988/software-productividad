import { CalendarDays, AlertTriangle, CheckCircle, XCircle, Clock, Package, Info, Play, ChevronDown } from "lucide-react";
import { SectionHeader } from "./SectionHeader";
import { AnnotationBadge } from "./AnnotationBadge";
import { IndustrialCard } from "./IndustrialCard";
import { useState } from "react";

interface ProductionOrder {
  id: string;
  product: string;
  quantity: number;
  startTime: number; // hours from day start
  duration: number; // hours
  machineId: string;
  status: "feasible" | "warning" | "infeasible";
  violations?: string[];
}

interface Machine {
  id: string;
  name: string;
  capacity: number;
  lineColor: string;
}

interface Planning {
  id: string;
  name: string;
  type: "optimization" | "simulation";
  horizon: string;
  status: "feasible" | "warning";
  createdAt: string;
  orders: ProductionOrder[];
}

export function ManualPlannerView() {
  const [selectedPlanning, setSelectedPlanning] = useState<string>("plan-001");
  const [showPlanningSelector, setShowPlanningSelector] = useState(false);
  const [draggedOrder, setDraggedOrder] = useState<ProductionOrder | null>(null);

  const machines: Machine[] = [
    { id: "m1", name: "IQF Tunnel 01", capacity: 2500, lineColor: "#f97316" },
    { id: "m2", name: "Pre-Cooler A", capacity: 3000, lineColor: "#f97316" },
    { id: "m3", name: "Sorter Optical X1", capacity: 4000, lineColor: "#3b82f6" },
    { id: "m4", name: "Packer Auto 500", capacity: 1500, lineColor: "#3b82f6" }
  ];

  const availablePlannings: Planning[] = [
    {
      id: "plan-001",
      name: "Planificación optimizada – Producción real",
      type: "optimization",
      horizon: "17 horas (2 turnos)",
      status: "feasible",
      createdAt: "2026-01-27 08:00",
      orders: [
        {
          id: "ord-001",
          product: "Arándanos Premium",
          quantity: 5000,
          startTime: 0,
          duration: 2,
          machineId: "m1",
          status: "feasible"
        },
        {
          id: "ord-002",
          product: "Frambuesas IQF",
          quantity: 4800,
          startTime: 2.5,
          duration: 2,
          machineId: "m1",
          status: "warning",
          violations: ["Superposición de 30 min con orden anterior"]
        },
        {
          id: "ord-003",
          product: "Mixtos Pre-Cooled",
          quantity: 6000,
          startTime: 1,
          duration: 2,
          machineId: "m2",
          status: "feasible"
        },
        {
          id: "ord-004",
          product: "Calibrado Óptico",
          quantity: 9500,
          startTime: 0,
          duration: 2.5,
          machineId: "m3",
          status: "infeasible",
          violations: [
            "Sobrecarga de capacidad: 3800 kg/h > 4000 kg/h",
            "Requiere inventario adicional no disponible"
          ]
        },
        {
          id: "ord-005",
          product: "Empaque Bolsa 1kg",
          quantity: 3000,
          startTime: 3,
          duration: 2,
          machineId: "m4",
          status: "feasible"
        }
      ]
    },
    {
      id: "sim-001",
      name: "Simulación – Escenario alta demanda",
      type: "simulation",
      horizon: "17 horas (2 turnos)",
      status: "warning",
      createdAt: "2026-01-26 14:30",
      orders: [
        {
          id: "ord-101",
          product: "Arándanos Premium",
          quantity: 7500,
          startTime: 0,
          duration: 3,
          machineId: "m1",
          status: "feasible"
        },
        {
          id: "ord-102",
          product: "Frambuesas IQF XL",
          quantity: 8000,
          startTime: 3,
          duration: 3.5,
          machineId: "m1",
          status: "warning",
          violations: ["Alta utilización: 95% capacidad"]
        },
        {
          id: "ord-103",
          product: "Pre-Cooled Intensivo",
          quantity: 9000,
          startTime: 0,
          duration: 3,
          machineId: "m2",
          status: "feasible"
        },
        {
          id: "ord-104",
          product: "Calibrado Premium",
          quantity: 12000,
          startTime: 0,
          duration: 3,
          machineId: "m3",
          status: "feasible"
        },
        {
          id: "ord-105",
          product: "Empaque Express",
          quantity: 4500,
          startTime: 4,
          duration: 3,
          machineId: "m4",
          status: "warning",
          violations: ["Requiere inventario previo en turno anterior"]
        },
        {
          id: "ord-106",
          product: "Empaque Refuerzo",
          quantity: 3000,
          startTime: 8,
          duration: 2,
          machineId: "m4",
          status: "feasible"
        }
      ]
    },
    {
      id: "sim-002",
      name: "Simulación – Mantenimiento línea 1",
      type: "simulation",
      horizon: "17 horas (2 turnos)",
      status: "feasible",
      createdAt: "2026-01-25 10:15",
      orders: [
        {
          id: "ord-201",
          product: "Solo Pre-Cooler",
          quantity: 10000,
          startTime: 0,
          duration: 4,
          machineId: "m2",
          status: "feasible"
        },
        {
          id: "ord-202",
          product: "Sorter Alta Carga",
          quantity: 15000,
          startTime: 0,
          duration: 4,
          machineId: "m3",
          status: "feasible"
        },
        {
          id: "ord-203",
          product: "Empaque Continuo",
          quantity: 6000,
          startTime: 5,
          duration: 4,
          machineId: "m4",
          status: "feasible"
        }
      ]
    }
  ];

  const currentPlanning = availablePlannings.find(p => p.id === selectedPlanning) || availablePlannings[0];
  const [orders, setOrders] = useState<ProductionOrder[]>(currentPlanning.orders);

  // Update orders when planning changes
  const handlePlanningChange = (planningId: string) => {
    setSelectedPlanning(planningId);
    const newPlanning = availablePlannings.find(p => p.id === planningId);
    if (newPlanning) {
      setOrders(newPlanning.orders);
    }
    setShowPlanningSelector(false);
  };

  const timeSlots = Array.from({ length: 17 }, (_, i) => i); // Changed to 17 hours
  const hourWidth = 60; // pixels per hour

  const handleDragStart = (order: ProductionOrder) => {
    setDraggedOrder(order);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (machineId: string, e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedOrder) return;

    // Calculate new position based on drop location
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const newStartTime = Math.max(0, Math.round(x / hourWidth));

    // Update the order
    setOrders(orders.map(order => 
      order.id === draggedOrder.id 
        ? { ...order, machineId, startTime: newStartTime }
        : order
    ));

    setDraggedOrder(null);
  };

  const getStatusColor = (status: ProductionOrder["status"]) => {
    switch (status) {
      case "feasible": return { bg: "bg-green-600", border: "border-green-500", text: "text-green-400" };
      case "warning": return { bg: "bg-amber-600", border: "border-amber-500", text: "text-amber-400" };
      case "infeasible": return { bg: "bg-red-600", border: "border-red-500", text: "text-red-400" };
    }
  };

  const getStatusIcon = (status: ProductionOrder["status"]) => {
    switch (status) {
      case "feasible": return CheckCircle;
      case "warning": return AlertTriangle;
      case "infeasible": return XCircle;
    }
  };

  const validationSummary = {
    feasible: orders.filter(o => o.status === "feasible").length,
    warning: orders.filter(o => o.status === "warning").length,
    infeasible: orders.filter(o => o.status === "infeasible").length,
    totalProduction: orders.reduce((sum, o) => sum + o.quantity, 0)
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto">
      <SectionHeader
        icon={CalendarDays}
        title="Planificador Manual & Validación"
        subtitle="Edición de órdenes de producción con validación en tiempo real contra restricciones MILP"
        badge="MANUAL MODE"
      >
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors flex items-center gap-2">
            <Play className="w-4 h-4" />
            Ejecutar Validación
          </button>
        </div>
      </SectionHeader>

      {/* Planning Selector */}
      <div className="mb-8">
        <label className="text-xs text-slate-400 uppercase tracking-wider mb-2 block">
          Planificación activa
        </label>
        <div className="relative">
          <button
            onClick={() => setShowPlanningSelector(!showPlanningSelector)}
            className="w-full bg-[#1a1a24] border border-slate-800 rounded-lg p-4 flex items-center justify-between hover:border-slate-700 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                currentPlanning.type === "optimization" 
                  ? "bg-gradient-to-br from-orange-600 to-orange-700 shadow-lg shadow-orange-900/30"
                  : "bg-gradient-to-br from-blue-600 to-blue-700 shadow-lg shadow-blue-900/30"
              }`}>
                <CalendarDays className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-white">{currentPlanning.name}</h3>
                  <span className={`px-2 py-1 text-xs rounded border ${
                    currentPlanning.status === "feasible"
                      ? "bg-green-600/20 text-green-400 border-green-600/30"
                      : "bg-amber-600/20 text-amber-400 border-amber-600/30"
                  }`}>
                    {currentPlanning.status === "feasible" ? "Factible" : "Advertencia"}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-xs text-slate-400">
                  <span>Horizonte: {currentPlanning.horizon}</span>
                  <span>•</span>
                  <span>Origen: {currentPlanning.type === "optimization" ? "Optimización" : "Simulación"}</span>
                  <span>•</span>
                  <span>{currentPlanning.createdAt}</span>
                </div>
              </div>
            </div>
            <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${
              showPlanningSelector ? "rotate-180" : ""
            }`} />
          </button>

          {/* Dropdown */}
          {showPlanningSelector && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-[#1a1a24] border border-slate-800 rounded-lg shadow-2xl z-10 overflow-hidden">
              {availablePlannings.map((planning) => (
                <button
                  key={planning.id}
                  onClick={() => handlePlanningChange(planning.id)}
                  className={`w-full p-4 flex items-center gap-4 hover:bg-slate-800/50 transition-colors border-b border-slate-800 last:border-0 ${
                    selectedPlanning === planning.id ? "bg-slate-800/30" : ""
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    planning.type === "optimization"
                      ? "bg-orange-600/20 text-orange-400"
                      : "bg-blue-600/20 text-blue-400"
                  }`}>
                    <CalendarDays className="w-4 h-4" />
                  </div>
                  <div className="flex-1 text-left">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium text-white">{planning.name}</p>
                      {selectedPlanning === planning.id && (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      )}
                    </div>
                    <p className="text-xs text-slate-400">
                      {planning.horizon} • {planning.type === "optimization" ? "Optimización" : "Simulación"}
                    </p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded border ${
                    planning.status === "feasible"
                      ? "bg-green-600/20 text-green-400 border-green-600/30"
                      : "bg-amber-600/20 text-amber-400 border-amber-600/30"
                  }`}>
                    {planning.status === "feasible" ? "✓" : "⚠"}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <AnnotationBadge type="info" className="mb-8">
        <strong>Validación en tiempo real:</strong> Cada cambio manual (drag & drop, redimensión, nueva orden) 
        se valida contra las restricciones del modelo MILP. El sistema verifica: capacidades de máquinas, 
        disponibilidad de inventarios, conflictos temporales, y políticas operativas. Los bloques cambian de color 
        según su estado de factibilidad.
      </AnnotationBadge>
      
      {/* Note about planning selection */}
      <AnnotationBadge type="success" className="mb-8">
        <strong>Selector de planificación:</strong> El usuario puede trabajar sobre distintas planificaciones 
        (optimizadas o simuladas) y ajustarlas visualmente. Las modificaciones manuales se marcan como "Cambio pendiente" 
        y requieren validación antes de ejecución. La distribución temporal cambia según la planificación seleccionada.
      </AnnotationBadge>

      {/* Validation Summary */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <div className="bg-[#1a1a24] border border-green-600/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Factibles</span>
            <CheckCircle className="w-4 h-4 text-green-500" />
          </div>
          <p className="text-2xl font-bold text-white">{validationSummary.feasible}</p>
          <p className="text-xs text-slate-500 mt-1">órdenes validadas</p>
        </div>

        <div className="bg-[#1a1a24] border border-amber-600/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Advertencias</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-bold text-white">{validationSummary.warning}</p>
          <p className="text-xs text-slate-500 mt-1">requieren ajuste</p>
        </div>

        <div className="bg-[#1a1a24] border border-red-600/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">No Factibles</span>
            <XCircle className="w-4 h-4 text-red-500" />
          </div>
          <p className="text-2xl font-bold text-white">{validationSummary.infeasible}</p>
          <p className="text-xs text-slate-500 mt-1">violaciones críticas</p>
        </div>

        <div className="bg-[#1a1a24] border border-slate-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 uppercase tracking-wider">Producción Total</span>
            <Package className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-bold text-white">{(validationSummary.totalProduction / 1000).toFixed(1)}k</p>
          <p className="text-xs text-slate-500 mt-1">kg planificados</p>
        </div>
      </div>

      {/* Gantt Chart */}
      <IndustrialCard title="Timeline de Producción por Máquina" subtitle="17 horas - Vista de 2 turnos (Interactivo - Drag & Drop)">
        <div className="overflow-x-auto">
          {/* Time Header */}
          <div className="flex mb-4 pb-2 border-b border-slate-800">
            <div className="w-48 flex-shrink-0" />
            <div className="flex">
              {timeSlots.map((hour) => (
                <div
                  key={hour}
                  className="flex-shrink-0 text-center text-xs text-slate-400 font-mono"
                  style={{ width: `${hourWidth}px` }}
                >
                  {hour.toString().padStart(2, "0")}:00
                </div>
              ))}
            </div>
          </div>

          {/* Machine Rows */}
          {machines.map((machine) => {
            const machineOrders = orders.filter(o => o.machineId === machine.id);

            return (
              <div key={machine.id} className="flex mb-3 items-center">
                {/* Machine Label */}
                <div className="w-48 flex-shrink-0 pr-4">
                  <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800">
                    <div className="flex items-center gap-2 mb-1">
                      <div
                        className="w-3 h-3 rounded"
                        style={{ backgroundColor: machine.lineColor }}
                      />
                      <h4 className="font-semibold text-white text-sm">{machine.name}</h4>
                    </div>
                    <p className="text-xs text-slate-400">{machine.capacity.toLocaleString()} kg/h</p>
                  </div>
                </div>

                {/* Timeline Grid */}
                <div 
                  className="flex-1 relative" 
                  style={{ height: "80px" }}
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(machine.id, e)}
                >
                  {/* Grid Background */}
                  <div className="absolute inset-0 flex">
                    {timeSlots.map((hour) => (
                      <div
                        key={hour}
                        className="border-l border-slate-800/50 flex-shrink-0"
                        style={{ width: `${hourWidth}px` }}
                      />
                    ))}
                  </div>

                  {/* Production Orders */}
                  {machineOrders.map((order) => {
                    const colors = getStatusColor(order.status);
                    const Icon = getStatusIcon(order.status);

                    return (
                      <div
                        key={order.id}
                        draggable
                        onDragStart={() => handleDragStart(order)}
                        className={`absolute ${colors.bg} ${colors.border} border-2 rounded-lg p-2 shadow-lg cursor-move hover:opacity-90 transition-all hover:scale-105`}
                        style={{
                          left: `${order.startTime * hourWidth}px`,
                          width: `${order.duration * hourWidth - 4}px`,
                          top: "10px"
                        }}
                        title={`Drag to move between machines`}
                      >
                        <div className="flex items-start justify-between mb-1">
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-white truncate">{order.product}</p>
                            <p className="text-[10px] text-white/70">{order.quantity.toLocaleString()} kg</p>
                          </div>
                          <Icon className="w-3 h-3 text-white flex-shrink-0 ml-1" />
                        </div>
                        <p className="text-[10px] text-white/60 font-mono">
                          {order.duration}h
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex items-center gap-6 mt-6 pt-4 border-t border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-600 rounded border-2 border-green-500" />
            <span className="text-slate-400">✓ Factible - Sin violaciones</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-amber-600 rounded border-2 border-amber-500" />
            <span className="text-slate-400">⚠ Advertencia - Revisar</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-600 rounded border-2 border-red-500" />
            <span className="text-slate-400">✗ No Factible - Bloquea ejecución</span>
          </div>
        </div>
      </IndustrialCard>

      {/* Violations Panel */}
      <IndustrialCard title="Restricciones Violadas" subtitle="Detalles de órdenes con problemas de factibilidad" className="mt-6">
        <div className="space-y-3">
          {orders
            .filter(o => o.violations && o.violations.length > 0)
            .map((order) => {
              const colors = getStatusColor(order.status);
              const Icon = getStatusIcon(order.status);

              return (
                <div key={order.id} className="bg-slate-900/50 rounded-lg p-4 border border-slate-800">
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 ${colors.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-white">{order.product}</h4>
                        <span className="px-2 py-1 text-xs font-mono bg-slate-800 text-slate-400 rounded">
                          {order.id}
                        </span>
                      </div>
                      <div className="space-y-1">
                        {order.violations?.map((violation, idx) => (
                          <p key={idx} className={`text-xs ${colors.text} flex items-start gap-2`}>
                            <span className="mt-0.5">•</span>
                            <span>{violation}</span>
                          </p>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
        </div>
      </IndustrialCard>

      {/* Footer Annotations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <AnnotationBadge type="warning">
          <strong>Validación contra MILP:</strong> El motor evalúa cada cambio contra las restricciones formales: 
          <code className="mx-1 px-2 py-0.5 bg-slate-900 rounded text-xs">Σ(flow) ≤ capacity</code>, 
          <code className="mx-1 px-2 py-0.5 bg-slate-900 rounded text-xs">inventory ≥ demand</code>, 
          y políticas de negocio. Las violaciones bloquean la ejecución de la planificación.
        </AnnotationBadge>

        <AnnotationBadge type="success">
          <strong>Drag & Drop funcional:</strong> Los bloques ahora son arrastrables entre máquinas. 
          Cada movimiento actualiza la asignación temporal. La distribución cambia según la planificación seleccionada 
          (17 horas de horizonte). Blueprint interactivo completo.
        </AnnotationBadge>
      </div>
    </div>
  );
}
