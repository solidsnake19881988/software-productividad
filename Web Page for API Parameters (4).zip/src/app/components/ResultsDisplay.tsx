import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { CheckCircle2, AlertCircle } from 'lucide-react';

interface OptimizationResult {
  status: 'success' | 'error';
  optimalValue: number;
  solution: number[];
  iterations: number;
  executionTime: number;
  convergence: boolean;
  message?: string;
}

interface ResultsDisplayProps {
  result: OptimizationResult | null;
}

export function ResultsDisplay({ result }: ResultsDisplayProps) {
  if (!result) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Resultados</CardTitle>
          <CardDescription>
            Los resultados de la optimización se mostrarán aquí
          </CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-12">
          <p className="text-muted-foreground">
            Ingrese los parámetros y ejecute la optimización
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Resultados de la Optimización</CardTitle>
          {result.status === 'success' ? (
            <Badge variant="default" className="flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" />
              Éxito
            </Badge>
          ) : (
            <Badge variant="destructive" className="flex items-center gap-1">
              <AlertCircle className="h-3 w-3" />
              Error
            </Badge>
          )}
        </div>
        {result.message && (
          <CardDescription>{result.message}</CardDescription>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {result.status === 'success' && (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Valor Óptimo</p>
                <p className="text-2xl font-semibold">
                  {result.optimalValue.toFixed(2)}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Iteraciones</p>
                <p className="text-2xl font-semibold">{result.iterations}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">
                  Tiempo de Ejecución
                </p>
                <p className="text-2xl font-semibold">
                  {result.executionTime.toFixed(3)}s
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Convergencia</p>
                <p className="text-2xl font-semibold">
                  {result.convergence ? '✓' : '✗'}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">Solución</p>
              <div className="bg-muted rounded-md p-4">
                <div className="flex flex-wrap gap-2">
                  {result.solution.map((value, index) => (
                    <Badge key={index} variant="secondary">
                      x{index + 1}: {value.toFixed(4)}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
