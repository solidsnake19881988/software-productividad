import { Activity, Plus, Play, Trash2, Copy, FileText, TrendingUp, AlertCircle, CheckCircle, Settings } from "lucide-react";
import { SectionHeader } from "./SectionHeader";
import { AnnotationBadge } from "./AnnotationBadge";
import { IndustrialCard } from "./IndustrialCard";
import { ButtonWithTooltip, StateBadge } from "./ButtonWithTooltip";
import { NewSimulationFlow } from "./NewSimulationFlow";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { useState } from "react";

interface Simulation {
  id: string;
  name: string;
  description: string;
  status: "completed" | "running" | "pending";
  createdAt: string;
  duration: string;
  kpis: {
    production: number;
    efficiency: number;
    cost: number;
    feasibility: "feasible" | "infeasible";
  };
}

export function SimulationsView2() {
  const [showNewSimulation, setShowNewSimulation] = useState(false);
  const simulations: Simulation[] = [
    {
      id: "sim-001",
      name: "Escenario: Incremento Demanda 20%",
      description: "Simulación con aumento de demanda del 20% manteniendo capacidades actuales",
      status: "completed",
      createdAt: "2026-01-25",
      duration: "2.3 min",
      kpis: {
        production: 14940,
        efficiency: 91.2,
        cost: 45200,
        feasibility: "feasible"
      }
    },
    {
      id: "sim-002",
      name: "Escenario: IQF Tunnel 02 Operativa",
      description: "Análisis de impacto al activar máquina en mantenimiento",
      status: "completed",
      createdAt: "2026-01-24",
      duration: "1.8 min",
      kpis: {
        production: 16200,
        efficiency: 93.5,
        cost: 48500,
        feasibility: "feasible"
      }
    },
    {
      id: "sim-003",
      name: "Escenario: Reducción Inventario 30%",
      description: "Evaluación de factibilidad con inventario inicial limitado",
      status: "completed",
      createdAt: "2026-01-23",
      duration: "2.1 min",
      kpis: {
        production: 8700,
        efficiency: 68.4,
        cost: 32100,
        feasibility: "infeasible"
      }
    }
  ];

  const realPlanKPIs = {
    production: 12450,
    efficiency: 88.3,
    cost: 42800,
    feasibility: "feasible" as const
  };

  const comparisonData = [
    {
      name: "Producción (kg)",
      Real: realPlanKPIs.production,
      "Sim-001": simulations[0].kpis.production,
      "Sim-002": simulations[1].kpis.production,
      "Sim-003": simulations[2].kpis.production
    },
    {
      name: "Eficiencia (%)",
      Real: realPlanKPIs.efficiency,
      "Sim-001": simulations[0].kpis.efficiency,
      "Sim-002": simulations[1].kpis.efficiency,
      "Sim-003": simulations[2].kpis.efficiency
    },
    {
      name: "Costo (×100)",
      Real: realPlanKPIs.cost / 100,
      "Sim-001": simulations[0].kpis.cost / 100,
      "Sim-002": simulations[1].kpis.cost / 100,
      "Sim-003": simulations[2].kpis.cost / 100
    }
  ];

  const getStatusBadge = (status: Simulation["status"]) => {
    switch (status) {
      case "completed":
        return (
          <span className="px-2 py-1 text-xs bg-green-600/20 text-green-400 border border-green-600/30 rounded flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            Completada
          </span>
        );
      case "running":
        return (
          <span className="px-2 py-1 text-xs bg-blue-600/20 text-blue-400 border border-blue-600/30 rounded flex items-center gap-1 animate-pulse">
            <Play className="w-3 h-3" />
            Ejecutando
          </span>
        );
      case "pending":
        return (
          <span className="px-2 py-1 text-xs bg-slate-600/20 text-slate-400 border border-slate-600/30 rounded">
            Pendiente
          </span>
        );
    }
  };

  const getFeasibilityBadge = (feasibility: "feasible" | "infeasible") => {
    if (feasibility === "feasible") {
      return (
        <span className="px-2 py-1 text-xs bg-green-600/20 text-green-400 border border-green-600/30 rounded">
          ✓ Factible
        </span>
      );
    }
    return (
      <span className="px-2 py-1 text-xs bg-red-600/20 text-red-400 border border-red-600/30 rounded">
        ✗ No Factible
      </span>
    );
  };

  return (
    <div className="p-8 max-w-[1800px] mx-auto">
      <SectionHeader
        icon={Activity}
        title="Centro de Simulaciones"
        subtitle="Análisis de escenarios hipotéticos sin afectar la operación real"
        badge="SIMULATION"
      >
        <button className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm transition-colors flex items-center gap-2" onClick={() => setShowNewSimulation(true)}>
          <Plus className="w-4 h-4" />
          Nueva Simulación
        </button>
      </SectionHeader>

      <AnnotationBadge type="info" className="mb-8">
        <strong>Entorno de pruebas:</strong> Las simulaciones permiten evaluar escenarios "qué pasaría si" ejecutando 
        el modelo MILP con parámetros modificados. Los resultados NO impactan la producción real ni las planificaciones activas. 
        Todas las simulaciones mantienen una copia aislada del estado actual del sistema.
      </AnnotationBadge>

      {/* Simulations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {simulations.map((sim) => (
          <div
            key={sim.id}
            className={`bg-[#1a1a24] border rounded-lg overflow-hidden transition-colors ${
              sim.kpis.feasibility === "feasible" ? "border-slate-800 hover:border-slate-700" : "border-red-900/50 hover:border-red-800/50"
            }`}
          >
            {/* Card Header */}
            <div className="px-4 py-3 bg-[#12121a] border-b border-slate-800/50 flex items-center justify-between">
              {getStatusBadge(sim.status)}
              <span className="text-xs text-slate-500 font-mono">{sim.id}</span>
            </div>

            {/* Card Content */}
            <div className="p-6">
              <h3 className="font-semibold text-white mb-2">{sim.name}</h3>
              <p className="text-xs text-slate-400 mb-4 leading-relaxed">{sim.description}</p>

              {/* KPIs Grid */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-slate-900/50 rounded p-3">
                  <p className="text-xs text-slate-400 mb-1">Producción</p>
                  <p className="text-lg font-bold text-white">{sim.kpis.production.toLocaleString()}</p>
                  <p className="text-xs text-slate-500">kg</p>
                </div>

                <div className="bg-slate-900/50 rounded p-3">
                  <p className="text-xs text-slate-400 mb-1">Eficiencia</p>
                  <p className={`text-lg font-bold ${sim.kpis.efficiency >= 90 ? "text-green-400" : "text-amber-400"}`}>
                    {sim.kpis.efficiency}%
                  </p>
                  <p className="text-xs text-slate-500">global</p>
                </div>

                <div className="bg-slate-900/50 rounded p-3">
                  <p className="text-xs text-slate-400 mb-1">Costo Est.</p>
                  <p className="text-lg font-bold text-white">${(sim.kpis.cost / 1000).toFixed(1)}k</p>
                  <p className="text-xs text-slate-500">USD</p>
                </div>

                <div className="bg-slate-900/50 rounded p-3">
                  <p className="text-xs text-slate-400 mb-1">Factibilidad</p>
                  <div className="mt-1">
                    {getFeasibilityBadge(sim.kpis.feasibility)}
                  </div>
                </div>
              </div>

              {/* Metadata */}
              <div className="flex items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-800">
                <span>Creada: {sim.createdAt}</span>
                <span>Duración: {sim.duration}</span>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 mt-4">
                <button className="flex-1 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs transition-colors flex items-center justify-center gap-2">
                  <FileText className="w-3 h-3" />
                  Ver Reporte
                </button>
                <button className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs transition-colors">
                  <Copy className="w-3 h-3" />
                </button>
                <button className="px-3 py-2 bg-slate-800 hover:bg-red-900/50 text-slate-300 hover:text-red-400 rounded text-xs transition-colors">
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Comparison Chart */}
      <IndustrialCard title="Comparativa: Simulaciones vs Planificación Real" subtitle="Análisis de KPIs principales">
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={comparisonData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2a2a35" />
            <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
            <YAxis stroke="#94a3b8" fontSize={12} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1a1a24",
                border: "1px solid #2a2a35",
                borderRadius: "8px",
                color: "#fff"
              }}
            />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            <Bar dataKey="Real" fill="#10b981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Sim-001" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Sim-002" fill="#f97316" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Sim-003" fill="#ef4444" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>

        <div className="grid grid-cols-4 gap-4 mt-6">
          <div className="text-center">
            <div className="w-4 h-4 bg-green-600 rounded mx-auto mb-2" />
            <p className="text-xs text-slate-400">Planificación Real</p>
          </div>
          <div className="text-center">
            <div className="w-4 h-4 bg-blue-600 rounded mx-auto mb-2" />
            <p className="text-xs text-slate-400">Sim-001 (Demanda +20%)</p>
          </div>
          <div className="text-center">
            <div className="w-4 h-4 bg-orange-600 rounded mx-auto mb-2" />
            <p className="text-xs text-slate-400">Sim-002 (Máquina extra)</p>
          </div>
          <div className="text-center">
            <div className="w-4 h-4 bg-red-600 rounded mx-auto mb-2" />
            <p className="text-xs text-slate-400">Sim-003 (No factible)</p>
          </div>
        </div>
      </IndustrialCard>

      {/* Footer Annotations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <AnnotationBadge type="warning">
          <strong>Simulación vs Optimización:</strong> A diferencia de la optimización real, las simulaciones 
          permiten modificar libremente restricciones "duras" del modelo (capacidades, inventarios, políticas) 
          sin validación de factibilidad previa.
        </AnnotationBadge>

        <AnnotationBadge type="success">
          <strong>Análisis de sensibilidad:</strong> Las simulaciones son ideales para análisis "qué pasaría si" 
          en inversiones de capital (nuevas máquinas), cambios de demanda, o evaluación de políticas operativas alternativas.
        </AnnotationBadge>
      </div>

      {/* New Simulation Flow */}
      <NewSimulationFlow isOpen={showNewSimulation} onClose={() => setShowNewSimulation(false)} />
    </div>
  );
}