import { LucideIcon } from "lucide-react";
import { ReactNode } from "react";

interface ButtonWithTooltipProps {
  icon?: LucideIcon;
  label: string;
  tooltip: string;
  state?: "normal" | "active" | "disabled";
  variant?: "primary" | "secondary" | "ghost";
  onClick?: () => void;
  size?: "sm" | "md" | "lg";
}

export function ButtonWithTooltip({
  icon: Icon,
  label,
  tooltip,
  state = "normal",
  variant = "secondary",
  onClick,
  size = "md"
}: ButtonWithTooltipProps) {
  const sizeClasses = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-6 py-3 text-base"
  };

  const variantClasses = {
    primary: {
      normal: "bg-orange-600 hover:bg-orange-700 text-white",
      active: "bg-orange-700 text-white ring-2 ring-orange-500",
      disabled: "bg-slate-800 text-slate-600 cursor-not-allowed"
    },
    secondary: {
      normal: "bg-slate-800 hover:bg-slate-700 text-slate-300",
      active: "bg-slate-700 text-white ring-2 ring-slate-500",
      disabled: "bg-slate-900 text-slate-700 cursor-not-allowed"
    },
    ghost: {
      normal: "bg-transparent hover:bg-slate-800 text-slate-400 border border-slate-700",
      active: "bg-slate-800 text-white border border-slate-600",
      disabled: "bg-transparent text-slate-800 border border-slate-900 cursor-not-allowed"
    }
  };

  return (
    <div className="relative group inline-block">
      <button
        onClick={state !== "disabled" ? onClick : undefined}
        disabled={state === "disabled"}
        className={`
          ${sizeClasses[size]} 
          ${variantClasses[variant][state]} 
          rounded-lg transition-all flex items-center gap-2 font-medium
        `}
      >
        {Icon && <Icon className="w-4 h-4" />}
        {label}
        {state === "disabled" && (
          <span className="ml-1 text-xs opacity-60">(No disponible)</span>
        )}
      </button>

      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
        <div className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 shadow-xl max-w-xs">
          <p className="text-xs text-slate-300 leading-relaxed">{tooltip}</p>
          {state === "disabled" && (
            <p className="text-xs text-amber-400 mt-1 italic">⚠ Requiere datos del ERP</p>
          )}
        </div>
        <div className="w-2 h-2 bg-slate-900 border-b border-r border-slate-700 absolute -bottom-1 left-1/2 -translate-x-1/2 rotate-45" />
      </div>
    </div>
  );
}

interface StateBadgeProps {
  state: "optimal" | "executing" | "failed" | "idle";
  children: ReactNode;
}

export function StateBadge({ state, children }: StateBadgeProps) {
  const stateStyles = {
    optimal: "bg-green-600/20 text-green-400 border-green-600/30",
    executing: "bg-blue-600/20 text-blue-400 border-blue-600/30 animate-pulse",
    failed: "bg-red-600/20 text-red-400 border-red-600/30",
    idle: "bg-slate-600/20 text-slate-400 border-slate-600/30"
  };

  return (
    <div className={`px-3 py-1.5 rounded-lg border text-xs font-mono ${stateStyles[state]}`}>
      {children}
    </div>
  );
}
